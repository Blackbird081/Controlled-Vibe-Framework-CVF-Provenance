# CVF ACEL G1 T2A Candidate Evidence Binding Schema Amendment

Memory class: governed-implementation-audit

docType: audit

Status: WORKER_COMPLETE_PENDING_REVIEW

Batch ID: ACEL-G1-T2A-CANDIDATE-EVIDENCE-BINDING-SCHEMA-AMENDMENT

EPISTEMIC_PROCESS_NA_WITH_REASON: this audit records a root-contract schema
amendment derived from independently reproduced review findings; it does not
run or test an implementation, so no new empirical hypothesis is evaluated
here. Every design rule below is a direct closure of a named R2-RV-F1
through F4 finding, cited by line and mapped one-to-one.

## Purpose

Design a fresh root-contract amendment for the G1 candidate evidence binding
schema that structurally closes the four acceptance-blocking gaps recorded in
`docs/reviews/CVF_ACEL_G1_T2_R2_INDEPENDENT_REVIEW_2026-09-17.md`
(`REVIEW_REJECTED_PARKED_REDESIGN_REQUIRED`). This is a schema/design
artifact only. It does not repair, accept, or modify the seven rejected G1
T2 paths, and it authorizes no implementation, provider/live execution,
runtime, configuration mutation, or G4 work.

## Target / Source

| Target | Path | Role |
|---|---|---|
| Rejection authority | `docs/reviews/CVF_ACEL_G1_T2_R2_INDEPENDENT_REVIEW_2026-09-17.md` | names the four findings this amendment must close |
| Design authority (unchanged rules) | `docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json` | source of every rule not amended here |
| Frozen rejected implementation (read-only) | `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/task.class.calibration.owner.contract.ts` | evidence of exactly how F1-F3 occurred; never edited by this tranche |
| Frozen rejected checker (read-only) | `governance/compat/check_task_class_calibration_owner_evidence.py` | evidence of exactly how F2/F4 occurred; never edited by this tranche |
| G3 dependency (read-only, reused unchanged) | `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/assf.behavioral.evaluation.contract.ts` | source of the `gradeBehavioralEvaluation`/`admitFixtureSet` semantics this amendment binds against |
| This amendment's machine twin | `docs/audits/CVF_ACEL_G1_T2A_CANDIDATE_EVIDENCE_BINDING_SCHEMA_AMENDMENT_MANIFEST_2026-09-17.json` | exact schema, fields, and successor manifest |

## Scope / Methodology

Read the R2 independent review in full (Findings/Position, Probe Evidence,
Required Reopen Decision), the accepted T1 manifest's
`candidateEvidenceBinding`, `searchHeldoutPartition`, `comparabilityFingerprint`,
`eligibilityBeforePreferencePolicy`, `provenanceFingerprint`, and
`regressionBindingSchema` sections, the exact rejected implementation lines
the review cites (492-507, 660-725, 835-904), and the exact rejected checker
lines the review cites (216-221, 293-430). Recomputed the SHA-256 of all
seven frozen paths at execution start; four matched the work order's
dispatch-observed values exactly (files 1, 2, 6, 7); the remaining three
(audit, contract doc, worker return) were recomputed fresh since the work
order marked them "worker recomputes at start." No frozen path was edited.
Every design rule below is derived by tracing the exact review-cited gap to
its root in the T1 manifest, then closing that root without altering any
unrelated accepted rule (decision-state precedence, partition/contamination
rule, repeat semantics, invalidation-trigger set are unchanged).

## Root Cause Analysis: Why F1-F4 Were Possible Under The Accepted T1 Manifest

The accepted T1 manifest already required, in prose, that eligibility
depends on "all required held-out G3 fixtures" having bound
`PASS_WITH_EVIDENCE` results (`eligibilityBeforePreferencePolicy.stage1EligibilityFilter`,
final row) -- plural, by design. But the same manifest's
`candidateEvidenceBinding.requiredFields` only ever defined **one**
`fixtureId`/`fixtureContentHash`/`g3ResultHash` per candidate envelope. The
rejected implementation followed the literal single-fixture field list, so
"all required held-out fixtures" collapsed to exactly one fixture per
candidate. R2's worker then had to satisfy `admitFixtureSet`'s
positive-plus-negative rule (from G3, reused correctly) somehow, and the only
lever available under a single-fixture-per-candidate schema was pooling
fixtures **across candidates in the round** -- which is exactly R2-RV-F1.
This is a genuine schema gap in the T1 manifest's field list, not merely an
implementation bug; a correct implementation of the literal T1
`candidateEvidenceBinding` schema could not have satisfied the plural
"all required held-out fixtures" rule the same manifest also states. This
amendment's first and largest change (`## Candidate-Scoped Evidence Set`
below) closes that root by promoting the field list from one fixture to a
required, candidate-scoped, non-empty fixture-result collection.

F2 and F3 are narrower: the T1 manifest's `provenanceFingerprint.formula`
already names `preferencePolicyHash` as a required preimage component, and
the design's spirit (`candidateEvidenceBinding.verification`: "G3 output
alone does not attest candidate or live identity") already implies every
bound identity must appear in provenance. The rejected implementation simply
omitted `preferencePolicyHash` and several identity fields from its actual
preimage construction, and never required GC-026's outer/inner fields to
agree. These are implementation-fidelity gaps against an already-adequate
T1 formula, not new schema debt -- this amendment restates the formula with
an explicit, ordered, typed preimage (`## Canonical Provenance And
Invalidation` below) precisely so a future implementation cannot omit a
component without failing schema validation.

## Candidate-Scoped Evidence Set

### Problem This Closes

R2-RV-F1 (CRITICAL): round-level `admitFixtureSet` pooling let one
candidate's negative fixture satisfy another candidate's positive/negative
requirement (rejected implementation lines 492-507; test helper lines
285-374 append an intentionally failing companion candidate; the ordinary
positive candidate still becomes `preferred`). Probe evidence: baseline
probe returns `ACCEPTED_PREFERRED` for the positive candidate while its
negative companion is `insufficient_evidence` -- the round-level pool
satisfied admission with evidence that never attests the winning candidate.

### Schema Rule

A candidate envelope no longer declares a single `fixtureId` /
`fixtureContentHash` / `traceIds` / `traceContentHashes` /
`traceCaptureModes` / `g3ResultHash` tuple. It declares one
**`requiredFixtureEvidenceSet`**: a non-empty, ordered array of
`CandidateFixtureEvidence` records, each binding exactly one fixture to its
own traces/receipt/G3 result, all scoped to the **same candidate and the
same `candidateConfigHash`**.

```text
CandidateFixtureEvidence = {
  fixtureId: string (non-empty)
  fixtureClass: "POSITIVE" | "NEGATIVE"          // mirrors G3's own vocabulary
  fixtureContentHash: canonicalHash
  traceIds: string[] (non-empty)
  traceContentHashes: canonicalHash[] (same length as traceIds)
  traceCaptureModes: string[] (same length as traceIds)
  g3ResultHash: canonicalHash                     // recomputed, not caller-trusted (unchanged rule)
  producerReceipt: { receiptRef, candidateId, candidateConfigHash, traceIds }  // unchanged shape from R1
  g3Fixture: object                               // actual G3 fixture, genuinely graded (unchanged rule)
  g3Traces: object[]                              // actual G3 traces, genuinely graded (unchanged rule)
  g3PairedFixture?: object
}
```

`requiredFixtureEvidenceSet` replaces the single-fixture fields inside
`TaskClassCalibrationCandidateEnvelope`. Every other envelope field
(`taskClassId`, `candidateId`, `candidateConfigHash`, `comparabilityFingerprint`
and its constituent fields, `partition`, `policyId`, `budgetCeiling`,
`budgetConsumed`, `providerLaneStatus`, `contaminationKeys`, optional
`rubricEvaluatorAdapter`/`benchmarkReport`/`metricUnit`) is unchanged from
the accepted T1 manifest and the R1/R2 binding-verification additions; this
amendment touches only the fixture/trace/receipt/result shape.

### Required Fixture-Set Authority (Closes R1-RV-F1's Missing Descriptor)

R1-RV-F1 correctly found that a candidate-local `requiredFixtureEvidenceSet`
alone cannot prove a candidate covers the *task-class-required* fixtures,
because nothing named the authoritative required-set descriptor or an exact
comparison. The T1 manifest already defines the authority this amendment was
missing: `comparabilityFingerprint.fixtureSetContentHash`
(`comparabilityFingerprint.formula`/`fields`, unchanged) is the round's
existing canonical content hash of the task-class-bound fixture set, and
every candidate envelope already carries its own `comparabilityFingerprint`
(unchanged field). This amendment adds one new top-level round artifact,
**`RequiredFixtureSetDeclaration`**, that makes the required member list
explicit rather than leaving it implicit in a single hash:

```text
RequiredFixtureSetDeclaration = {
  taskClassId: string                              // binds to the round's taskClassId
  fixtureSetContentHash: canonicalHash              // must equal recompute(sort(requiredMembers by fixtureId) then hash) -- ties this declaration to the existing T1 comparabilityFingerprint component
  requiredMembers: Array<{
    fixtureId: string (non-empty)
    fixtureClass: "POSITIVE" | "NEGATIVE"
    fixtureContentHash: canonicalHash
  }>                                                 // non-empty; at least one POSITIVE and one NEGATIVE member; sorted by fixtureId ascending before hashing into fixtureSetContentHash
}
```

`RequiredFixtureSetDeclaration` is round-scoped (one per `taskClassId` per
round), not candidate-scoped, and read-only input to every candidate's
coverage check in that round; it is never authored or mutated by an
individual candidate envelope.

**Coverage equality (closes F1's "cannot distinguish missing from extra"
gap):** a candidate's `requiredFixtureEvidenceSet` **covers** the round's
`RequiredFixtureSetDeclaration` if and only if, for every entry in
`requiredMembers`, there exists exactly one entry in
`requiredFixtureEvidenceSet` with the same `fixtureId` **and** the same
`fixtureClass` **and** the same `fixtureContentHash`. This is a set-equality
check on `{(fixtureId, fixtureClass, fixtureContentHash)}` restricted to the
required members' `fixtureId`s -- entries in `requiredFixtureEvidenceSet`
whose `fixtureId` is not present in `requiredMembers` are extras (see the
extra-fixture rule below) and are excluded from the coverage check itself. A
candidate whose set does not cover every required member fails closed to
`insufficient_evidence` with a named `MISSING_REQUIRED_FIXTURE` reason
listing the uncovered `fixtureId`(s); a required member present with a
mismatched `fixtureClass` or `fixtureContentHash` is treated as not covering
that member (named `REQUIRED_FIXTURE_CONTENT_MISMATCH`), not as an
unrelated extra.

### Set-Coverage, Duplicate, Missing, Extra, Ordering, Malformed Behavior

- **Coverage rule (closes F1 directly):** two independent, both-mandatory
  gates apply per candidate, evaluated exclusively over that candidate's own
  `requiredFixtureEvidenceSet` -- never pooled across candidates: (1)
  `admitFixtureSet` (G3's own, reused unchanged), evaluated over that
  candidate's own `requiredFixtureEvidenceSet[].g3Fixture` pool only; and (2)
  the `RequiredFixtureSetDeclaration` coverage-equality check defined above,
  which additionally proves the candidate's set contains every specific
  required `fixtureId`/`fixtureClass`/`fixtureContentHash`, not merely one
  fixture of each class. A candidate failing either gate (missing positive,
  missing negative, malformed, or missing/mismatched required member) fails
  closed to `insufficient_evidence` for that candidate alone; it can never be
  cured by another candidate's fixtures, and it can never silently exclude
  the candidate from the round without a disclosed reason.
- **Per-fixture bound requirement (scoped to required entries; reconciled
  with the extra-fixture rule below):** every entry in
  `requiredFixtureEvidenceSet` whose `fixtureId` matches a member of the
  round's `RequiredFixtureSetDeclaration.requiredMembers` (a "required
  entry") must independently reach `PASS_WITH_EVIDENCE` from
  `gradeBehavioralEvaluation` (reused unchanged), with the same
  candidate-identity and byte-binding cross-checks R1 already added
  (`producerReceipt` identity match, recomputed `g3ResultHash`,
  `fixtureContentHash`/`traceContentHashes` cross-check against the actual
  supplied `g3Fixture`/`g3Traces`). One **required** entry failing this bar
  makes the **whole candidate** `insufficient_evidence`; a partially-passing
  required subset is never averaged or rounded into eligibility. This is the
  literal implementation of the T1 manifest's plural "all required held-out
  G3 fixtures must have bound `PASS_WITH_EVIDENCE` results." An entry whose
  `fixtureId` is **not** a required member (an extra, per the coverage
  equality rule above) is governed exclusively by the extra-fixture rule
  below, not by this required-entry rule -- the two rules apply to disjoint
  entry sets by construction, so they cannot contradict for the same entry.
- **Duplicate fixture IDs within one candidate's set:** two entries sharing
  the same `fixtureId` inside one `requiredFixtureEvidenceSet` blocks that
  candidate to `insufficient_evidence` with a named
  `DUPLICATE_FIXTURE_ID_WITHIN_CANDIDATE` reason; never silently
  deduplicated or last-write-wins.
- **Missing required class:** if the candidate's own set lacks a `POSITIVE`
  or lacks a `NEGATIVE` fixture (per G3's `admitFixtureSet` result for that
  candidate's own pool), the candidate is `insufficient_evidence` with the
  literal G3 admission reason (`MISSING_POSITIVE_CASE` /
  `MISSING_NEGATIVE_CASE`) attributed to that candidate by ID, never as an
  anonymous round-level note. This `admitFixtureSet` class-composition check
  and the `RequiredFixtureSetDeclaration` coverage-equality check above are
  independent, both-mandatory gates: a candidate's own pool can be
  class-admitted (has >=1 POSITIVE and >=1 NEGATIVE) while still failing
  coverage (missing one specific required `fixtureId`), and vice versa is
  impossible by construction since every `requiredMembers` entry is itself
  either `POSITIVE` or `NEGATIVE`, so covering every required member always
  implies class admission.
- **Extra/unrequired fixtures:** an entry in `requiredFixtureEvidenceSet`
  whose `fixtureId` is not a member of the round's
  `RequiredFixtureSetDeclaration.requiredMembers` is an extra. Extras are
  permitted only if every one of them independently passes the same
  `gradeBehavioralEvaluation`/byte-binding bar named in the per-fixture bound
  requirement above; an extra can never substitute for a missing required
  member (coverage equality is computed over `requiredMembers` only, so an
  extra's presence or pass/fail status never changes the coverage result),
  and a failing extra does not itself block the candidate -- it is excluded
  from the candidate's admitted evidence and disclosed by ID -- provided the
  required subset (per the rule above) is fully covered and passing.
- **Ordering:** `requiredFixtureEvidenceSet` order is not semantically
  significant for admission (G3's admission check is set-based), but it is
  significant for `orderedEvidenceEnvelopeHashes` in provenance (see
  `## Canonical Provenance And Invalidation`), where entries are sorted by
  `fixtureId` ascending before hashing, so two callers supplying the same
  logical set in different array order produce an identical provenance
  preimage.
- **Malformed set:** an empty `requiredFixtureEvidenceSet`, a non-array
  value, or any entry failing structural validation makes the candidate
  `insufficient_evidence` with a named per-entry structural reason (mirrors
  the existing `validateEnvelopeStructure` pattern, extended per-entry
  instead of per-envelope).
- **Cross-candidate non-pooling is a mandatory decision-owner invariant,
  enforced by schema shape plus a required regression, not claimed as
  structurally impossible (per R1-RV-F2):** the schema shape makes the
  *evaluation inputs* per-candidate -- `admitFixtureSet`, the coverage-equality
  check, and the per-fixture bound requirement are all defined above to take
  only one candidate's own `requiredFixtureEvidenceSet` as input, never a
  round-level array of candidates -- but this document is a design schema,
  not executable code, and cannot itself prevent a future TypeScript
  implementation from ignoring the schema and hand-assembling a pooled array
  across candidate envelopes before calling `admitFixtureSet`, exactly as the
  R2-rejected implementation did. The closure this amendment provides is
  therefore two-part and mandatory, not optional: (1) the **decision-owner
  invariant**, stated here as a hard implementation rule -- the function that
  evaluates a candidate's admission and coverage MUST take a single
  candidate's `requiredFixtureEvidenceSet` as its only fixture-bearing
  parameter (never an array of candidates, never a round-level pool
  parameter), so that constructing a cross-candidate pool would require
  changing the function's own signature, a change `## Checker And Test
  Contract`'s mandatory `f1RegressionCrossCandidateAdmissionForbidden` test
  is required to catch; and (2) the mandatory regression test itself, which
  is the actual enforcement backstop a schema document can provide. A future
  implementation that violates the decision-owner invariant is a defect
  against this amendment, catchable by the mandatory regression test, not a
  possibility this schema document can unilaterally foreclose. This
  reconciles the review's `## Required Reopen Decision` item 1-2 demand for a
  binding closure without overclaiming what a documentation-only artifact can
  prove.

## GC-026 Authority Topology

### Problem This Closes

R2-RV-F2 (HIGH): the rejected implementation validated
`gc026Attestation.recordContentHash`/`recordContent` internal consistency
and matched `recordContent.taskClassId`/`candidateConfigHash` to the
accepted candidate, but never required the outer `promotionRecordRef`/
`promotedAt` fields to equal the hashed inner record's
`promotionRecordRef`/`promotedAt`. Probe evidence: changing the outer
`promotionRecordRef` to `"different-record"` and outer `promotedAt` to
`"2030-01-01T00:00:00Z"`, while leaving the hashed inner record unchanged,
still returned `ACCEPTED_PREFERRED` with a `CURRENT` regression binding.

### Chosen Topology

Per the work order's required choice between "the hashed attestation record
is the single source of promotion record/time" and "outer fields remain but
must exactly equal hashed inner fields," this amendment selects **the
hashed attestation record as the single source of truth**, and removes the
outer `promotionRecordRef`/`promotedAt` fields from
`PreferenceAuthorityDeclaration` entirely for the `GC026_PROMOTED_PERFORMANCE_REFERENCE`
kind.

Rationale: a same-value duplication rule (option 2) still leaves two places
that must be kept in sync by every future caller and every future
implementation; any future implementer who re-derives the equality check
loosely (as R2 did) reopens the identical class of defect. A single source
of truth removes the duplication surface structurally rather than relying on
an equality check that a future implementation might again omit. The
`ref` field (a free-text pointer, unrelated to the hashed content) is
retained unchanged, since it is not part of the finding.

### Amended Shape

```text
PreferenceAuthorityDeclaration (GC026 kind) = {
  kind: "GC026_PROMOTED_PERFORMANCE_REFERENCE"
  ref: string (non-empty)                          // unchanged: free-text pointer, not attested content
  valueByCandidateId: Record<candidateId, number>   // unchanged
  gc026Attestation: {
    registrySnapshotHash: canonicalHash
    recordContentHash: canonicalHash                // must equal recompute(recordContent) -- unchanged rule
    recordContent: {
      taskClassId: string                           // must equal the round's taskClassId -- unchanged rule
      candidateConfigHash: canonicalHash             // must equal the accepted candidate's -- unchanged rule
      promotionRecordRef: string (non-empty)         // SINGLE SOURCE OF TRUTH for the promotion reference
      promotedAt: string (non-empty, strict ISO-8601) // SINGLE SOURCE OF TRUTH for the promotion time
    }
  }
}
```

The top-level `promotionRecordRef`/`promotedAt` fields the rejected
implementation carried alongside `gc026Attestation` are removed for this
kind. `RegressionBinding.preferenceAuthorityRef` continues to be sourced
from `ref` (unchanged), and any consumer that needs the promotion record
identity or time reads `gc026Attestation.recordContent.promotionRecordRef`/
`promotedAt` exclusively -- there is no second field that could disagree.

### Registry-Snapshot Honesty Statement

`registrySnapshotHash` is a caller-supplied canonical hash. This schema, and
any pure/offline implementation of it, can verify only that
`registrySnapshotHash` is a well-formed 64-hex-character SHA-256 string and
that it is bound (see provenance below) into the accepted operating point's
provenance so a later change to the claimed snapshot invalidates the
binding. **This is not, and must never be described as, proof that a real
GC-026 registry entry exists or that the snapshot was genuinely read from a
live registry.** A shape-valid arbitrary hash satisfies this schema exactly
as well as a real one; verifying registry membership requires a real,
separately-governed registry lookup that is explicitly out of scope for a
pure/offline decision layer, consistent with how G3's fixture/trace grading
never contacts a real provider. Any future implementation's own claim
boundary must repeat this honesty statement verbatim or equivalently; no
future implementation may claim registry-membership proof from this schema
alone.

### Malformed / Missing / Contradictory Behavior

- Missing or structurally invalid `gc026Attestation` (any required field
  absent or wrong type): authority is inadmissible;
  `NO_ADMISSIBLE_PREFERENCE_EVIDENCE` for the round if this was the only
  declared authority.
- `recordContentHash` not equal to the recomputed hash of `recordContent`:
  inadmissible (unchanged rule from R2, restated here because it remains
  correct and load-bearing).
- `recordContent.taskClassId` not equal to the round's `taskClassId`, or
  `recordContent.candidateConfigHash` not equal to the accepted candidate's
  `candidateConfigHash`: inadmissible (unchanged rule from R2, restated).
- Because the outer duplicate fields no longer exist, an outer/inner
  contradiction is **structurally impossible** rather than merely rejected
  by an equality check -- directly satisfying Acceptance Criterion 4.

## Canonical Provenance And Invalidation

### Problem This Closes

R2-RV-F3 (HIGH): the rejected implementation's provenance preimage omitted
the T1 manifest's required `preferencePolicyHash` component and did not bind
actual trace identity, capture mode, or producer receipt identity. Probe
evidence: changing a supplied G3 trace's actual `traceId` (while leaving the
candidate's declared `traceIds` array unchanged) left provenance identical;
changing the winning GC-026 preference value from 42 to 999 also left
provenance identical.

### Amended Preimage (Versioned, Typed, Length/Domain-Separated)

The T1 manifest's formula --
`SHA-256(canonicalVersion | comparabilityFingerprint | acceptedCandidateId |
candidateConfigHash | orderedEvidenceEnvelopeHashes[] | preferencePolicyHash
| promotionEvidenceRefOrRubricHash)` -- is restated here as an explicit,
ordered, typed component list so a future implementation cannot silently
drop a component and still type-check:

```text
provenancePreimageComponents (in this exact order, pipe-joined, each
component itself length-prefixed as "<len>:<value>" before joining, to
guarantee unambiguous domain separation even if a component value itself
contains the pipe character):

1. canonicalVersion                - string, this schema's version literal
2. comparabilityFingerprint         - canonicalHash, the round's fingerprint
3. acceptedCandidateId              - string
4. candidateConfigHash              - canonicalHash, the accepted candidate's
5. orderedEvidenceEnvelopeHashes[]  - canonicalHash[], fully defined below
6. preferencePolicyHash             - canonicalHash (NEW: was omitted by the
                                       rejected implementation; REQUIRED)
7. promotionEvidenceRefOrRubricHash - canonicalHash:
                                       gc026Attestation.recordContentHash for
                                       GC026, or rubricVersionHash for the
                                       rubric kind (unchanged binding target,
                                       now unambiguous per kind)
8. acceptedCandidateReceiptHash     - canonicalHash (NEW), fully defined below
9. acceptedCandidateTraceBindingHash - canonicalHash (NEW), fully defined below
10. preferenceValueDigest           - canonicalHash (NEW), fully defined below
11. acceptedCandidateEligibilitySnapshotHash - canonicalHash (NEW), fully
                                       defined below (closes R1-RV-F4: binds
                                       provider-lane readiness and budget
                                       state into provenance)
```

### `orderedEvidenceEnvelopeHashes[]` (Redefined To Bind Full Envelope Identity, Closes Part Of R1-RV-F3)

For the accepted candidate, take every entry of its (already
coverage-verified, per `## Candidate-Scoped Evidence Set`)
`requiredFixtureEvidenceSet`, sort the entries by `fixtureId` ascending, and
for each sorted entry compute one envelope hash:

```text
evidenceEnvelopeHash = SHA-256(
  "1:" + len(fixtureId) + ":" + fixtureId + "|" +
  "1:" + len(fixtureClass) + ":" + fixtureClass + "|" +
  "1:" + len(fixtureContentHash) + ":" + fixtureContentHash + "|" +
  "1:" + len(g3ResultHash) + ":" + g3ResultHash
)
```

using the same length-prefixed, pipe-joined discipline as the outer preimage.
`orderedEvidenceEnvelopeHashes[]` is the ordered array of these per-entry
`evidenceEnvelopeHash` values, in `fixtureId`-ascending order. This directly
binds `fixtureId` and `fixtureClass` into the envelope hash itself (the
rejected implementation's flattened `(fixtureContentHash, g3ResultHash)` pair
named neither), and depends on the full candidate-scoped
`requiredFixtureEvidenceSet` rather than the single fixture the rejected
implementation used.

### `acceptedCandidateReceiptHash` (Fully Specified, Closes Part Of R1-RV-F3)

Exact fields, in this fixed order, one instance per `requiredFixtureEvidenceSet`
entry sorted by `fixtureId` ascending (same ordering as
`orderedEvidenceEnvelopeHashes[]`, so both are derived from one canonical
sort): `receiptRef`, `candidateId`, `candidateConfigHash`, then `traceIds`
itself sorted ascending and joined with `,` (a receipt's own `traceIds` array
has no independent significance beyond membership, so it is normalized by
sort before hashing). Each of the four fields/sub-values is length-prefixed
`"<len>:<value>"` as above; per-entry tuples are pipe-joined in fixtureId
order; entries are pipe-joined into one preimage and hashed once:

```text
acceptedCandidateReceiptHash = SHA-256(
  join("|", for each requiredFixtureEvidenceSet entry sorted by fixtureId:
    join("|",
      "1:" + len(receiptRef) + ":" + receiptRef,
      "1:" + len(candidateId) + ":" + candidateId,
      "1:" + len(candidateConfigHash) + ":" + candidateConfigHash,
      "1:" + len(sortedTraceIdsJoined) + ":" + sortedTraceIdsJoined
    )
  )
)
```

Duplicate behavior: if two `requiredFixtureEvidenceSet` entries carry
identical `producerReceipt` content, both still contribute their own
per-entry tuple in `fixtureId` order (receipts are not deduplicated across
entries), because the hash's purpose is to bind exactly which entries
produced which receipts, not merely which distinct receipts exist.

### `acceptedCandidateTraceBindingHash` (Fully Specified, Closes Part Of R1-RV-F3)

For each `requiredFixtureEvidenceSet` entry (sorted by `fixtureId` ascending,
same canonical sort as above), and within that entry for each of its
`traceIds`/`traceContentHashes`/`traceCaptureModes` triples taken **in
declared array order** (trace order within one fixture's own declared arrays
is semantically significant, since `traceIds[i]`/`traceContentHashes[i]`/
`traceCaptureModes[i]` are positionally paired and re-sorting them would not
be meaningful without also re-sorting the pairing), form one length-prefixed,
pipe-joined `(traceId, traceCaptureMode, traceContentHash)` tuple:

```text
acceptedCandidateTraceBindingHash = SHA-256(
  join("|", for each requiredFixtureEvidenceSet entry sorted by fixtureId:
    join("|", for each trace index i in declared array order:
      join("|",
        "1:" + len(traceIds[i]) + ":" + traceIds[i],
        "1:" + len(traceCaptureModes[i]) + ":" + traceCaptureModes[i],
        "1:" + len(traceContentHashes[i]) + ":" + traceContentHashes[i]
      )
    )
  )
)
```

This is the direct fix for the review's "changing a supplied G3 trace ID ...
provenance identical" probe: because actual trace identity and capture mode
are now hashed into provenance in a fully specified order, any trace
substitution that is not reflected in the candidate's declared
`traceIds`/`traceContentHashes`/`traceCaptureModes` either fails the existing
R1 binding cross-check (declared vs. actual mismatch = `insufficient_evidence`)
or, if the substitution is consistent end-to-end, changes the resulting
provenance -- so a real substitution can never leave provenance identical
while remaining accepted.

### `preferenceValueDigest` (Fully Specified, Closes Part Of R1-RV-F3)

The accepted candidate's numeric preference value (`valueByCandidateId[acceptedCandidateId]`
from the admissible `PreferenceAuthorityDeclaration`) is normalized to a
canonical decimal string before hashing, using this exact rule: reject
non-finite values (`NaN`, `Infinity`, `-Infinity`) as a structural validation
failure (`insufficient_evidence`, never hashed); reject exponent-form input
by requiring plain decimal notation; normalize `-0` to `0`; represent the
value with no trailing zeroes after the decimal point and no leading zeroes
before it (other than a single `0` for values with magnitude less than 1),
and no trailing decimal point for whole numbers (e.g. `42` not `42.0` or
`42.00`); a leading `-` is retained for negative values, with the same
normalization otherwise applied to the magnitude. `preferenceValueDigest` is
`SHA-256("1:" + len(normalizedDecimalString) + ":" + normalizedDecimalString)`.
This is the direct fix for the review's "changing the winning score from 42
to 999 ... provenance identical" probe: the accepted candidate's numeric
preference value is now a required, exactly normalized, hashed preimage
component, so any two textual representations of the same numeric value
(`42`, `42.0`, `4.2e1`, all rejected or normalized per the rule above) can
never produce two different valid digests for the same underlying value, and
two different values can never collide into the same normalized string.

### `acceptedCandidateEligibilitySnapshotHash` (Fully Specified, Closes R1-RV-F4)

R1-RV-F4 correctly found that Acceptance Criterion 5 requires **every**
declared invalidation trigger to map to provenance-bound content, but two
triggers (`accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum`,
`accepted_candidate_budget_ceiling_lowered_below_recorded_consumption`) were
left as "eligibility re-evaluation, not provenance-hashed" with no
accompanying provenance-bound representation at all -- self-assessed as PASS
without one. This amendment adds one new preimage component that resolves
the apparent conflict between "provenance-bound" (criterion 5) and "readiness
and budget must be re-checked live, never frozen into a stale hash" (the
unchanged T1 design rule the audit's earlier text correctly protects): the
component is a **snapshot digest**, not a frozen authority. It proves that a
specific readiness/budget state was observed at accept-time and makes any
retroactive claim that a different state was observed at that moment
detectable, without ever being consulted as authority for a live
re-evaluation.

```text
acceptedCandidateEligibilitySnapshotHash = SHA-256(
  "1:" + len(providerLaneStatus) + ":" + providerLaneStatus + "|" +
  "1:" + len(budgetCeilingCanonicalDecimal) + ":" + budgetCeilingCanonicalDecimal + "|" +
  "1:" + len(budgetConsumedCanonicalDecimal) + ":" + budgetConsumedCanonicalDecimal
)
```

`providerLaneStatus` is the accepted candidate's own field (unchanged T1
type). `budgetCeilingCanonicalDecimal`/`budgetConsumedCanonicalDecimal` are
the accepted candidate's `budgetCeiling`/`budgetConsumed` fields (unchanged
T1 fields), each normalized by the identical canonical-decimal rule defined
above for `preferenceValueDigest` (no exponent form, no `-0`, no trailing/
leading zero noise).

**Claim boundary for this component (critical to avoid reopening the
freezing concern this amendment must not create):** this hash proves only
that this exact `(providerLaneStatus, budgetCeiling, budgetConsumed)` triple
was the one bound into provenance at accept-time; it is a tamper-evidence and
audit-trail mechanism, never an eligibility authority. Live readiness and
budget checks continue to be evaluated fresh at every re-evaluation, exactly
as the unchanged T1 rule requires (`providerLaneStatus`/budget fields remain
eligibility gates checked against current live/operator-supplied state, not
against this hash); this hash is never compared against a "current" value to
decide eligibility, only used after the fact to prove or disprove that the
recorded state at accept-time matches what is now claimed to have been
recorded.

### Invalidation Trigger Mapping (Every Trigger Bound To Provenance-Relevant Content)

The T1 manifest's six invalidation triggers are unchanged in name and intent.
This amendment maps each to the exact amended field(s) whose change now
provably alters provenance or the binding's validity, closing Acceptance
Criterion 5:

| Invalidation trigger (T1, unchanged) | Bound field(s) under this amendment |
|---|---|
| `fixture_set_content_hash_changes_for_bound_task_class` | `comparabilityFingerprint`'s `fixtureSetContentHash` component (unchanged binding, now also indirectly covers every entry's `fixtureContentHash` via `orderedEvidenceEnvelopeHashes`) |
| `candidate_config_or_bound_trace_result_or_producer_receipt_changes` | `candidateConfigHash`, `orderedEvidenceEnvelopeHashes[]`, `acceptedCandidateReceiptHash`, `acceptedCandidateTraceBindingHash` (three of these four are new components that did not exist in the rejected implementation) |
| `partition_rubric_environment_policy_acceptance_or_preference_policy_changes` | `comparabilityFingerprint`'s constituent fields, plus the NEW `preferencePolicyHash` component |
| `accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum` | `acceptedCandidateEligibilitySnapshotHash`'s `providerLaneStatus` component (NEW: proves the accept-time readiness value; live re-evaluation remains the actual eligibility gate and is never overridden by this hash, per its claim boundary above) |
| `gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence` | `promotionEvidenceRefOrRubricHash` (now unambiguously `gc026Attestation.recordContentHash`, the single source of truth per `## GC-026 Authority Topology`) |
| `accepted_candidate_budget_ceiling_lowered_below_recorded_consumption` | `acceptedCandidateEligibilitySnapshotHash`'s `budgetCeiling`/`budgetConsumed` components (NEW: proves the accept-time budget state; live re-evaluation against current `budgetCeiling` remains the actual eligibility gate and is never overridden by this hash, per its claim boundary above) |

## Checker And Test Contract

### Problem This Closes

R2-RV-F4 (MEDIUM): the Python checker mirrored the incomplete GC-026 outer/
inner binding and checked provenance shape (non-empty string) rather than
recomputing the accepted design's formula, so a machine `PASS` from the
checker could not close F2 or F3 (checker lines 293-430, 424-487).

### Per-Edge Owner Table

For every equality, membership, coverage, and preimage edge this amendment
introduces or restates, this table states whether the TypeScript decision
owner, the Python persisted-evidence checker, or both enforce it, and the
exact fail behavior. `BOTH_INDEPENDENT` means the Python checker
independently recomputes the same value from the same inputs rather than
trusting a TypeScript-computed field -- this is the literal fix for F4.

| Edge | Owner | Mandatory path | Bypass behavior | Fail result |
|---|---|---|---|---|
| Candidate-scoped `admitFixtureSet` (per candidate, never pooled) | TypeScript only (decision-time; not persisted-document-checkable without re-running G3 grading, which the Python checker does not do) | every candidate decision | none; always evaluated per candidate | `insufficient_evidence` for that candidate |
| `RequiredFixtureSetDeclaration.fixtureSetContentHash == recompute(sort(requiredMembers) then hash)` | `BOTH_INDEPENDENT`: TypeScript computes and checks it at decision time; Python checker independently recomputes from the persisted `requiredMembers` list | every round using this schema | none | non-empty violation naming the mismatch |
| Candidate `requiredFixtureEvidenceSet` covers `RequiredFixtureSetDeclaration.requiredMembers` (coverage-equality, closes R1-RV-F1) | TypeScript (decision-time; requires the live `RequiredFixtureSetDeclaration` as input, which the Python checker treats as a declared, hashed, persisted sibling field rather than re-deriving) | every candidate decision | none | `insufficient_evidence` for that candidate, naming uncovered `fixtureId`(s) |
| Every `requiredFixtureEvidenceSet` entry reaches `PASS_WITH_EVIDENCE` | TypeScript (decision-time) | every candidate decision | none | `insufficient_evidence` for that candidate |
| `orderedEvidenceEnvelopeHashes[]` content and ordering | `BOTH_INDEPENDENT`: TypeScript computes it at decision time; Python checker recomputes it from a supplied `requiredFixtureEvidenceSet` snapshot (see `## Migration / Successor Boundary` for the schema field the checker will read) and rejects if the persisted value disagrees | `ACCEPTED_PREFERRED` assessments with an attached evidence-set snapshot | none for a document declaring the snapshot; a document with no snapshot cannot claim this edge is closed and the checker records `PROVENANCE_RECOMPUTATION_UNAVAILABLE_NO_SNAPSHOT` rather than a false pass | non-empty violation naming the mismatch, or the explicit unavailable marker |
| `gc026Attestation.recordContentHash == recompute(recordContent)` | `BOTH_INDEPENDENT` (unchanged from R2, restated) | any `ACCEPTED_PREFERRED` claiming GC-026 authority | none | non-empty violation |
| `recordContent.taskClassId`/`candidateConfigHash` match accepted candidate | `BOTH_INDEPENDENT` (unchanged from R2, restated) | same | none | non-empty violation |
| Outer `promotionRecordRef`/`promotedAt` equal inner (F2) | `STRUCTURALLY_ELIMINATED`: the outer fields no longer exist in the schema (see `## GC-026 Authority Topology`), so there is nothing left to check for disagreement; the checker instead validates that no outer duplicate fields are present, and rejects a document that still carries them as a schema-version violation | any GC-026 document | none | non-empty violation naming the forbidden legacy field |
| `preferencePolicyHash` present and non-zero-length in preimage inputs | `BOTH_INDEPENDENT`: TypeScript includes it in the hashed preimage; Python checker requires the persisted document to declare `preferencePolicyHash` as a sibling field and rejects an `ACCEPTED_PREFERRED` document that omits it | any `ACCEPTED_PREFERRED` | none | non-empty violation |
| `acceptedCandidateReceiptHash`, `acceptedCandidateTraceBindingHash`, `preferenceValueDigest`, `acceptedCandidateEligibilitySnapshotHash` present in preimage inputs | `BOTH_INDEPENDENT`, same pattern as `preferencePolicyHash` | any `ACCEPTED_PREFERRED` | none | non-empty violation naming the missing component |
| `provenanceFingerprint == recompute(all eleven preimage components)` | `BOTH_INDEPENDENT`: this is the header-level fix for F4 -- the Python checker moves from "is this a non-empty string" to "recompute the exact SHA-256 over the declared components and compare," the same way it already does for `gc026Attestation.recordContentHash` | any `ACCEPTED_PREFERRED` | none | non-empty violation naming the mismatch |
| `RegressionBinding.invalidationStatus == CURRENT` requires non-empty `boundAt` | unchanged from R1 (already `BOTH_INDEPENDENT` in the rejected checker) | any `RegressionBinding` claiming `CURRENT` | none | non-empty violation |

### Positive Controls And Negative Cases Required Of Any Future Implementation

A future implementation of this schema must include, at minimum, tests that
independently reproduce and now reject every R2 probe:

1. **Positive control:** a single candidate whose `requiredFixtureEvidenceSet`
   contains its own POSITIVE and NEGATIVE fixtures, both bound
   `PASS_WITH_EVIDENCE`, reaches `preferred` under an admissible authority.
2. **F1 regression (mandatory):** a round with candidate A (POSITIVE only,
   own set) and candidate B (NEGATIVE only, own set) must **never** produce
   a `preferred` candidate from either A's or B's set alone; each fails
   closed to `insufficient_evidence` with its own missing-class reason. A
   test fixture may not manufacture admission by appending evidence from
   another candidate -- any test helper that does so is itself a defect
   under this amendment, not an acceptable positive-control pattern.
3. **F2 regression (mandatory):** an attempt to construct a
   `PreferenceAuthorityDeclaration` with a duplicate top-level
   `promotionRecordRef`/`promotedAt` alongside `gc026Attestation` must fail
   to type/structurally-validate (the fields do not exist in the schema);
   a document carrying them anyway must be rejected by the checker as a
   forbidden legacy field, not silently ignored.
4. **F3 regression (mandatory):** changing only the actual supplied trace's
   `traceId` (with declared `traceIds` inconsistently left unchanged) must
   fail the existing binding cross-check to `insufficient_evidence`;
   changing the trace consistently (declared and actual together) must
   change `acceptedCandidateTraceBindingHash` and therefore
   `provenanceFingerprint`. Changing the accepted candidate's preference
   value must change `preferenceValueDigest` and therefore
   `provenanceFingerprint`.
5. **F4 regression (mandatory):** a persisted `OperatingPointAssessment`
   document with a `provenanceFingerprint` that does not match the
   independently recomputed value over its own declared components must be
   rejected by the Python checker with a non-empty violation, not silently
   passed.
6. **R1-RV-F1 coverage regression (mandatory):** a candidate whose
   `requiredFixtureEvidenceSet` passes `admitFixtureSet`'s class-composition
   check (has >=1 `POSITIVE` and >=1 `NEGATIVE`) but is missing one specific
   required `fixtureId` from `RequiredFixtureSetDeclaration.requiredMembers`
   must still fail to `insufficient_evidence` with `MISSING_REQUIRED_FIXTURE`
   naming that `fixtureId` -- class admission alone must never be treated as
   sufficient coverage.
7. **R1-RV-F4 eligibility-snapshot regression (mandatory):** changing an
   accepted candidate's `providerLaneStatus`, `budgetCeiling`, or
   `budgetConsumed` after acceptance (without a fresh accept-time
   recomputation) must change `acceptedCandidateEligibilitySnapshotHash` and
   therefore `provenanceFingerprint`; and this hash must never itself be
   consulted to decide current eligibility during a fresh live
   re-evaluation, which must always use the then-current
   `providerLaneStatus`/`budgetCeiling`/`budgetConsumed` values, not this
   snapshot.

## Migration / Successor Boundary

| Rejected path | Disposition | Reason | Named future successor path |
|---|---|---|---|
| `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/task.class.calibration.owner.contract.ts` | `DISCARD_WITH_REASON` | The single-fixture-per-candidate envelope shape is incompatible with `requiredFixtureEvidenceSet`; the GC-026 outer/inner duplicate fields must be removed, not patched; the provenance preimage gains new required components including a new round-scoped `RequiredFixtureSetDeclaration` coverage input. These are structural shape changes, not isolated line edits, so in-place repair is unsafe and was explicitly rejected by the R2 review's `## Required Reopen Decision`. | `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/task.class.calibration.owner.contract.ts` (same path, entirely new implementation authored under a future separate work order; this amendment does not author it) |
| `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/tests/task.class.calibration.owner.contract.test.ts` | `DISCARD_WITH_REASON` | Every fixture builder in this file assumes the single-fixture shape and the cross-candidate companion pattern this amendment forbids; reusing any of it would reintroduce F1 into new tests. | same path, entirely new test suite authored against `## Checker And Test Contract` above |
| `governance/compat/check_task_class_calibration_owner_evidence.py` | `REUSE_AFTER_EXACT_CHANGE` | The existing hash-recomputation pattern (`_recompute_gc026_record_content_hash`, the `_is_canonical_hash` helper, the `_declares_contract` schema-marker gate) is structurally sound and should be extended, not replaced: add `orderedEvidenceEnvelopeHashes[]`/`provenanceFingerprint` full recomputation, remove the outer-GC026-field tolerance, and add the `preferencePolicyHash`/`acceptedCandidateReceiptHash`/`acceptedCandidateTraceBindingHash`/`preferenceValueDigest` presence checks. | same path, patched under a future implementation work order |
| `governance/compat/test_check_task_class_calibration_owner_evidence.py` | `REUSE_AFTER_EXACT_CHANGE` | Same reasoning as the checker: the hermetic-fixture test pattern is sound; new fixtures are needed for the amended fields. | same path, extended under a future implementation work order |
| `docs/reference/agent_system_skills/CVF_TASK_CLASS_CALIBRATION_OWNER_CONTRACT.md` | `REPLACE_IN_SEPARATE_IMPLEMENTATION` | The normative contract doc must describe the amended schema (candidate-scoped evidence set, single-source GC-026, eleven-component provenance preimage), which is a substantial rewrite this design tranche does not author (out of the three-path Required Artifact Manifest). | same path, rewritten under a future implementation work order to match this amendment |
| `docs/audits/CVF_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md` | `DISCARD_WITH_REASON` | This audit documents the rejected R1/R2 implementation's now-superseded design; a future implementation work order will author a fresh audit against this amendment rather than continuing R1/R2's document. | `docs/audits/CVF_ACEL_G1_T2B_..._IMPLEMENTATION_<date>.md` (exact future batch ID not yet assigned; naming is Local's dispatch decision) |
| `docs/reviews/CVF_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_WORKER_RETURN_2026-09-17.md` | `DISCARD_WITH_REASON` | Same reasoning: this is the rejected worker's own self-report, superseded by the R2 independent review's rejection; a future implementation authors a fresh worker return. | `docs/reviews/CVF_ACEL_G1_T2B_..._WORKER_RETURN_<date>.md` (exact future batch ID not yet assigned) |

None of the seven rejected paths is modified, staged, or committed by this
amendment. All seven remain exactly as R2 left them, uncommitted and parked,
pending the Local-selected future implementation work order this table names
as their successor.

## Findings / Position

This amendment closes all four review findings by direct schema change, not
by documentation-only reinterpretation:

- **R2-RV-F1** is closed by a required, non-empty, candidate-scoped
  `requiredFixtureEvidenceSet` plus a new authoritative
  `RequiredFixtureSetDeclaration` coverage-equality gate (see `## Required
  Fixture-Set Authority` above), enforced as a mandatory decision-owner
  invariant and mandatory regression test
  (`f1RegressionCrossCandidateAdmissionForbidden`) rather than claimed as
  structurally impossible for a schema document to guarantee alone (R1-RV-F2
  correction).
- **R2-RV-F2** is closed structurally: the outer `promotionRecordRef`/
  `promotedAt` fields that could disagree with the hashed inner record no
  longer exist in the schema; there is exactly one source of truth.
- **R2-RV-F3** is closed by an explicit, versioned, eleven-component preimage
  that includes the previously-omitted `preferencePolicyHash` plus three new
  required components (`acceptedCandidateReceiptHash`,
  `acceptedCandidateTraceBindingHash`, `preferenceValueDigest`) that
  directly bind the exact identities the review's probes mutated. A fourth
  new component, `acceptedCandidateEligibilitySnapshotHash`, closes
  R1-RV-F4's separate finding that provider-lane readiness and budget
  invalidation triggers had no provenance-bound representation at all (see
  `## Canonical Provenance And Invalidation`'s eligibility-snapshot
  subsection and the invalidation trigger mapping table).
- **R2-RV-F4** is closed by moving every provenance/attestation edge from
  Python-side shape-checking to `BOTH_INDEPENDENT` recomputation, so a
  machine `PASS` from the checker now requires the persisted document's
  hashed values to actually match independent recomputation, not merely be
  present and well-formed.

No accepted T1 design rule outside these four findings is altered: decision
state precedence (`incomparable` > `insufficient_evidence` > `ineligible` >
`eligible_nonpreferred`/`preferred`), the SEARCH/HELD_OUT contamination
rule, G3 repeat-policy semantics (1 for DETERMINISTIC, 3 for STOCHASTIC),
readiness-as-eligibility-gate-only, and the no-score-laundering invariant are
all unchanged and are not affected by this amendment's field-level changes.

## Deviations From The Accepted T1 Design (Disclosed)

1. **`candidateEvidenceBinding.requiredFields` is superseded, not merely
   extended.** The T1 manifest's single-fixture field list
   (`fixtureId`, `fixtureContentHash`, `traceIds`, `traceContentHashes`,
   `traceCaptureModes`, `g3ResultHash`) is replaced by
   `requiredFixtureEvidenceSet[]`, each entry carrying that same field
   shape. This is a necessary consequence of closing F1 per the review's
   `## Required Reopen Decision` item 1, which explicitly asks whether a
   candidate envelope should contain "a fixture-result collection" -- this
   amendment answers yes.
2. **`provenanceFingerprint`'s formula gains four components beyond the T1
   manifest's literal six-component list**
   (`acceptedCandidateReceiptHash`, `acceptedCandidateTraceBindingHash`,
   `preferenceValueDigest`, `acceptedCandidateEligibilitySnapshotHash`),
   while restoring the one component the T1 formula already named but the
   rejected implementation omitted (`preferencePolicyHash`). This is
   disclosed as an amendment, not a silent reinterpretation, because the R2
   review's `## Required Reopen Decision` item 4 explicitly asks for "the
   complete canonical provenance preimage, including preference policy,
   evidence-envelope identity, receipt identity, trace identity/capture
   mode, and deterministic ordering" -- three of the four new components map
   to those named gaps, and the fourth (`acceptedCandidateEligibilitySnapshotHash`)
   is a direct response to the R1 independent review's separate finding
   (R1-RV-F4) that provider-lane readiness and budget invalidation triggers
   had no provenance-bound representation at all.
3. **GC-026's outer `promotionRecordRef`/`promotedAt` fields are removed**
   from `PreferenceAuthorityDeclaration`, where R1/R2 had them present
   alongside `gc026Attestation`. This is the direct, disclosed consequence
   of choosing "single source of truth" over "duplicate with equality
   constraint" per the work order's required either/or choice.
4. **A new round-level artifact, `RequiredFixtureSetDeclaration`, is
   introduced.** The T1 manifest never named a distinct required-fixture-set
   descriptor object; it only carried `comparabilityFingerprint.fixtureSetContentHash`
   as an opaque hash with no accompanying member-identity list. This
   amendment adds `requiredMembers` (the explicit, canonical, per-member
   identity list) alongside a `fixtureSetContentHash` that is now defined as
   `recompute(sort(requiredMembers) then hash)`, so the existing T1 hash
   component gains an explicit, independently recomputable definition rather
   than remaining caller-asserted. This is a direct, disclosed response to
   R1-RV-F1's finding that no required-set authority or exact coverage
   comparison existed; it does not change the existing
   `comparabilityFingerprint` formula or field list, only defines what
   `fixtureSetContentHash` is computed over.

No other deviation from the accepted T1 design is introduced by this
amendment.

## Risk / Corrective Action

| Risk | Mitigation | Residual |
|---|---|---|
| A future implementer could reintroduce cross-candidate pooling by evaluating `admitFixtureSet` at the round level again, exactly as R2 did | This amendment names the structural rule explicitly ("evaluated exclusively within one candidate's own set") and requires the F1 regression test named in `## Checker And Test Contract` as mandatory, not optional | Accepted: a schema document alone cannot force a future implementer's code structure; the mandatory regression test is the enforcement backstop, and Local review remains required before any future implementation is accepted |
| `registrySnapshotHash`/`gc026Attestation` still cannot prove a real GC-026 registry entry exists, only internal document consistency | Explicit honesty statement added in `## GC-026 Authority Topology`, required to be repeated by any future implementation's own claim boundary | Accepted: proving real registry membership requires a separately-governed live lookup, explicitly out of scope for a pure/offline decision layer, consistent with G3's own never-contacts-a-real-provider posture |
| The eleven-component provenance preimage is more complex than the T1 manifest's six-component formula, raising future implementation and review cost | Justified component-by-component against a specific named review probe or T1 manifest gap in `## Canonical Provenance And Invalidation`; no component is speculative or added without a named reason | Accepted: complexity here is the direct, minimal closure of four independently reproduced acceptance-blocking findings, not speculative hardening |
| This amendment cannot itself prove a future implementation will correctly realize it; only Local review of that future implementation can | Every design rule states machine-checkable pass/fail behavior precisely enough that `## Checker And Test Contract` can be authored directly from this document without further Claude context, per the work order's independent-implementability requirement | Accepted: this is a design artifact; implementation correctness proof is out of scope for this tranche and remains a future, separately-reviewed work order |

## Decision / Disposition

`WORKER_COMPLETE_PENDING_REVIEW`. This amendment maps all four R2-RV
findings to structural schema rules and at least one mandatory future
regression test each, resolves the GC-026 topology choice the work order
required, and states an explicit, ordered, typed provenance preimage. All
seven frozen rejected paths were read-only throughout; their SHA-256 hashes
are reconciled unchanged in the paired worker return. No implementation,
provider/live, runtime, configuration-mutation, G4, public-sync, or
deployment claim is made. Local review and acceptance remain a separate,
later step.

## Public Export Disposition

DEFERRED_PRIVATE_ONLY

Reason: this audit references private CVF provenance architecture, a
rejected implementation's exact source lines, and repository-internal review
findings; public-safe export requires separate redaction and public-sync
authorization.

## Claim Boundary

This audit records a schema/design amendment only. It does not implement,
test, execute, or accept any TypeScript/Python code; does not modify,
stage, or commit any of the seven frozen rejected G1 T2 paths; and does not
authorize provider/live execution, real calibration, configuration
mutation, G4, runtime wiring, public sync, or deployment. Local review and
a separate future implementation work order are required before any of the
rules in this document take effect in running code.
