# CVF ACEL G1 T2B Calibration Root Contract Architecture Reassessment

Memory class: governed-implementation-audit

docType: audit

Status: WORKER_COMPLETE_PENDING_REVIEW

Batch ID: ACEL-G1-T2B-CALIBRATION-ROOT-CONTRACT-ARCHITECTURE-REASSESSMENT

EPISTEMIC_PROCESS_NA_WITH_REASON: this audit designs a fresh root contract
from four Local-selected architecture decisions; it does not run or test an
implementation, so no new empirical hypothesis is evaluated here. Every
design rule below is derived either from the Local architecture decision it
implements or from a named R2-RV-F1 through F4 finding it must not repeat.

## Purpose

Design a fresh, independently implementable G1 calibration root contract
from the four architecture decisions Local selected in
`docs/baselines/CVF_GC018_ACEL_G1_T2B_CALIBRATION_ROOT_CONTRACT_ARCHITECTURE_REASSESSMENT_2026-09-17.md`,
after `docs/reviews/CVF_ACEL_G1_T2A_CANDIDATE_EVIDENCE_BINDING_SCHEMA_AMENDMENT_R2_INDEPENDENT_REVIEW_2026-09-17.md`
terminally rejected the T2A topology and reached
`STOP_REASSESS_ARCHITECTURE`. This is a fresh tranche, not a repair of the
three rejected T2A artifacts, which remain parked, unmodified, uncommitted
evidence. This is a schema/design artifact only. It does not implement,
test, execute, or accept any TypeScript/Python code, and it authorizes no
provider/live execution, real calibration, configuration mutation, runtime
wiring, G4 work, public sync, or deployment.

## Target / Source

| Target | Path | Role |
|---|---|---|
| Governing work order | `docs/work_orders/CVF_AGENT_WORK_ORDER_ACEL_G1_T2B_CALIBRATION_ROOT_CONTRACT_ARCHITECTURE_REASSESSMENT_2026-09-17.md` | authorizes exactly three fresh outputs and states the four fixed architecture decisions |
| Governing baseline | `docs/baselines/CVF_GC018_ACEL_G1_T2B_CALIBRATION_ROOT_CONTRACT_ARCHITECTURE_REASSESSMENT_2026-09-17.md` | source of the four Local architecture decisions this contract must implement without an alternative topology |
| Terminal rejection authority | `docs/reviews/CVF_ACEL_G1_T2A_CANDIDATE_EVIDENCE_BINDING_SCHEMA_AMENDMENT_R2_INDEPENDENT_REVIEW_2026-09-17.md` | names R2-RV-F1 through F4, the exact defects this contract must not repeat |
| Unchanged design authority (predecessor evidence, not implementation authority) | `docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json` | source of every accepted rule not superseded by this reassessment (decision states/precedence, SEARCH/HELD_OUT contamination rule, repeat semantics, invalidation-trigger names) |
| Canonicalization pattern evidence (adapted, not owned) | `docs/reference/sot_three_layer/CVF_SOT_THREE_LAYER_INVARIANTS_AND_NEGATIVE_CASES.md` | Invariant 5/NC-05 source-backed JCS canonical-hash-with-test-vector pattern; this contract adapts the pattern under a new G1-owned profile identifier and does not claim SOT3 profile ownership |
| Parked rejected T2A design (read-only, never edited by this tranche) | `docs/audits/CVF_ACEL_G1_T2A_CANDIDATE_EVIDENCE_BINDING_SCHEMA_AMENDMENT_2026-09-17.md` | evidence of exactly how R2-RV-F1 through F4 occurred; cited by line, never reused as a base to edit |
| This contract's machine twin | `docs/audits/CVF_ACEL_G1_T2B_CALIBRATION_ROOT_CONTRACT_ARCHITECTURE_REASSESSMENT_MANIFEST_2026-09-17.json` | exact schema, fields, canonicalization vectors and self-check |

## Scope / Methodology

Read the T2B work order and GC-018 baseline in full, the T2A R2 independent
review in full (Findings/Position, Accepted Returned Evidence, Acceptance
Resolution, Architecture Reassessment Requirement), the accepted T1
manifest's `candidateEvidenceBinding`, `searchHeldoutPartition`,
`comparabilityFingerprint`, `eligibilityBeforePreferencePolicy`,
`provenanceFingerprint`, `invalidationTriggers`, `invalidationAction`,
`regressionBindingSchema`, `decisionStates` and `negativeCases` sections via
direct JSON field extraction (not paraphrase), and
`docs/reference/sot_three_layer/CVF_SOT_THREE_LAYER_INVARIANTS_AND_NEGATIVE_CASES.md`
Invariant 5 and NC-05 in full. Recomputed the SHA-256 of all ten parked
paths at execution start; all ten matched the work order's Parked Evidence
Freeze table exactly. No parked path was edited. Every design rule below
either implements one of the four Local architecture decisions verbatim
(refining field names only, per the baseline's explicit allowance) or closes
one named R2-RV finding by tracing it to its exact root and eliminating the
root cause, not merely adding a test around it.

## Root Cause Analysis: Why R2-RV-F1 Through F4 Recur Unless Structurally Eliminated

R2-RV-F1 recurred because the T2A repair renamed the required-set concept
(`RequiredFixtureSetDeclaration`) without ever naming a single authoritative
**owner** for it, and without binding it to the partition/comparability
identity that actually determines which fixtures are eligible held-out
evidence in the first place. A descriptor with no named issuer and no
partition binding can always be reinterpreted as "whatever the candidate's
own evaluation code currently reads," which is the same authority gap R1 and
R2 both found in different forms. This contract closes the root by defining
`HeldOutFixtureSetAuthority` as a single immutable object with one named
issuer (the calibration-round decision owner, never a candidate), issued
strictly before candidate evaluation begins, and binding partition identity
directly into the object's own hash -- so "who created this" and "which
partition does it certify" are answered by the object itself, not by
narrative.

R2-RV-F2 recurred because every previous version of this contract line
(T1's `SHA-256(a | b | c | ...)`, T2A's per-field length-prefixed
pipe-joining, T2A's `traceIds.join(",")` receipt digest) invented its own
ad hoc serialization rule per hash, and each ad hoc rule left at least one
edge (list ordering, delimiter-shaped values, nested object serialization)
underspecified or exploitable. A concrete collision was demonstrated:
`['a,b','c']` and `['a','b,c']` both join to the string `"a,b,c"`. This
contract closes the root by defining exactly **one** reusable typed
canonical serialization primitive, used for every hash in this document
without exception, modeled on the SOT3 Invariant 5 pattern (real RFC 8785
JCS canonical JSON over a typed object, not string-joining of raw values)
and owned under a new G1-specific profile identifier.

R2-RV-F3 recurred because both T1 and T2A treated "acceptance" as a single
mutable-in-spirit record: T2A's `acceptedCandidateEligibilitySnapshotHash`
tried to make a later readiness/budget change "provenance-bound" by hashing
a snapshot into the *original* acceptance fingerprint, which cannot work --
an immutable historical hash cannot detect a change that happens after it
was computed, and the T2A document said so explicitly while also claiming
every invalidation trigger was provenance-bound, which is self-contradictory.
This contract closes the root by never trying to make a historical
fingerprint detect the future. Acceptance provenance
(`OperatingPointAcceptanceBinding`) is created once, is immutable, and is
never queried against current state. A separate, append-only
`OperatingPointInvalidationReceipt` chain is the only thing that ever
compares an accepted binding against a later observation; current validity
is a derived read over the latest receipt, never a mutation of history.

## Selected Architecture Decision 1: HeldOutFixtureSetAuthority

### Local Decision (Verbatim Binding, Field Names Refined)

Per GC-018's Architecture Decision table, row "Fixture authority": an
immutable `HeldOutFixtureSetAuthority` issued before candidate evaluation by
the calibration-round decision owner; binds task class, partition/
comparability identity, exact required members and authority hash; each
candidate references the exact hash. Candidate-authored or hash-only fixture
declaration is the rejected alternative and is not implemented here.

### Schema

```text
HeldOutFixtureSetAuthority = {
  authorityId: string (non-empty, unique per issuance)
  issuedBy: "CALIBRATION_ROUND_DECISION_OWNER"  // fixed literal; CLAIMED role only, see "Issuer attestation" below for the independent check
  issuerAttestationRef: {                       // see "Issuer attestation" below for full definition and honesty statement
    registrySnapshotHash: canonicalHash          // decision-owner identity registry snapshot (same pattern class as GC-026's)
    attestedIssuerIdentity: string (non-empty)   // registry entry ID this attestation names as issuer
    attestationContentHash: canonicalHash        // SHA-256 of {registrySnapshotHash, attestedIssuerIdentity, authorityId, issuedAtUtc}
  }
  issuedAtUtc: string (ISO 8601 UTC, "YYYY-MM-DDTHH:MM:SSZ")
  taskClassId: string (non-empty)
  partitionId: string (non-empty)                // SEARCH/HELD_OUT ledger identity (closes R2-RV-F1's missing partition binding)
  comparabilityFingerprint: canonicalHash        // round's T1-formula fingerprint; binds one exact comparability context
  requiredMembers: Array<{
    fixtureId: string (non-empty)
    fixtureClass: "POSITIVE" | "NEGATIVE"
    fixtureContentHash: canonicalHash
  }>                                              // non-empty; at least one POSITIVE and one NEGATIVE member
  authorityHash: canonicalHash                   // SHA-256 of this object's own preimage per `## Canonical Serialization Profile`, excluding authorityHash itself
}
```

`HeldOutFixtureSetAuthority` itself carries no verification-status field --
verification is derived from a separate `IssuerVerificationReceipt` object,
never a self-declared status a writer could set directly. See "Issuer
attestation and its admission consequence" below for the receipt schema and
the exact derivation rule an authority's admissibility depends on.

`HeldOutFixtureSetAuthority` is round-scoped: exactly one authority object
per `(taskClassId, partitionId, comparabilityFingerprint)` triple per
calibration round. It is created once, before any candidate is evaluated
against it, and is never mutated afterward. A candidate envelope carries
only `heldOutFixtureSetAuthorityHash` (a reference to `authorityHash`); it
never carries `requiredMembers` or any other authority field directly, and
it never constructs or edits an authority object.

### Ownership And Immutability

- **Issuer:** only the calibration-round decision owner may create a
  `HeldOutFixtureSetAuthority`. A document, receipt, or code path that lets
  a candidate's own submission construct, propose, or silently default one
  is a structural violation of this contract, not an implementation detail
  left open for later. This directly answers R2-RV-F1's "the authority that
  creates and freezes the declaration also remains unnamed" finding: the
  issuer is named as a fixed role literal in the schema itself.
- **Issuer attestation and its admission consequence:** the `issuedBy`
  literal proves nothing by itself -- any writer can set it to
  `"CALIBRATION_ROUND_DECISION_OWNER"` regardless of who authored the
  object. `issuerAttestationRef.attestationContentHash` (matches
  `recompute({registrySnapshotHash, attestedIssuerIdentity, authorityId,
  issuedAtUtc})`, `BOTH_INDEPENDENT`) is a **structural consistency check
  only**: it proves non-repudiation and mandatory presence, but a
  shape-valid arbitrary `registrySnapshotHash`/`attestedIssuerIdentity`
  satisfies it exactly as well as a real one, so it cannot by itself prove
  `attestedIssuerIdentity` genuinely holds the decision-owner role -- no
  more than the bare literal could. A free-standing
  `issuerVerificationStatus` string would have the identical defect (Local
  found this in a prior repair round): self-settable by whoever constructs
  the authority. Verification must instead be a separately-issued,
  hash-bound receipt the checker actually inspects, never a status field it
  merely reads:

  ```text
  IssuerVerificationReceipt = {
    receiptId: string (non-empty, unique per issuance)
    verifiedAuthorityHash: canonicalHash            // the exact authorityHash this receipt verifies; binds the receipt to one specific authority object, not a role or a round
    verifiedBy: "CALIBRATION_ROUND_DECISION_OWNER_VERIFIER"  // fixed literal; the verifying-party role, structurally DISTINCT from HeldOutFixtureSetAuthority.issuedBy -- the same actor that issues an authority must never be able to also self-verify it, so this contract requires a different named role even though both ultimately trace to the same governance chain in a real deployment
    verifiedRegistrySnapshotHash: canonicalHash      // the registry snapshot actually consulted during the live lookup this receipt records; MUST equal the authority's own issuerAttestationRef.registrySnapshotHash, checked explicitly below
    verifiedAtUtc: string (ISO 8601 UTC)             // when the live lookup was performed; must be at or after the authority's issuedAtUtc
    lookupResult: "IDENTITY_CONFIRMED_DECISION_OWNER_ROLE"  // fixed literal; the only admissible positive outcome; any other value (or the receipt's absence) leaves the authority UNVERIFIED
    receiptHash: canonicalHash                       // SHA-256 under this profile of every field above except receiptHash itself
  }
  ```

  **Derivation (not a self-declared field):** verification status is
  removed from `HeldOutFixtureSetAuthority` entirely and is instead a
  **derived** read (same pattern as `OperatingPointAcceptanceBinding`'s
  derived validity in Decision 4): derived status is
  `VERIFIED_BY_LIVE_REGISTRY_LOOKUP` iff at least one
  `IssuerVerificationReceipt` exists with all of: (a)
  `verifiedAuthorityHash == authorityHash`; (b) `receiptHash ==
  recompute(fields)` (`BOTH_INDEPENDENT`, rejects a fabricated receipt); (c)
  `verifiedRegistrySnapshotHash == issuerAttestationRef.registrySnapshotHash`
  (verifies the *same* snapshot the authority cites, not an unrelated one);
  (d) `verifiedAtUtc >= issuedAtUtc`; (e) `lookupResult ==
  IDENTITY_CONFIRMED_DECISION_OWNER_ROLE`. Absent such a receipt, or with
  any condition (a)-(e) failing, derived status is `UNVERIFIED` and the
  authority is **inadmissible for candidate evaluation** (reason
  `AUTHORITY_ISSUER_UNVERIFIED`), regardless of
  `issuerAttestationRef.attestationContentHash` passing. This closes the
  self-settable-field defect Local found: there is no field left to set --
  admissibility requires an independently-hashed, independently-recomputable
  receipt, checked `BOTH_INDEPENDENT` like every other admissibility edge
  here. A pure/offline layer that cannot perform the underlying live lookup
  (same posture as G3 never contacting a real provider, and T2A's GC-026
  honesty statement for a different registry) issues no receipt, so every
  authority it evaluates derives `UNVERIFIED` and is rejected -- never
  silently admissible, never satisfied by a self-declared string. Any
  future implementation's claim boundary must repeat this receipt-based
  rule verbatim or equivalently; a bare, unconstrained status field is
  never sufficient for admission again.
- **Timing:** `issuedAtUtc` must be provably before every candidate
  evaluation timestamp it governs (checked against each candidate's own
  evidence timestamps at decision time); an authority issued after
  evaluation began is inadmissible for that round.
- **Immutability:** once issued, `requiredMembers` and every other field
  except is never edited. A round that needs a different required set
  issues a **new** `HeldOutFixtureSetAuthority` with a new `authorityId` and
  a new `authorityHash`; it does not patch the existing object. Candidates
  already bound to the old `authorityHash` remain governed by the old
  object; they are never silently migrated to a new authority.

### Coverage-Equality Rule (Closes The T2A Coverage Gap Without Repeating Its Ownership Gap)

"Currently admissible," for this rule, requires two independent conditions,
checked in this order: (1) the referenced `HeldOutFixtureSetAuthority`
exists in the round with a matching `authorityHash`; and (2) that
authority's **derived** verification status (computed from
`IssuerVerificationReceipt` per "Issuer attestation and its admission
consequence" above) is `VERIFIED_BY_LIVE_REGISTRY_LOOKUP`, never
`UNVERIFIED`. A candidate whose `heldOutFixtureSetAuthorityHash` does not
match any authority satisfying **both** conditions is `insufficient_evidence`:
reason `UNKNOWN_OR_STALE_FIXTURE_AUTHORITY` if condition (1) fails, or
reason `AUTHORITY_ISSUER_UNVERIFIED` if condition (1) holds but condition
(2) fails -- an `UNVERIFIED` authority is never silently treated as
admissible merely because it is otherwise structurally well-formed, and
there is no field on the authority itself a writer could set to force
condition (2); it can only be satisfied by an independently checkable
`IssuerVerificationReceipt` existing and passing every one of its own
binding checks. Only once both conditions hold does coverage-equality
itself apply: a
candidate's `requiredEvidence[]` (defined in `## Selected Architecture
Decision 2` below) **covers** the authority if and only if, for every entry
in `requiredMembers`, there exists exactly one entry in the candidate's
`requiredEvidence[]` with the same `fixtureId`, the same `fixtureClass`, and
the same `fixtureContentHash`. A candidate whose set does not cover every
required member is `insufficient_evidence` with reason
`MISSING_REQUIRED_FIXTURE` naming the uncovered `fixtureId`(s). This
coverage-equality check is evaluated **exclusively within one candidate's
own `requiredEvidence[]`** against the one authority it references; no code
path reads another candidate's evidence, exactly as the T2A repair
(correctly, per R2's `ACCEPT_AS_DESIGN_DIRECTION` disposition) established
as a mandatory decision-owner invariant with mandatory regression test
coverage -- that part of T2A's design direction is preserved here, not
reopened.

## Selected Architecture Decision 2: requiredEvidence / supplementalEvidence Topology

### Local Decision (Verbatim Binding, Field Names Refined)

Per GC-018's Architecture Decision table, row "Evidence topology": separate
`requiredEvidence[]` and `supplementalEvidence[]`; only required evidence can
affect admission, preference and regression binding. Extras inside a field
named required evidence is the rejected alternative and is not implemented
here -- this directly reopens and correctly resolves R2-RV-F1's finding that
T2A "keeps extras inside the field named `requiredFixtureEvidenceSet`."

### Schema

```text
CandidateFixtureEvidence = {
  fixtureId: string (non-empty)
  fixtureClass: "POSITIVE" | "NEGATIVE"
  fixtureContentHash: canonicalHash
  traceIds: string[] (non-empty)
  traceContentHashes: canonicalHash[] (same length as traceIds)
  traceCaptureModes: string[] (same length as traceIds)
  g3ResultHash: canonicalHash                     // recomputed, never
                                                   // caller-trusted
  producerReceipt: {
    receiptRef: string
    candidateId: string
    candidateConfigHash: canonicalHash
    traceIds: string[]
  }
  g3Fixture: object                               // actual G3 fixture,
                                                   // genuinely graded
  g3Traces: object[]                               // actual G3 traces,
                                                   // genuinely graded
}

TaskClassCalibrationCandidateEnvelope (relevant fields only) = {
  taskClassId: string
  candidateId: string
  candidateConfigHash: canonicalHash
  comparabilityFingerprint: canonicalHash
  heldOutFixtureSetAuthorityHash: canonicalHash    // reference only; see
                                                   // Decision 1
  requiredEvidence: CandidateFixtureEvidence[]      // non-empty; every
                                                   // entry MUST correspond
                                                   // to a member of the
                                                   // referenced authority's
                                                   // requiredMembers, per
                                                   // the coverage-equality
                                                   // rule above
  supplementalEvidence: CandidateFixtureEvidence[]  // may be empty; every
                                                   // entry's fixtureId MUST
                                                   // NOT be a member of the
                                                   // referenced authority's
                                                   // requiredMembers (see
                                                   // Field-Disjointness rule
                                                   // below)
  // ... unchanged envelope fields from the T1 manifest: partition,
  // policyId, budgetCeiling, budgetConsumed, providerLaneStatus,
  // contaminationKeys, optional rubricEvaluatorAdapter/benchmarkReport/
  // metricUnit
}
```

### Field-Disjointness Rule (Structural, Not Merely Tested)

`requiredEvidence[]` and `supplementalEvidence[]` are **disjoint by
`fixtureId`**, enforced at structural-validation time, before any admission
or preference logic runs: an entry whose `fixtureId` matches a member of the
referenced `HeldOutFixtureSetAuthority.requiredMembers` MUST appear only in
`requiredEvidence[]`; an entry whose `fixtureId` does not match any required
member MUST appear only in `supplementalEvidence[]`. A candidate envelope
that places a required-member `fixtureId` inside `supplementalEvidence[]`,
or a non-member `fixtureId` inside `requiredEvidence[]`, fails structural
validation with reason `EVIDENCE_TOPOLOGY_MISPLACEMENT` naming the offending
`fixtureId` and the field it was found in versus the field it belongs in.
This is checked mechanically against the authority's own `requiredMembers`
list, not against a candidate's self-declared intent, which is what makes
this the *no-extras-inside-required* topology GC-018 selected rather than a
naming convention alone.

**Two-phase evaluation order (mandatory, resolves the single ambiguity a
required-member `fixtureId` misplacement could otherwise create between
this rule and the coverage-equality rule below):** every candidate envelope
is evaluated in exactly two ordered, non-overlapping phases, and the second
phase never runs unless the first phase fully passes.

1. **Phase 1 -- structural validation (this Field-Disjointness Rule).**
   Checked first, over the candidate's raw `requiredEvidence[]`/
   `supplementalEvidence[]` field placement against the referenced
   authority's `requiredMembers`. A misplacement failure here (`EVIDENCE_TOPOLOGY_MISPLACEMENT`)
   terminates evaluation for that candidate immediately: **the envelope
   never reaches Phase 2**, no coverage-equality check runs, and no
   `insufficient_evidence`/`MISSING_REQUIRED_FIXTURE` determination is ever
   made for that envelope, because a structurally invalid envelope has no
   decision state to reach. This is the single authoritative outcome for a
   required-member `fixtureId` found in `supplementalEvidence[]`, or a
   non-member `fixtureId` found in `requiredEvidence[]`.
2. **Phase 2 -- admission and coverage (`## Admission And Coverage` below).**
   Runs only after Phase 1 passes -- i.e., only over an envelope where every
   `requiredEvidence[]` entry's `fixtureId` is genuinely a required member
   and every `supplementalEvidence[]` entry's `fixtureId` is genuinely not.
   `MISSING_REQUIRED_FIXTURE` (`insufficient_evidence`) can therefore only
   ever be reached for a required member that is **absent from both
   arrays entirely** in a Phase-1-valid envelope -- never for a member that
   was present but misplaced, since a misplaced member fails Phase 1 first
   and the envelope never reaches Phase 2's coverage check at all.

### Admission And Coverage (Required Evidence Only)

- `admitFixtureSet` (the existing G3 positive-plus-negative class-composition
  check, reused unchanged) is evaluated exactly once per candidate, over
  that candidate's own `requiredEvidence[].g3Fixture` pool only.
- The `## Selected Architecture Decision 1` coverage-equality rule is
  evaluated over `requiredEvidence[]` only.
- Every entry in `requiredEvidence[]` must independently reach
  `PASS_WITH_EVIDENCE` from `gradeBehavioralEvaluation` (reused unchanged),
  with byte-binding cross-checks (`producerReceipt` identity match,
  recomputed `g3ResultHash`, `fixtureContentHash`/`traceContentHashes`
  cross-check against the actual supplied `g3Fixture`/`g3Traces`). One
  `requiredEvidence[]` entry failing this bar makes the whole candidate
  `insufficient_evidence`.
- **Supplemental evidence is provably non-authoritative (closes Acceptance
  Criterion 4):** `supplementalEvidence[]` entries are never read by
  `admitFixtureSet`, never read by the coverage-equality check, never read
  by the per-entry `PASS_WITH_EVIDENCE` gate, never included in
  `orderedEvidenceEnvelopeHashes` (defined in Decision 3), never contribute
  to `preferenceValueDigest`, and never create or modify a
  `RegressionBinding`. A supplemental entry that fails, is malformed, or is
  entirely absent has zero effect on any decision-path outcome -- the only
  permitted use of `supplementalEvidence[]` is disclosure in the returned
  assessment document, for human/reviewer visibility, with a
  `SUPPLEMENTAL_EVIDENCE_NON_AUTHORITATIVE` marker on every entry.

### Negative Cases

Every row below is scoped to its evaluation phase; rows marked "Phase 1"
occur before, and instead of, any Phase 2 row for the same envelope.

| Phase | Case | Behavior |
|---|---|---|
| Phase 1 | a required-member `fixtureId` is placed in `supplementalEvidence[]` | structural validation failure, reason `EVIDENCE_TOPOLOGY_MISPLACEMENT`, naming the `fixtureId` and its actual versus required field. This is the sole, unambiguous outcome for this case: the envelope terminates at Phase 1 and never reaches Phase 2, so `insufficient_evidence`/`MISSING_REQUIRED_FIXTURE` is never separately reached or reported for the same `fixtureId` |
| Phase 1 | a non-member `fixtureId` is placed in `requiredEvidence[]` | structural validation failure, reason `EVIDENCE_TOPOLOGY_MISPLACEMENT`; envelope terminates at Phase 1 |
| Phase 2 | `heldOutFixtureSetAuthorityHash` does not match any authority in the round (no `authorityHash` match at all) | `insufficient_evidence`, reason `UNKNOWN_OR_STALE_FIXTURE_AUTHORITY` |
| Phase 2 | `heldOutFixtureSetAuthorityHash` matches an authority for which no admissible `IssuerVerificationReceipt` exists (structurally well-formed authority, but no receipt, or a receipt failing any of the receipt's own binding checks) | `insufficient_evidence`, reason `AUTHORITY_ISSUER_UNVERIFIED`; derived status is `UNVERIFIED`, never silently treated as admissible regardless of every other check passing |
| Phase 2 | an `IssuerVerificationReceipt` exists but its `verifiedAuthorityHash` does not match this authority's `authorityHash`, or its `verifiedRegistrySnapshotHash` does not match the authority's own `issuerAttestationRef.registrySnapshotHash`, or `verifiedAtUtc < issuedAtUtc`, or `lookupResult` is not exactly `IDENTITY_CONFIRMED_DECISION_OWNER_ROLE` | that receipt does not count toward verification; if no other admissible receipt exists, derived status is `UNVERIFIED`, same as the row above |
| Phase 2 | candidate's `requiredEvidence[]` and `supplementalEvidence[]` (both already Phase-1-valid) together omit a required member entirely -- the member appears in neither array | `insufficient_evidence`, reason `MISSING_REQUIRED_FIXTURE`, naming the `fixtureId`. (A required member that was *present but misplaced* is a Phase 1 case above, not this row; this row applies only to genuine absence.) |
| Phase 2 | candidate's `requiredEvidence[]` has an entry whose class/content hash mismatches the authority's corresponding required member | `insufficient_evidence`, reason `REQUIRED_FIXTURE_CONTENT_MISMATCH` |
| Phase 1 | duplicate `fixtureId` within `requiredEvidence[]` | structural validation failure, reason `DUPLICATE_FIXTURE_ID_WITHIN_CANDIDATE`; envelope terminates at Phase 1 (duplicate identity is itself a structural defect, checked alongside field-disjointness before Phase 2) |
| N/A (never blocking) | duplicate `fixtureId` within `supplementalEvidence[]` | disclosure-only; deduplicated for display with a disclosed count, never blocks any decision path (supplemental evidence cannot affect outcome regardless of shape) |
| Phase 2 | `requiredEvidence[]` entry fails `PASS_WITH_EVIDENCE` | `insufficient_evidence` for the whole candidate |
| N/A (never blocking) | `supplementalEvidence[]` entry fails grading, is malformed, or is empty | no effect on any decision path; disclosed only |
| Structurally impossible (not a reachable case) | candidate attempts to satisfy a missing required member using a `supplementalEvidence[]` entry with the same `fixtureId` | structurally impossible in two independent ways: (1) Phase 1 rejects that exact placement as `EVIDENCE_TOPOLOGY_MISPLACEMENT` before Phase 2 runs; (2) even hypothetically bypassing Phase 1, the Phase 2 coverage-equality check in Decision 1 reads `requiredEvidence[]` exclusively and never inspects `supplementalEvidence[]` at all. This closes the "supplemental laundering" case the work order names explicitly, by two independent structural barriers rather than one |
| N/A (cross-cutting) | cross-candidate pooling attempt (one candidate's evidence read while evaluating another) | forbidden by mandatory decision-owner invariant: every function above takes exactly one candidate's own `requiredEvidence[]`/`supplementalEvidence[]` as its only fixture-bearing parameter; enforcement backstop is the mandatory regression test named in `## Checker And Test Contract` |

## Canonical Serialization Profile (Closes R2-RV-F2)

### Problem This Closes

R2-RV-F2 (HIGH): every prior version of this line of work defined
canonicalization ad hoc, per hash, using string-joining or partial field
lists. The concrete demonstrated collision:
`traceIds.join(",")` before length-prefixing means `['a,b','c']` and
`['a','b,c']` both serialize to the identical string `"a,b,c"`, so two
distinct receipt contents can produce the same declared preimage without an
actual SHA-256 collision -- the collision is in the serialization step, not
the hash function.

### Chosen Profile

Per the work order's mandatory architecture item 3, this contract defines
one new profile, **`cvf.taskClassCalibration.rootContractHash.v1`**, used
for every hash in this entire document without exception (the
`HeldOutFixtureSetAuthority.authorityHash`, every `CandidateFixtureEvidence`
content hash, `OperatingPointAcceptanceBinding.acceptanceFingerprint`, and
`OperatingPointInvalidationReceipt.receiptHash` all use this one profile,
never a field-local delimiter convention).

```text
Profile: cvf.taskClassCalibration.rootContractHash.v1

digestAlgorithm: SHA-256

serialization: RFC 8785 (JCS) canonical JSON string serialization of a
  fixed-shape JSON object, UTF-8 encoded, with:
  - no insignificant whitespace
  - minimal string escaping per RFC 8785 (only characters JCS requires
    escaped are escaped; non-ASCII is literal UTF-8, never \uXXXX-escaped
    unless the character is a JSON-mandatory escape)
  - fixed named fields in fixed declared order for every object type this
    profile hashes (the field order for each hashed object type is stated
    explicitly in that object's own schema section in this document; JCS's
    own key-sorting rule is NOT relied upon alone, since JCS sorts object
    keys but this profile additionally fixes which keys exist and forbids
    extra/missing keys for a hashed object -- JCS key ordering and this
    profile's fixed-field-list requirement are complementary, not
    substitutes for each other)
  - JSON null for any field this profile declares nullable and the value is
    absent
  - JSON [] for any array-typed field with zero elements; arrays are never
    represented as null, and null is never used where [] is required
  - every array field explicitly declared SET_SEMANTIC in this document is
    sorted lexicographically (Unicode code point order, ascending) by its
    declared sort key before serialization, so two callers supplying the
    same logical set in different input order produce an identical preimage
  - every array field explicitly declared SEQUENCE_SEMANTIC in this document
    preserves caller-declared order verbatim; it is never reordered, and
    reordering it is a content change subject to the invalidation triggers
    in `## Selected Architecture Decision 4`, not a canonicalization no-op
  - decimal/numeric values are represented as canonical decimal strings
    (never a native JSON number, to avoid IEEE-754 float-formatting
    ambiguity across implementations): no exponent form, `-0` normalized to
    `0`, no leading zeroes (other than a single `0` for magnitude below 1),
    no trailing zeroes after the decimal point, no trailing decimal point
    for whole values, a single leading `-` retained for negative values
  - ISO 8601 UTC timestamps in the fixed form `YYYY-MM-DDTHH:MM:SSZ`
  - the profile identifier (`cvf.taskClassCalibration.rootContractHash.v1`)
    and a `hashedObjectType` string (naming exactly which schema object is
    being hashed, e.g. `"HeldOutFixtureSetAuthority"`) are themselves
    included as fixed fields inside the preimage object, so a future profile
    or object-shape change is detectable in the digest rather than silently
    reusing the same profile identifier over a changed shape
  - the field being computed (e.g. `authorityHash`, `receiptHash`) is always
    excluded from its own preimage

preimageConstruction: for a given object O being hashed under this profile,
  the preimage is the RFC 8785 JCS-canonical UTF-8 byte serialization of a
  JSON object containing exactly: `{"profile":"cvf.taskClassCalibration.rootContractHash.v1","hashedObjectType":"<TypeName>","fields":{...O's own fixed fields, excluding the hash field being computed...}}`.
  digest = SHA-256(preimageBytes), rendered as 64 lowercase hex characters.

fieldOrderPolicy: this profile does not itself need to declare one single
  global field order, because RFC 8785 JCS deterministically sorts JSON
  object keys lexicographically as part of canonical serialization -- this
  profile's own contribution is (a) requiring JCS (not an ad hoc join) for
  every hash without exception, (b) fixing which keys exist per hashed
  object type (so extra/missing keys are themselves a validation failure,
  not merely a hashing nondeterminism risk), and (c) fixing set-versus-
  sequence array semantics per field so array reordering is either always a
  no-op (set-semantic) or always a content change (sequence-semantic),
  never ambiguous per caller.

listSerialization: every list-typed field (`requiredMembers`, `traceIds`,
  `traceContentHashes`, `traceCaptureModes`, evidence arrays, receipt
  chains) is serialized as a genuine JSON array of its typed elements inside
  the canonical JSON object -- never joined into one delimited string before
  hashing. This is the direct, structural fix for the demonstrated
  collision: `["a,b","c"]` and `["a","b,c"]` are two distinct JSON arrays
  with two distinct JCS-canonical serializations and therefore two distinct
  digests, regardless of what any individual string element contains.
```

### Published Test Vectors

Per Acceptance Criterion 5 and the work order's mandatory architecture item
3, this document publishes one complete positive preimage/digest vector plus
delimiter-collision negative vectors, computed directly in this authoring
pass (not asserted without computation).

**Positive vector** -- `HeldOutFixtureSetAuthority` with one `POSITIVE` and
one `NEGATIVE` required member, and a fully self-consistent
`issuerAttestationRef` (mandatory as of this repair round; an earlier draft
of this vector omitted the field entirely, making the preimage invalid
against this contract's own schema):

```text
issuerAttestationRef.attestationContentHash preimage (computed first, since authorityHash's own preimage depends on it):
{"fields":{"attestedIssuerIdentity":"decision-owner-registry-entry-0001","authorityId":"hofsa-2026-09-17-0001","issuedAtUtc":"2026-09-17T00:00:00Z","registrySnapshotHash":"7777777777777777777777777777777777777777777777777777777777777777"},"hashedObjectType":"IssuerAttestationRef","profile":"cvf.taskClassCalibration.rootContractHash.v1"}
Computed attestationContentHash: c5e8016632a74cd9cead9734eba608d0b10474dfeae9a8a83db7c1ffcf109b2a

Input object (before hashing; authorityHash omitted per the profile's own exclusion rule; attestationContentHash is the value computed immediately above, not a placeholder, so this vector is internally consistent end to end):
{
  "authorityId": "hofsa-2026-09-17-0001",
  "issuedBy": "CALIBRATION_ROUND_DECISION_OWNER",
  "issuerAttestationRef": {
    "registrySnapshotHash": "7777777777777777777777777777777777777777777777777777777777777777",
    "attestedIssuerIdentity": "decision-owner-registry-entry-0001",
    "attestationContentHash": "c5e8016632a74cd9cead9734eba608d0b10474dfeae9a8a83db7c1ffcf109b2a"
  },
  "issuedAtUtc": "2026-09-17T00:00:00Z",
  "taskClassId": "tc-example-001",
  "partitionId": "part-heldout-001",
  "comparabilityFingerprint": "0000000000000000000000000000000000000000000000000000000000000000",
  "requiredMembers": [
    {"fixtureId": "fx-001", "fixtureClass": "NEGATIVE", "fixtureContentHash": "1111111111111111111111111111111111111111111111111111111111111111"},
    {"fixtureId": "fx-002", "fixtureClass": "POSITIVE", "fixtureContentHash": "2222222222222222222222222222222222222222222222222222222222222222"}
  ]
}
Note: requiredMembers is SET_SEMANTIC (sorted lexicographically by fixtureId ascending) -- "fx-001" before "fx-002" is already ascending order, so this vector does not exercise reordering; see the array-reorder vector below for that case. This vector's authority has no accompanying `IssuerVerificationReceipt`, so its derived verification status would be `UNVERIFIED` (inadmissible for any candidate evaluation) as issued; it is a schema/canonicalization example only -- see "Issuer attestation and its admission consequence" in `## Ownership And Immutability` for the receipt-based admission rule this example does not itself satisfy.

Canonical preimage (RFC 8785 JCS-serialized, exact bytes, wrapped per this profile's preimageConstruction):
{"fields":{"authorityId":"hofsa-2026-09-17-0001","comparabilityFingerprint":"0000000000000000000000000000000000000000000000000000000000000000","issuedAtUtc":"2026-09-17T00:00:00Z","issuedBy":"CALIBRATION_ROUND_DECISION_OWNER","issuerAttestationRef":{"attestationContentHash":"c5e8016632a74cd9cead9734eba608d0b10474dfeae9a8a83db7c1ffcf109b2a","attestedIssuerIdentity":"decision-owner-registry-entry-0001","registrySnapshotHash":"7777777777777777777777777777777777777777777777777777777777777777"},"partitionId":"part-heldout-001","requiredMembers":[{"fixtureClass":"NEGATIVE","fixtureContentHash":"1111111111111111111111111111111111111111111111111111111111111111","fixtureId":"fx-001"},{"fixtureClass":"POSITIVE","fixtureContentHash":"2222222222222222222222222222222222222222222222222222222222222222","fixtureId":"fx-002"}],"taskClassId":"tc-example-001"},"hashedObjectType":"HeldOutFixtureSetAuthority","profile":"cvf.taskClassCalibration.rootContractHash.v1"}
Computed SHA-256 digest (verified by direct computation during authoring): 549530d9f5d97d6d3ea07f91f48e334fb31957c7756d2a16b4e1fad25af11456
```

**Delimiter-collision negative vector 1** -- comma inside a list element (the exact class of collision R2-RV-F2 demonstrated against T2A's receipt digest). **Correction:** an earlier draft varied `traceIds` on a `HeldOutFixtureSetAuthority`-typed preimage, but that schema has no `traceIds` field, so the preimage was not reconstructible and the vector was not genuinely reproducible. This vector instead uses `CandidateFixtureEvidenceEnvelopeHash` (the exact type `orderedEvidenceEnvelopeHashes` hashes per entry, Decision 3 above), which does declare `traceIds`/`traceContentHashes`/`traceCaptureModes` and a nested `producerReceipt.traceIds`. Two complete, valid preimages are published in full below, so the vector is independently reproducible field-for-field:

```text
Object A (traceIds=["a,b","c"]), hashedObjectType "CandidateFixtureEvidenceEnvelopeHash", fields: fixtureId "fx-001", fixtureClass "NEGATIVE", fixtureContentHash "1111111111111111111111111111111111111111111111111111111111111111", traceIds ["a,b","c"], traceContentHashes ["5555555555555555555555555555555555555555555555555555555555555555","6666666666666666666666666666666666666666666666666666666666666666"], traceCaptureModes ["LIVE","LIVE"], g3ResultHash "3333333333333333333333333333333333333333333333333333333333333333", producerReceipt {receiptRef "receipt-ref-0001", candidateId "cand-0001", candidateConfigHash "4444444444444444444444444444444444444444444444444444444444444444", traceIds ["a,b","c"]}

Full canonical preimage:
{"fields":{"fixtureClass":"NEGATIVE","fixtureContentHash":"1111111111111111111111111111111111111111111111111111111111111111","fixtureId":"fx-001","g3ResultHash":"3333333333333333333333333333333333333333333333333333333333333333","producerReceipt":{"candidateConfigHash":"4444444444444444444444444444444444444444444444444444444444444444","candidateId":"cand-0001","receiptRef":"receipt-ref-0001","traceIds":["a,b","c"]},"traceCaptureModes":["LIVE","LIVE"],"traceContentHashes":["5555555555555555555555555555555555555555555555555555555555555555","6666666666666666666666666666666666666666666666666666666666666666"],"traceIds":["a,b","c"]},"hashedObjectType":"CandidateFixtureEvidenceEnvelopeHash","profile":"cvf.taskClassCalibration.rootContractHash.v1"}
Computed SHA-256 digest: 6cbd4c82d31d562469d62c20e0dcf7877917d9ea18b1f332ab040132bb9e4c98

Object B (traceIds=["a","b,c"], every other field identical to Object A). Full canonical preimage:
{"fields":{"fixtureClass":"NEGATIVE","fixtureContentHash":"1111111111111111111111111111111111111111111111111111111111111111","fixtureId":"fx-001","g3ResultHash":"3333333333333333333333333333333333333333333333333333333333333333","producerReceipt":{"candidateConfigHash":"4444444444444444444444444444444444444444444444444444444444444444","candidateId":"cand-0001","receiptRef":"receipt-ref-0001","traceIds":["a","b,c"]},"traceCaptureModes":["LIVE","LIVE"],"traceContentHashes":["5555555555555555555555555555555555555555555555555555555555555555","6666666666666666666666666666666666666666666666666666666666666666"],"traceIds":["a","b,c"]},"hashedObjectType":"CandidateFixtureEvidenceEnvelopeHash","profile":"cvf.taskClassCalibration.rootContractHash.v1"}

Computed SHA-256 digest:
d6a7648550635b3c0da1b09693734c4a925a201c26f6b6291eff15462d439592

Under the REJECTED prior pattern (join(",") then hash the joined string):
both `["a,b","c"]` and `["a","b,c"]` serialize to the identical string
"a,b,c" -> identical digest -- this is the exact defect R2-RV-F2 found,
confirmed by direct computation: `",".join(["a,b","c"])` ==
`",".join(["a","b,c"])` == `"a,b,c"` in both cases.

Under this profile (genuine JSON array inside JCS canonical serialization),
the two full preimages above differ at both the outer `traceIds` field and
the nested `producerReceipt.traceIds` field, producing two distinct byte
sequences and therefore two distinct SHA-256 digests, both computed
directly during authoring of this document, holding every other field
identical between Object A and Object B:
Object A digest: 6cbd4c82d31d562469d62c20e0dcf7877917d9ea18b1f332ab040132bb9e4c98
Object B digest: d6a7648550635b3c0da1b09693734c4a925a201c26f6b6291eff15462d439592
Disposition: NOT_EQUAL (correct; collision structurally avoided)
```

**Delimiter-collision negative vector 2** -- pipe character inside a string field (guards the T2A pattern this profile fully replaces, not merely supplements):

```text
Object A authorityId: "a|b"; Object B authorityId: "a", with a second field's value carrying "b" instead. A genuine JCS-serialized JSON object never merges two distinct string-typed fields' content through a shared delimiter byte, because each field is its own quoted JSON string token with JSON's own escaping rules, not a concatenated byte run. This profile therefore has no pipe-collision surface at all; the "|"-joined length-prefixing scheme T2A used is not carried forward into this profile in any form.
Disposition: STRUCTURALLY_ELIMINATED, not merely tested
```

**Array-reorder vector** -- confirms `requiredMembers` is genuinely SET_SEMANTIC:

```text
Caller A supplies requiredMembers in order [fx-002 (POSITIVE), fx-001 (NEGATIVE)]; Caller B supplies [fx-001 (NEGATIVE), fx-002 (POSITIVE)]. This profile sorts SET_SEMANTIC arrays lexicographically by fixtureId ascending before serialization for both callers, so both produce the identical canonical preimage as the positive vector above (including the same `issuerAttestationRef`) and therefore the identical digest 549530d9f5d97d6d3ea07f91f48e334fb31957c7756d2a16b4e1fad25af11456.
Disposition: MATCH (correct; caller input order is not authority content)
```

**Empty/null vector**:

```text
An authority with zero requiredMembers is REJECTED at structural validation (requiredMembers is declared non-empty in the schema) before any hash is even computed; there is no valid canonical preimage for an empty required set, so this profile never needs to disambiguate {"requiredMembers":[]} from {"requiredMembers":null} for this field -- both are structurally invalid input, not two different valid encodings of "no requirement."
```

### Independent Recomputability

Any two independent implementations of `cvf.taskClassCalibration.rootContractHash.v1`
given the same typed field values for the same `hashedObjectType` must
produce the identical digest, because RFC 8785 JCS is itself a
deterministic, fully specified canonicalization algorithm with no
implementation-defined choices left open, and this profile adds only fixed
field lists and fixed set/sequence array semantics on top of it -- neither
of which leaves a per-implementation choice either. This is the literal
closure of Acceptance Criterion 5's "one complete JCS preimage definition
and reproducible vector; delimiter-shaped distinct inputs cannot collide
before SHA-256."

## Selected Architecture Decision 3: Operating-Point Provenance Formula (Adapted From T1, Restated Under The New Profile)

The T1 manifest's `provenanceFingerprint.formula` --
`SHA-256(canonicalVersion | comparabilityFingerprint | acceptedCandidateId |
candidateConfigHash | orderedEvidenceEnvelopeHashes[] | preferencePolicyHash
| promotionEvidenceRefOrRubricHash)` -- is restated as a fixed-field object
hashed under `cvf.taskClassCalibration.rootContractHash.v1`
(`hashedObjectType: "OperatingPointAcceptanceBinding"`), not as a
pipe-joined string, per `## Canonical Serialization Profile` above:

```text
OperatingPointAcceptanceBinding = {
  bindingId: string (non-empty, unique per issuance)
  taskClassId: string
  acceptedCandidateId: string
  candidateConfigHash: canonicalHash
  comparabilityFingerprint: canonicalHash
  heldOutFixtureSetAuthorityHash: canonicalHash
  orderedEvidenceEnvelopeHashes: canonicalHash[]  // SEQUENCE_SEMANTIC: accepted candidate's requiredEvidence[] sorted by fixtureId ascending (fixed once, then ordered); each entry = SHA-256 of a "CandidateFixtureEvidenceEnvelopeHash"-typed object (fixtureId, fixtureClass, fixtureContentHash, g3ResultHash, producerReceipt, traceIds, traceContentHashes, traceCaptureModes), not a joined pair -- the exact type used in the delimiter-collision vector below
  preferencePolicyHash: canonicalHash
  promotionEvidenceRefOrRubricHash: canonicalHash  // GC-026 recordContentHash or rubricVersionHash, unambiguous per kind (unchanged from T1/T2A)
  preferenceValueDigest: canonicalHash            // SHA-256 of the accepted candidate's exact numeric preference value as a canonical decimal string
  requiredEvidenceSnapshotRef: {                  // MANDATORY; INCLUDED in acceptanceFingerprint's own preimage (see explicit field list below) -- see "acceptance precondition" note below for why
    snapshotContentHash: canonicalHash             // SHA-256 of the full ordered requiredEvidence[] array (same ordering as orderedEvidenceEnvelopeHashes) that produced orderedEvidenceEnvelopeHashes
    snapshotRef: string (non-empty)                // pointer to where the full snapshot content is persisted for independent recomputation
  }
  acceptedAtUtc: string (ISO 8601 UTC)            // separate metadata, never hashed (matches T1's "acceptedAt is separate metadata")
  acceptanceFingerprint: canonicalHash            // SHA-256 of exactly: bindingId, taskClassId, acceptedCandidateId, candidateConfigHash, comparabilityFingerprint, heldOutFixtureSetAuthorityHash, orderedEvidenceEnvelopeHashes, preferencePolicyHash, promotionEvidenceRefOrRubricHash, preferenceValueDigest, AND requiredEvidenceSnapshotRef -- explicitly named, not "every field above," to remove any ambiguity about which fields are bound in. Excludes only acceptanceFingerprint itself (self-reference) and acceptedAtUtc (time is metadata per T1, not content)
}
```

**`requiredEvidenceSnapshotRef` is explicitly bound into `acceptanceFingerprint`'s own preimage, not merely present alongside it (closes a provenance-binding gap Local found: an earlier schema draft defined `acceptanceFingerprint` as "every field above," which is textually ambiguous about whether a field declared below that definition line is included, and never explicitly settled the question).** If `requiredEvidenceSnapshotRef` were excluded from `acceptanceFingerprint`, an actor could swap in a *different*, still-internally-consistent snapshot after acceptance (one whose `snapshotContentHash` still self-verifies, but which is not the actual snapshot `orderedEvidenceEnvelopeHashes` was computed from) without changing `acceptanceFingerprint` at all -- defeating the entire purpose of the snapshot requirement, since the acceptance's own immutable fingerprint would not detect the substitution. Binding it directly into the preimage closes this: any change to `requiredEvidenceSnapshotRef` (either field) changes `acceptanceFingerprint`, exactly like every other field the preimage explicitly names.

`OperatingPointAcceptanceBinding` is created exactly once per accepted
operating point and is immutable from that point forward. No field is ever
edited after creation, including in response to a later readiness, budget,
or GC-026 change -- those are handled exclusively by Decision 4 below, never
by mutating this binding.

**`requiredEvidenceSnapshotRef` is a mandatory acceptance precondition, not
an optional attachment (closes the unverifiable-acceptance gap):** a
document claiming `ACCEPTED_PREFERRED` or constructing an
`OperatingPointAcceptanceBinding` without a well-formed, non-empty
`requiredEvidenceSnapshotRef` fails structural validation before
`acceptanceFingerprint` is even computed -- there is no code path that
produces a valid `OperatingPointAcceptanceBinding` lacking this field. The
Python checker's independent recomputation of `orderedEvidenceEnvelopeHashes`
(`## Checker And Test Contract` below) is therefore never optional-if-
attached: every persisted acceptance carries the exact snapshot its
`orderedEvidenceEnvelopeHashes` was computed from, so `BOTH_INDEPENDENT`
recomputation is always possible, never merely attempted when convenient.
This directly satisfies Acceptance Criterion 6's "independently verifiable"
requirement for acceptance provenance specifically, closing the gap where a
prior draft of this contract allowed an accepted operating point to exist
with no attached evidence snapshot and treated that as a disclosed-but-
tolerated non-failure (`PROVENANCE_RECOMPUTATION_UNAVAILABLE_NO_SNAPSHOT`)
rather than a hard rejection. This mandatory-presence requirement and the
hash-binding requirement in the schema above are two distinct, both-needed
controls: mandatory presence stops an acceptance with no snapshot at all;
hash-binding (`requiredEvidenceSnapshotRef` included in `acceptanceFingerprint`'s
own preimage) stops a later swap to a *different* snapshot than the one
actually used, since swapping it would change `acceptanceFingerprint` and
be caught by `BOTH_INDEPENDENT` recomputation. Neither control alone is
sufficient; both are required together.

## Selected Architecture Decision 4: Acceptance Provenance Versus Invalidation-Event Evidence (Closes R2-RV-F3)

### Problem This Closes

R2-RV-F3 (HIGH): T2A tried to make a single immutable acceptance
fingerprint simultaneously (a) an unchangeable historical record and (b)
"provenance-bound" against future readiness/budget changes, by hashing an
accept-time snapshot into that same fingerprint. Both cannot hold at once:
an immutable hash computed at time T cannot, by definition, change in
response to an event at time T+1, so "every invalidation trigger maps to
provenance-bound content" was never actually true for the two live-state
triggers, even though the T2A document asserted it was.

### Chosen Architecture

Per GC-018's Architecture Decision table, row "Invalidation": immutable
acceptance binding (Decision 3 above) plus append-only
`OperatingPointInvalidationReceipt`; current validity derives from the
latest verified receipt and current-state observation. Pretending a later
readiness/budget change mutates a historical acceptance fingerprint is the
rejected alternative and is not implemented here.

```text
OperatingPointInvalidationReceipt = {
  receiptId: string (non-empty, unique per issuance)
  priorAcceptanceHash: canonicalHash               // OperatingPointAcceptanceBinding.acceptanceFingerprint
                                                   // this receipt is
                                                   // evaluated against
  trigger: TriggerName                             // one of the six T1
                                                   // invalidation-trigger
                                                   // names, unchanged (see
                                                   // Invalidation Trigger
                                                   // Reconciliation below)
  observedCurrentStateSnapshot: {
    source: string (non-empty)                     // e.g.
                                                   // "provider-lane-status-registry",
                                                   // "budget-ledger";
                                                   // names WHERE the
                                                   // current-state
                                                   // observation came from
    observedAtUtc: string (ISO 8601 UTC)
    observedFields: object                          // typed, trigger-
                                                   // specific fields (e.g.
                                                   // providerLaneStatus,
                                                   // budgetCeiling,
                                                   // budgetConsumed,
                                                   // gc026Attestation.recordContentHash,
                                                   // preferencePolicyHash,
                                                   // comparabilityFingerprint,
                                                   // per trigger)
  }
  comparisonResult: "NO_CHANGE" | "TRIGGER_MATCH"   // the result of
                                                   // comparing
                                                   // observedCurrentStateSnapshot
                                                   // against the field(s)
                                                   // this trigger governs,
                                                   // as bound in
                                                   // OperatingPointAcceptanceBinding
                                                   // or the fixture/GC-026
                                                   // authority it
                                                   // references
  checkedAtUtc: string (ISO 8601 UTC)               // when this comparison
                                                   // was performed (may
                                                   // differ from
                                                   // observedAtUtc)
  predecessorReceiptHash: canonicalHash | null       // the immediately
                                                   // prior receipt's own
                                                   // receiptHash in this
                                                   // acceptance's chain, or
                                                   // null only for the
                                                   // first receipt on a
                                                   // given
                                                   // priorAcceptanceHash
  receiptHash: canonicalHash                       // SHA-256 under this
                                                   // profile of every field
                                                   // above except
                                                   // receiptHash itself
}
```

### Append-Only Chain And Current-Validity Derivation

- `OperatingPointInvalidationReceipt` objects are append-only: a new
  observation always creates a new receipt with `predecessorReceiptHash`
  set to the prior receipt's `receiptHash` for the same
  `priorAcceptanceHash` chain. No receipt is ever edited or deleted.
- **Current validity is a derived read, never a stored/mutated flag on the
  acceptance binding itself, and `STALE` is monotonic (sticky) within one
  acceptance binding's chain -- it is never cleared by a later receipt on
  that same chain, only by a genuinely new acceptance.** To determine
  whether an `OperatingPointAcceptanceBinding` is currently valid, walk its
  **entire** receipt chain from the first receipt (the one whose
  `predecessorReceiptHash` is `null`) forward to the receipt with no
  successor (verified via `predecessorReceiptHash` linkage throughout, not
  by `checkedAtUtc` alone, since clock skew must not be authoritative over
  chain linkage). The walk does not stop at the latest receipt and read
  only its `comparisonResult`; it inspects **every** receipt in the chain,
  because a later `NO_CHANGE` receipt only proves no *new* trigger fired
  since the receipt before it -- it proves nothing about a `TRIGGER_MATCH`
  that already occurred earlier in the same chain, and reading only the
  latest receipt would silently erase that earlier finding without any new
  acceptance ever having happened. Derivation rule:
  The three derived states (`CURRENT`, `STALE`, `UNVERIFIED`) are computed
  by the following **strictly ordered, mutually exclusive** procedure --
  each step's condition is evaluated only if every earlier step's condition
  did not already apply, so exactly one state is ever returned and no two
  conditions can both be satisfied for the same chain:

  1. **STALE check (evaluated first):** if **any** receipt anywhere in the
     chain has `comparisonResult: TRIGGER_MATCH`, the derived status is
     `STALE`, full stop -- regardless of chain length, regardless of what
     any later receipt in the same chain reports, and regardless of trigger
     coverage. `STALE` never reverts to `CURRENT` within the same
     `OperatingPointAcceptanceBinding`'s chain; the only way to obtain a
     `CURRENT` status again is a **new** `OperatingPointAssessment`
     producing a **new** `OperatingPointAcceptanceBinding` (a new
     `bindingId`, a new `acceptanceFingerprint`, and consequently a new,
     empty receipt chain) -- matching T1's unchanged `invalidationAction`
     ("mark ... STALE and require a fresh `OperatingPointAssessment` before
     reliance; never automatic rollback or configuration mutation") read
     literally: reliance requires a *fresh assessment*, not a later
     favorable receipt on the stale chain.
  2. **UNVERIFIED check (evaluated only if step 1 did not apply):** if the
     chain does not satisfy step 1, but the chain is **empty**, **or** it
     contains fewer than six triggers each with at least one covering
     `NO_CHANGE` receipt (i.e. does not have at least one `NO_CHANGE`
     receipt for every one of the six triggers named in
     `## Invalidation Trigger Reconciliation` below), the derived status is
     `UNVERIFIED`. This closes two gaps at once: a zero-receipt chain has
     not had its current-state triggers checked even once, so "no evidence
     of staleness" is not the same claim as "verified current"; and a
     chain covering only a strict subset of the six triggers has likewise
     not established that every trigger is genuinely unchanged.
     `UNVERIFIED` behaves identically to `STALE` for every reliance
     decision (a consumer must not rely on an `UNVERIFIED` binding any more
     than a `STALE` one), but is reported under its own distinct label so a
     reviewer or checker can distinguish "never fully checked" from
     "checked and found changed."
  3. **CURRENT (the only remaining case):** if neither step 1 nor step 2
     applies -- i.e. no receipt in the chain is `TRIGGER_MATCH`, **and**
     every one of the six named triggers has at least one covering
     `NO_CHANGE` receipt on record -- the derived status is `CURRENT`.

  Because step 2 is evaluated only when step 1 already failed, and step 3
  is evaluated only when both step 1 and step 2 already failed, the three
  conditions can never overlap for the same chain; derived status is
  therefore always exactly one of `CURRENT`, `STALE`, or `UNVERIFIED`, with
  no fourth value and no ambiguous or doubly-satisfied case.
- **Stale-chain and forked-chain fail-closed behavior:** a receipt whose
  `predecessorReceiptHash` does not match any existing receipt's
  `receiptHash` for the same `priorAcceptanceHash` (a forked or
  out-of-order receipt) is rejected at ingestion with reason
  `INVALIDATION_CHAIN_FORK_REJECTED`; it is never appended, and it never
  becomes part of the derived-validity walk. A chain with more than one
  receipt claiming the same `predecessorReceiptHash` (an actual fork
  attempt) is likewise rejected for the second and later conflicting
  claimant; the first-ingested receipt at that chain position wins and the
  conflicting claimant is disclosed, never silently accepted.
- **Missing current-state source:** a receipt whose
  `observedCurrentStateSnapshot.source` is empty, or whose `observedFields`
  does not contain the fields this specific `trigger` requires, fails
  structural validation with reason `INVALIDATION_SNAPSHOT_SOURCE_MISSING`
  and is never ingested as a valid receipt; a trigger can never be marked
  `TRIGGER_MATCH` or `NO_CHANGE` from an absent or incomplete observation.

### Invalidation Trigger Reconciliation (Every Trigger Bound To A Verifiable Comparison, Not A Frozen Snapshot)

The T1 manifest's six invalidation triggers are unchanged in name and
intent. Each is now bound to an explicit, independently checkable
comparison performed at receipt-creation time, against either the immutable
acceptance binding's own content or a separately named live authority --
never against a frozen accept-time snapshot masquerading as forward-looking
provenance:

| Invalidation trigger (T1, unchanged name) | Comparison this receipt performs |
|---|---|
| `fixture_set_content_hash_changes_for_bound_task_class` | compare `observedFields.currentHeldOutFixtureSetAuthorityHash` (the round's currently-admissible authority hash, read live from the calibration-round decision owner's current issuance) against `OperatingPointAcceptanceBinding.heldOutFixtureSetAuthorityHash` |
| `candidate_config_or_bound_trace_result_or_producer_receipt_changes` | compare a freshly recomputed `orderedEvidenceEnvelopeHashes` over the candidate's current evidence against the bound `OperatingPointAcceptanceBinding.orderedEvidenceEnvelopeHashes` |
| `partition_rubric_environment_policy_acceptance_or_preference_policy_changes` | compare `observedFields.currentComparabilityFingerprint`/`currentPreferencePolicyHash` (read live) against the bound `comparabilityFingerprint`/`preferencePolicyHash` |
| `accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum` | compare `observedFields.providerLaneStatus` (read live from the provider-lane status registry named in `source`) against the round's predeclared allowed-status set; this is a live eligibility-gate re-check, explicitly not a comparison against any accept-time value, since T1's own rule requires readiness to be re-checked live, never frozen |
| `gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence` | compare `observedFields.gc026Attestation.recordContentHash` (read live from the GC-026 registry snapshot named in `source`) against the bound `promotionEvidenceRefOrRubricHash` |
| `accepted_candidate_budget_ceiling_lowered_below_recorded_consumption` | compare `observedFields.budgetCeiling` (read live from the budget ledger named in `source`) against `observedFields.budgetConsumed` (also read live); this is a live eligibility-gate re-check against current ledger state, not a comparison against any accept-time value |

This reconciliation table is the direct fix for R2-RV-F3: every trigger now
names exactly what is compared against what, and every comparison either
reads live current state (for the two triggers that are inherently
time-varying, exactly as T1 already required) or compares against the
immutable acceptance binding's own frozen content (for the four triggers
that are about a fact that was true or false at accept time and can be
verified against a fixed historical record). No trigger claims a frozen
historical hash can detect a future change by itself; the receipt's live
comparison is what detects it, and the receipt -- not the acceptance binding
-- is what changes over time.

## Checker And Test Contract

### Per-Edge Owner Table

For every equality, membership, coverage, and preimage edge this contract
defines, this table states whether the TypeScript decision owner, the
Python persisted-evidence checker, or both enforce it, and the exact fail
behavior. `BOTH_INDEPENDENT` means the Python checker independently
recomputes the same value from the same typed inputs under
`cvf.taskClassCalibration.rootContractHash.v1` rather than trusting a
TypeScript-computed field.

| Edge | Owner | Mandatory path | Fail result |
|---|---|---|---|
| `HeldOutFixtureSetAuthority.authorityHash == recompute(fields)` under the canonical profile | `BOTH_INDEPENDENT` | every authority issuance | non-empty violation naming the mismatch |
| Authority issuer is exactly `CALIBRATION_ROUND_DECISION_OWNER`; `issuedAtUtc` precedes every governed candidate evaluation timestamp | TypeScript decision-time; Python checker validates the literal issuer field and timestamp ordering against persisted evidence | every authority issuance | inadmissible authority for the round |
| `issuerAttestationRef.attestationContentHash == recompute({registrySnapshotHash, attestedIssuerIdentity, authorityId, issuedAtUtc})` under the canonical profile (a structural non-repudiation check only; does not by itself prove real issuer identity) | `BOTH_INDEPENDENT` | every authority issuance | non-empty violation naming the mismatch; authority inadmissible for the round |
| `IssuerVerificationReceipt.receiptHash == recompute(fields)` under the canonical profile | `BOTH_INDEPENDENT` | every issued receipt | non-empty violation naming the mismatch |
| an admissible `IssuerVerificationReceipt` exists for the referenced authority (`verifiedAuthorityHash` match, `verifiedRegistrySnapshotHash` matches the authority's own `issuerAttestationRef.registrySnapshotHash`, `verifiedAtUtc >= issuedAtUtc`, `lookupResult == IDENTITY_CONFIRMED_DECISION_OWNER_ROLE`) -- the actual admission gate; a self-set status field is structurally impossible since no such field exists on the authority | live registry lookup performed by a separately-governed, out-of-scope component to produce the receipt; Python checker independently re-checks every one of the receipt's binding conditions against the persisted authority, never trusting a bare status string | every authority reference used in any candidate evaluation | `insufficient_evidence`, reason `AUTHORITY_ISSUER_UNVERIFIED` |
| `requiredEvidenceSnapshotRef` present and `snapshotContentHash == recompute(referenced requiredEvidence[] snapshot content)` (mandatory acceptance precondition, not optional-if-attached) | `BOTH_INDEPENDENT` | every persisted `OperatingPointAcceptanceBinding`, unconditionally | `UNVERIFIABLE_ACCEPTANCE_NO_SNAPSHOT` if absent; non-empty violation naming the mismatch if present but incorrect |
| Candidate `requiredEvidence[]` covers referenced authority's `requiredMembers` (coverage-equality) | TypeScript only, decision-time (requires the live authority object as input) | every candidate decision | `insufficient_evidence`, naming uncovered `fixtureId`(s) |
| `requiredEvidence[]`/`supplementalEvidence[]` field-disjointness by `fixtureId` against the referenced authority | `BOTH_INDEPENDENT`: TypeScript validates at structural-parse time; Python checker independently re-validates against the persisted authority snapshot | every candidate envelope | `EVIDENCE_TOPOLOGY_MISPLACEMENT` structural failure |
| Every `requiredEvidence[]` entry reaches `PASS_WITH_EVIDENCE` | TypeScript only (decision-time) | every candidate decision | `insufficient_evidence` |
| `supplementalEvidence[]` never read by any decision-path function | TypeScript only, by construction (no function signature accepts `supplementalEvidence[]` as an input parameter) | every candidate decision | N/A -- structurally absent from every decision function's parameter list, verified by the mandatory regression test below |
| `OperatingPointAcceptanceBinding.acceptanceFingerprint == recompute(the eleven explicitly named fields, including requiredEvidenceSnapshotRef)` under the canonical profile | `BOTH_INDEPENDENT` | any accepted operating point | non-empty violation naming the mismatch; a document whose `requiredEvidenceSnapshotRef` was swapped after acceptance is caught here, since the swap changes the recomputed fingerprint |
| `orderedEvidenceEnvelopeHashes` content/order recomputation | `BOTH_INDEPENDENT`: Python checker recomputes from a supplied `requiredEvidence[]` snapshot and rejects if the persisted value disagrees. **The evidence-set snapshot is a mandatory precondition for acceptance, not an optional attachment (closes the unverifiable-acceptance gap):** a persisted document claiming `ACCEPTED_PREFERRED`/`OperatingPointAcceptanceBinding` status without an attached `requiredEvidence[]` snapshot is itself rejected with `UNVERIFIABLE_ACCEPTANCE_NO_SNAPSHOT`, a distinct, terminal, always-failing disposition -- **never** `PROVENANCE_RECOMPUTATION_UNAVAILABLE_NO_SNAPSHOT` treated as a tolerated non-failing state. The `UNAVAILABLE_NO_SNAPSHOT` marker is retired from this contract; independent recomputability (Acceptance Criterion 6) requires the snapshot to exist, not merely to be checked when present | every persisted `OperatingPointAcceptanceBinding`/accepted operating point, unconditionally -- there is no acceptance path that omits the snapshot | non-empty violation naming the mismatch; or `UNVERIFIABLE_ACCEPTANCE_NO_SNAPSHOT` (a hard rejection, not a disclosed-but-tolerated pass) when no snapshot is attached at all |
| `OperatingPointInvalidationReceipt.receiptHash == recompute(fields)` under the canonical profile | `BOTH_INDEPENDENT` | every receipt | non-empty violation naming the mismatch |
| `predecessorReceiptHash` chain linkage (no fork, no orphan) | `BOTH_INDEPENDENT`: TypeScript rejects at ingestion; Python checker independently re-walks the persisted chain and rejects a document containing an unlinked or forked receipt | every receipt ingestion and every persisted chain read | `INVALIDATION_CHAIN_FORK_REJECTED` or non-empty violation |
| Derived current-validity status (`CURRENT`/`STALE`/`UNVERIFIED`) is computed by a full chain walk (every receipt inspected, not only the latest), never read from a stored mutable field on the acceptance binding, and `STALE` is monotonic within one chain | TypeScript only (the acceptance binding schema has no validity-status field to read); Python checker rejects any persisted `OperatingPointAcceptanceBinding` document that carries a validity/status field at all, since none is defined, and independently re-walks the full persisted receipt chain rather than trusting a caller-supplied derived status anywhere it appears in a review artifact | any persisted acceptance binding document; any document or claim citing a derived validity status | non-empty violation naming the forbidden field, if present; or non-empty violation naming the mismatch if a claimed derived status disagrees with the independently recomputed full-chain-walk result |

### Positive Controls And Mandatory Regression Tests

A future implementation of this contract must include, at minimum, tests
that independently reproduce and reject every R2-RV probe plus this
contract's own new edges:

1. **Positive control:** a candidate whose `requiredEvidence[]` exactly
   covers an admissible `HeldOutFixtureSetAuthority`'s `requiredMembers`,
   every entry bound `PASS_WITH_EVIDENCE`, reaches `preferred` under an
   admissible authority.
2. **F1 regression (authority ownership, mandatory):** an authority object
   claiming any `issuedBy` value other than `CALIBRATION_ROUND_DECISION_OWNER`,
   or issued after a governed candidate's evaluation timestamp, must be
   rejected as inadmissible; no candidate-constructed authority is ever
   admissible regardless of shape.
3. **F1 regression (partition binding, mandatory):** two candidates
   referencing authorities with the same `requiredMembers` but different
   `partitionId` must never be treated as comparable or interchangeable;
   an authority hash computed without `partitionId` in its preimage would
   fail this test, since this contract's authority hash includes it.
4. **F1/topology regression (evidence-set laundering, mandatory; corrected
   to match the two-phase evaluation order):** a candidate carrying a
   required-member `fixtureId` inside `supplementalEvidence[]` instead of
   `requiredEvidence[]` must fail at **Phase 1** with
   `EVIDENCE_TOPOLOGY_MISPLACEMENT`, naming that `fixtureId` -- **not**
   `insufficient_evidence`/`MISSING_REQUIRED_FIXTURE`, since the envelope
   never reaches Phase 2's coverage-equality check at all once Phase 1
   rejects it. A test asserting `MISSING_REQUIRED_FIXTURE` for this exact
   case is itself wrong and must be rejected; the only correct assertion is
   `EVIDENCE_TOPOLOGY_MISPLACEMENT`. (A separate, genuinely distinct case --
   a required member absent from **both** `requiredEvidence[]` and
   `supplementalEvidence[]` in an otherwise Phase-1-valid envelope -- is
   what legitimately reaches `MISSING_REQUIRED_FIXTURE` at Phase 2; that
   case is covered by the coverage-equality rule in
   `## Selected Architecture Decision 1`, not by this regression item.) The
   coverage check must never fall back to reading `supplementalEvidence[]`
   under any circumstance.
5. **F2 regression (delimiter collision, mandatory):** the exact
   `['a,b','c']` versus `['a','b,c']` vectors published above must produce
   two different digests under any implementation of
   `cvf.taskClassCalibration.rootContractHash.v1`; a test that computes both
   and asserts inequality is mandatory, not optional.
6. **F2 regression (array-reorder, mandatory):** the published array-reorder
   vector must produce the identical digest regardless of caller-supplied
   `requiredMembers` order; a test asserting this equality is mandatory.
7. **F3 regression (acceptance immutability, mandatory):** attempting to
   construct or serialize an `OperatingPointAcceptanceBinding` with any
   validity/status field must fail to type/structurally-validate, since no
   such field exists in the schema; a persisted document carrying one
   anyway must be rejected by the checker as a forbidden field.
8. **F3 regression (derived validity via full chain walk, mandatory):**
   given one acceptance binding and an append-only receipt chain containing
   at least one `TRIGGER_MATCH` receipt anywhere in the chain, the derived
   current-validity read must return `STALE`, **even when a later receipt
   in the same chain reports `NO_CHANGE`** -- a test that appends a
   `NO_CHANGE` receipt after an existing `TRIGGER_MATCH` receipt on the same
   `priorAcceptanceHash` and asserts the derived status is still `STALE`
   (never reverts to `CURRENT`) is mandatory, not optional, and is the
   direct regression for the sticky/monotonic `STALE` rule. Given a chain
   whose every receipt reports `NO_CHANGE`, the derived read must return
   `CURRENT`. Given zero receipts, the derived read must return
   `UNVERIFIED`, never `CURRENT`. Given receipts covering only some of the
   six named triggers with `NO_CHANGE` and no receipt at all for the
   remaining triggers, the derived read must return `UNVERIFIED`, never
   `CURRENT`. Mutating the acceptance binding itself, or reading only the
   latest receipt in the chain instead of walking the full chain, must
   never be a code path available to satisfy any of these cases.
9. **F3 regression (forked/stale chain, mandatory):** a receipt whose
   `predecessorReceiptHash` does not match any existing chain-tip receipt
   must be rejected at ingestion, and a second receipt claiming the same
   `predecessorReceiptHash` as an already-ingested receipt must also be
   rejected; neither becomes part of the derived-validity walk.
10. **Issuer-attestation structural regression (mandatory; this is a
    non-repudiation check, not proof of real issuer identity by itself):**
    an authority whose `issuerAttestationRef.attestationContentHash` does
    not match `recompute({registrySnapshotHash, attestedIssuerIdentity,
    authorityId, issuedAtUtc})` must be rejected as inadmissible; an
    authority attempting to omit `issuerAttestationRef` entirely, or to
    reuse one authority's `issuerAttestationRef` verbatim on a different
    `authorityId`/`issuedAtUtc` pair, must also be rejected, since the
    attestation content hash binds those exact fields and would no longer
    match.
10a. **Issuer-verification admission regression (mandatory, the actual
    closure of the self-asserted-literal gap; corrected to a receipt-based
    check after Local found a bare status field is itself self-settable):**
    an authority with no accompanying `IssuerVerificationReceipt` must be
    rejected for any candidate evaluation with reason
    `AUTHORITY_ISSUER_UNVERIFIED`, **even when its own
    `issuerAttestationRef.attestationContentHash` check (item 10) passes**
    -- structural consistency of the authority alone must never be treated
    as sufficient for admission. A test constructing an authority together
    with a self-authored `IssuerVerificationReceipt` whose
    `verifiedAuthorityHash` matches, but whose `verifiedRegistrySnapshotHash`
    deliberately differs from the authority's own
    `issuerAttestationRef.registrySnapshotHash`, must also be rejected --
    a receipt verifying a *different* snapshot than the one the authority
    itself cites must not count. Only an authority for which an admissible
    `IssuerVerificationReceipt` (passing every one of its own binding
    checks: matching `verifiedAuthorityHash`, matching
    `verifiedRegistrySnapshotHash`, `verifiedAtUtc >= issuedAtUtc`, and
    `lookupResult == IDENTITY_CONFIRMED_DECISION_OWNER_ROLE`) exists may be
    referenced by any candidate's `heldOutFixtureSetAuthorityHash`.
11. **Unverifiable-acceptance regression (mandatory, closes the missing-
    snapshot-as-tolerated-pass gap):** a document claiming
    `ACCEPTED_PREFERRED` or constructing an `OperatingPointAcceptanceBinding`
    with no `requiredEvidenceSnapshotRef`, or with a
    `requiredEvidenceSnapshotRef.snapshotContentHash` that does not match
    the independently recomputed hash of the referenced snapshot content,
    must be rejected with `UNVERIFIABLE_ACCEPTANCE_NO_SNAPSHOT` or a
    non-empty mismatch violation, never accepted as `PASS` or silently
    passed through as a disclosed-but-tolerated state.
12. **Snapshot-binding regression (mandatory, closes the acceptanceFingerprint
    preimage-boundary gap):** given one accepted, persisted
    `OperatingPointAcceptanceBinding` with a valid `acceptanceFingerprint`,
    replacing only its `requiredEvidenceSnapshotRef` (either
    `snapshotContentHash` or `snapshotRef`) with a different,
    still-internally-self-consistent value, without recomputing
    `acceptanceFingerprint`, must produce a persisted document whose
    `acceptanceFingerprint` no longer matches the independent recomputation
    -- i.e. the substitution must be caught as a non-empty violation. A
    test that swaps `requiredEvidenceSnapshotRef` and finds
    `acceptanceFingerprint` still matches indicates the field was wrongly
    excluded from the preimage and is itself a defect.

## Migration / Successor Boundary

| Parked path | Disposition | Reason | Named future successor path |
|---|---|---|---|
| `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/task.class.calibration.owner.contract.ts` | `DISCARD_WITH_REASON` | Superseded by `HeldOutFixtureSetAuthority`/`requiredEvidence`/`supplementalEvidence`; structural shape change | same path, new implementation, future work order |
| `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/tests/task.class.calibration.owner.contract.test.ts` | `DISCARD_WITH_REASON` | Fixture builders assume a superseded shape | same path, new test suite against `## Checker And Test Contract` |
| `docs/audits/CVF_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md` | `DISCARD_WITH_REASON` | Documents the R2-rejected implementation's now-superseded design | future implementation audit, batch ID not yet assigned |
| `docs/reference/agent_system_skills/CVF_TASK_CLASS_CALIBRATION_OWNER_CONTRACT.md` | `REPLACE_IN_SEPARATE_IMPLEMENTATION` | Must describe this contract's schema; out of this tranche's three-path manifest | same path, rewritten under future implementation work order |
| `docs/reviews/CVF_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_WORKER_RETURN_2026-09-17.md` | `DISCARD_WITH_REASON` | Rejected worker's own self-report, superseded by the R2 rejection chain | future worker return, batch ID not yet assigned |
| `governance/compat/check_task_class_calibration_owner_evidence.py` | `DISCARD_WITH_REASON` | Mirrors the superseded topology and join-based hashing this contract eliminates; `BOTH_INDEPENDENT` pattern reusable conceptually | same path, new checker, future work order |
| `governance/compat/test_check_task_class_calibration_owner_evidence.py` | `DISCARD_WITH_REASON` | Fixtures assume the superseded schema | same path, new test suite |
| `docs/audits/CVF_ACEL_G1_T2A_CANDIDATE_EVIDENCE_BINDING_SCHEMA_AMENDMENT_2026-09-17.md` | `DISCARD_WITH_REASON` | Terminally rejected at `STOP_REASSESS_ARCHITECTURE`; fresh design, not a repair | none; closed, rejected evidence |
| `docs/audits/CVF_ACEL_G1_T2A_CANDIDATE_EVIDENCE_BINDING_SCHEMA_AMENDMENT_MANIFEST_2026-09-17.json` | `DISCARD_WITH_REASON` | Same reasoning | none |
| `docs/reviews/CVF_ACEL_G1_T2A_CANDIDATE_EVIDENCE_BINDING_SCHEMA_AMENDMENT_WORKER_RETURN_2026-09-17.md` | `DISCARD_WITH_REASON` | Same reasoning | none |

None of the ten parked paths is modified, staged, or committed by this
tranche. All ten remain exactly as R2 left them, uncommitted and parked,
pending Local's own future implementation dispatch decision.

## Findings / Position

This contract implements all four GC-018 architecture decisions without an
alternative topology, and closes all three applicable R2-RV findings (F4 was
a T2A gate-reporting defect, not a design defect, and is preserved here only
as a behavioral lesson in `## Risk / Corrective Action`, not as a design
rule):

- **R2-RV-F1** is closed by `HeldOutFixtureSetAuthority` naming a single
  fixed issuer role, binding `partitionId` and `comparabilityFingerprint`
  directly into its own hash, and by the `requiredEvidence`/
  `supplementalEvidence` field-disjointness rule replacing T2A's
  extras-inside-required-field topology.
- **R2-RV-F2** is closed by one reusable, RFC 8785 JCS-based canonical
  serialization profile used for every hash in this document, with a
  published positive vector, a computed delimiter-collision negative vector
  reproducing the exact prior collision and proving it no longer occurs, and
  an array-reorder vector proving set-semantic fields are order-independent.
- **R2-RV-F3** is closed by separating immutable
  `OperatingPointAcceptanceBinding` from append-only
  `OperatingPointInvalidationReceipt`, deriving current validity by chain
  walk rather than by querying a frozen snapshot field, and reconciling
  every one of the six T1 invalidation triggers to an explicit, independently
  checkable comparison rather than an implicit claim.

No accepted T1 design rule outside these four findings is altered: decision
state precedence (`incomparable` > `insufficient_evidence` > `ineligible` >
`eligible_nonpreferred`/`preferred`), the SEARCH/HELD_OUT contamination
rule (`REUSED_HELDOUT_SEARCH_DATA`), G3 repeat-policy semantics, the
no-score-laundering invariant, and every T1 negative case not touched by
this reassessment (`empty_candidate_set`, `duplicate_candidate_ids`,
`mixed_task_case_sets`, `unequal_budgets_or_policies`, `stale_fingerprints`,
`incomplete_repeats`, `unknown_metrics_or_units`, `ties`,
`no_eligible_candidate`, `proposal_only_performance_advantage`) are all
unchanged and are not affected by this contract's field-level and
provenance-model changes.

## Risk / Corrective Action

| Risk | Mitigation | Residual |
|---|---|---|
| A bare `issuedBy` literal, and then a bare `issuerVerificationStatus` field, are both self-settable by whoever constructs the authority -- found twice across two Local review rounds, each time closed by removing the self-settable field rather than merely disclosing the limit | `issuerAttestationRef` (structural non-repudiation only) plus a separately-issued, independently-hashed `IssuerVerificationReceipt` that a real, out-of-scope live registry lookup must produce before an authority derives `VERIFIED_BY_LIVE_REGISTRY_LOOKUP`; regression tests 2, 10, and 10a assert every self-settable/self-authored bypass is rejected | Accepted: this contract can require the receipt's existence and internal consistency, but cannot itself perform the live lookup that produces a *genuine* one; a future implementation that fabricates receipts wholesale (not merely a bare field) is outside what a design-only tranche can prevent, and remains Local review's responsibility for any future implementation |
| A future implementer could reintroduce string-joining for a new field this contract did not anticipate | This document states the canonical profile applies to every hash "without exception" and requires any new hashed object type to declare its own fixed field list under the same profile, not invent a new ad hoc scheme | Accepted: enforcement depends on future authors reading and following this contract; the mandatory delimiter-collision regression test (item 5), now published against a schema-valid `CandidateFixtureEvidenceEnvelopeHash` object with two complete preimages rather than an unreproducible vector, is the concrete backstop for the fields this document does define |
| An accepted operating point could exist with no attached evidence snapshot, making its provenance permanently unverifiable while still counting as accepted -- an earlier draft of this contract tolerated exactly this via a `PROVENANCE_RECOMPUTATION_UNAVAILABLE_NO_SNAPSHOT` marker, found and closed during this same authoring pass | `requiredEvidenceSnapshotRef` is now a mandatory, non-empty field on `OperatingPointAcceptanceBinding`; a document lacking it fails with `UNVERIFIABLE_ACCEPTANCE_NO_SNAPSHOT`, a hard rejection, never a tolerated pass; the mandatory regression test (item 11) asserts this | Accepted: enforcement depends on the checker actually running before any acceptance is relied upon; this contract cannot itself force that invocation order in a future implementation, only state it as a mandatory precondition |
| `requiredEvidenceSnapshotRef` could be swapped for a different, still-self-consistent snapshot after acceptance without changing `acceptanceFingerprint`, since an earlier schema draft defined the fingerprint as "every field above" a definition line the field was declared below -- found and closed during this same authoring pass | `acceptanceFingerprint`'s preimage now explicitly names all eleven bound fields, including `requiredEvidenceSnapshotRef`; regression test 12 asserts a post-hoc swap is caught by `BOTH_INDEPENDENT` recomputation | Accepted: this closes the specific ambiguity Local found; a future implementation adding a twelfth field to this object must extend the explicit list, not rely on positional "above" language, to avoid reintroducing the same class of gap |
| A candidate whose required-member `fixtureId` is misplaced in `supplementalEvidence[]` could reach two different, unordered outcomes (`EVIDENCE_TOPOLOGY_MISPLACEMENT` and `insufficient_evidence`/`MISSING_REQUIRED_FIXTURE`) depending on evaluation order -- found and closed during this same authoring pass | The two-phase evaluation order in `## Selected Architecture Decision 2` makes Phase 1 (structural validation) a hard gate that terminates evaluation before Phase 2 (admission/coverage) ever runs, so exactly one outcome is reachable for any given envelope, never both | Accepted: this is a specification-level fix; a future implementation must actually implement two ordered, non-short-circuiting-in-the-wrong-direction phases, which the mandatory regression tests are the backstop for, not a runtime guarantee this document itself provides |
| The append-only receipt chain could grow unbounded for a long-lived accepted operating point, raising storage/read cost | Out of scope for this design-only tranche; a future implementation may add chain compaction/archival as an operational concern, provided it never violates append-only history or forges a `predecessorReceiptHash` | Accepted: performance/storage engineering is explicitly deferred to a future, separately-reviewed implementation tranche |
| This contract cannot itself prove a future implementation will correctly realize it; only Local review of that future implementation can | Every design rule states machine-checkable pass/fail behavior precisely enough that `## Checker And Test Contract` could be authored directly from this document | Accepted: this is a design artifact; implementation correctness proof is out of scope and remains a future, separately-reviewed work order |
| R2-RV-F4's lesson (a disclosed gate failure was reported alongside `COMPLETE_PENDING_REVIEW` instead of `BLOCKED_WITH_REASON`) is a worker-return behavioral defect, not something this design document can fix by itself | This tranche's own worker return applies the corrected rule directly: any required-gate failure, even truthfully disclosed and correctly scope-classified, produces `BLOCKED_WITH_REASON`, never `COMPLETE_PENDING_REVIEW` | Accepted: this is a process discipline applied in this tranche's own return, not a schema rule; recorded here for completeness since it is one of the four R2-RV findings |

## Decision / Disposition

`WORKER_COMPLETE_PENDING_REVIEW`. This contract implements all four GC-018
architecture decisions verbatim (field names refined per the baseline's
explicit allowance), closes R2-RV-F1 through F3 by eliminating each root
cause rather than adding a check around the same structure, and applies the
R2-RV-F4 process lesson directly to this tranche's own worker return. This
revision additionally repairs four defects found during Local review of the
first T2B draft: (1) the delimiter-collision test vector originally varied a
`traceIds` field on `HeldOutFixtureSetAuthority`, a type with no such field,
and was not reproducible against this contract's own schema -- replaced
with two complete, valid preimages against `CandidateFixtureEvidenceEnvelopeHash`;
(2) the negative-case table let a required-member `fixtureId` misplaced in
`supplementalEvidence[]` reach two contradictory outcomes -- resolved by an
explicit, mandatory two-phase evaluation order; (3) the current-validity
derivation read only the latest receipt, which could silently erase an
earlier `TRIGGER_MATCH` finding without any new acceptance, and treated a
zero-receipt chain as unconditionally `CURRENT` with no proof anything was
ever checked -- resolved by a full-chain walk with a sticky/monotonic
`STALE` state and a new `UNVERIFIED` state for never-checked bindings; (4)
the `issuedBy` literal was self-asserted with no independent proof of real
issuance authority, and an accepted operating point could exist with no
attached evidence snapshot while a `PROVENANCE_RECOMPUTATION_UNAVAILABLE_NO_SNAPSHOT`
marker tolerated that as a non-failure -- resolved by a mandatory
`issuerAttestationRef` (with an explicit honesty statement on what it can
and cannot prove) and a mandatory `requiredEvidenceSnapshotRef` precondition
for acceptance. All ten parked paths were read-only throughout; their
SHA-256 hashes are reconciled unchanged in the paired worker return. No
implementation, provider/live, runtime, configuration-mutation, G4,
public-sync, or deployment claim is made. Local review and acceptance
remain a separate, later step.

## Public Export Disposition

DEFERRED_PRIVATE_ONLY

Reason: this audit references private CVF provenance architecture, a
terminally rejected prior design's exact defects, and repository-internal
review findings; public-safe export requires separate redaction and
public-sync authorization.

## Claim Boundary

This audit records a fresh schema/design architecture reassessment only. It
does not implement, test, execute, or accept any TypeScript/Python code;
does not modify, stage, or commit any of the ten parked evidence paths; and
does not authorize provider/live execution, real calibration, configuration
mutation, G4, runtime wiring, public sync, or deployment. Local review and a
separate future implementation work order are required before any rule in
this document takes effect in running code.
