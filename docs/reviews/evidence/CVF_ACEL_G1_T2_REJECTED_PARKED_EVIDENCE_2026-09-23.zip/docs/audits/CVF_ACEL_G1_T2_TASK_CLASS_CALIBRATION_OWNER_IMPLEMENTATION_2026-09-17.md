# CVF ACEL G1 T2 Task-Class Calibration Owner Implementation Audit

Memory class: governed-implementation-audit

docType: audit

Status: WORKER_COMPLETE_PENDING_REVIEW

Batch ID: ACEL-G1-T2-TASK-CLASS-CALIBRATION-OWNER-IMPLEMENTATION

EPISTEMIC_PROCESS_NA_WITH_REASON: implementation audit of a fixed-schema
decision-layer contract; it records source verification, symbols
implemented, and test/gate counts rather than testing a new empirical
hypothesis.

## R2 Consolidated Repair Pass (2026-09-17)

This audit is extended for R2, a second consolidated repair pass fixing
three further correctness gaps that Local's independent semantic review of
the R1-repaired code (not just R1's passing gates) found. R2 modifies the
same seven paths in place; it creates no eighth file. R2 also performed a
Local-executed, separately verified fix for a real `governed file size
compatibility` gate trap (`near_hard_statement_compression`) that R2's own
edits (plus a background trimming pass) drove file 1 into; that fix and its
independent verification are recorded in `## R2 Governed File Size Fix
(Local-Executed, Independently Verified)` below.

### R2 Negative-Case-To-Fix Matrix

| Finding | Root defect (post-R1) | Fix (R2) | Covering test(s) |
|---|---|---|---|
| R2-1 -- round-level G3 fixture-set admission was informational only, never gated eligibility; happy-path test contradicted the design's positive+negative requirement | `admitFixtureSet` result was pushed into `exclusions` as a disclosure-only note; no candidate's `state` was ever changed by it. The R1 happy-path test used `makeValidG3Fixture()` (POSITIVE only, no negative fixture anywhere in the round) yet still asserted `roundOutcome === "ACCEPTED_PREFERRED"` and a non-null `RegressionBinding` | Round-level `admitFixtureSet` result now genuinely gates eligibility: when `roundFixtureSetAdmission.admission !== "ADMITTED"`, every candidate that would otherwise reach `eligible_nonpreferred`/`preferred` instead fails closed to `insufficient_evidence`, naming the round-level admission failure. The round-level disclosure entry in `exclusions` is retained for transparency. The former happy-path test and other fixtures were reworked so the round's pooled `g3Fixture` set is genuinely POSITIVE+NEGATIVE admitted | New/updated tests in `evaluateTaskClassCalibrationRound - happy path` and a dedicated `round-level G3 fixture-set admission gates eligibility` test group: POSITIVE-only pooled fixtures fail every candidate to `insufficient_evidence`; POSITIVE+NEGATIVE pooled fixtures allow the intended candidate through to `preferred` |
| R2-2 -- no cross-check that a candidate's declared `taskClassId` matched the round's `taskClassId`; `candidateConfigHash`/`comparabilityFingerprint` were never independently verified against their constituent declared fields | `env.taskClassId` was never compared against `typedInput.taskClassId`; `candidateConfigHash` and `comparabilityFingerprint` remained pure caller-supplied opaque strings, never recomputed or cross-checked, even though `composeComparabilityFingerprintPreimage` was already exported but never invoked inside `evaluateTaskClassCalibrationRound`. The R1 audit had labeled fingerprint verification "out of R1's bounded scope," which Local's R2 review identified as an in-scope continuation of the same binding-verification requirement, not a new scope expansion | Added a per-candidate `env.taskClassId !== typedInput.taskClassId` (or missing/malformed) check failing closed to `insufficient_evidence`. Added `recomputeCandidateConfigHash` (`sha256Hex` over a canonical, stable-sorted-keys JSON serialization of `declaredDimensions`) and a comparison against the candidate's declared `candidateConfigHash`; a mismatch fails closed to `insufficient_evidence`. Added a `comparabilityFingerprint` recompute via `composeComparabilityFingerprintPreimage` over the candidate's own declared constituent fields (`canonicalVersion`, `taskClassId`, `fixtureSetContentHash`, `environmentDescriptorHash`, `policyId`, `acceptanceCriteriaVersion`, `gradingRubricVersionHash`, `heldoutPartitionHash`), hashed and compared against the candidate's declared `comparabilityFingerprint`; a mismatch fails closed to `insufficient_evidence` (a *single* candidate's own fingerprint being unverifiable/fabricated -- distinct from the pre-existing cross-candidate `incomparable` state used when two internally-consistent candidates' fingerprints differ from each other). The prior "out of R1's bounded scope" risk-table entry is removed and replaced by this fix | New tests: candidate `taskClassId` mismatch fails closed; candidate `candidateConfigHash` not matching the recomputed hash of `declaredDimensions` fails closed; candidate `comparabilityFingerprint` not matching the recomputed preimage hash fails closed; existing tests reworked so their fixtures supply genuinely derived (not arbitrary-literal) `candidateConfigHash`/`comparabilityFingerprint` values, confirming the positive path still passes under the new verification |
| R2-3 -- GC-026 promotion authority was caller-asserted only; no attestation structure was verified | `hasAdmissibleBoundEvidence` accepted `GC026_PROMOTED_PERFORMANCE_REFERENCE` whenever `promotionRecordRef`/`promotedAt` were merely non-empty strings -- proving nothing about a real GC-026 promotion actually existing; any caller-fabricated string could obtain `preferred` plus a `RegressionBinding` | Per Local's explicit direction (this module is pure/offline and must never perform I/O or call a real registry), added a caller-supplied, internally-verifiable attestation structure: `TaskClassCalibrationGc026Attestation` (`registrySnapshotHash`, `recordContentHash`, `recordContent: {taskClassId, candidateConfigHash, promotionRecordRef, promotedAt}`). `recordContentHash` must equal `recomputeGc026RecordContentHash(recordContent)` (an independently recomputable `sha256Hex` over the canonical serialization of `recordContent`) -- structural/hash validity is checked in `hasAdmissibleBoundEvidence`. The attestation's `recordContent.taskClassId`/`recordContent.candidateConfigHash` must name the same candidate being preferred -- checked at candidate-selection time in the preference stage (an attestation for a different candidate/task-class is never reusable to promote this one), mirroring R1 Finding 1's producer-receipt binding check. This raises the bar above "any non-empty string wins" while staying pure (verifies internal consistency of a caller attestation, never contacts a real registry -- exactly as G3's `gradeBehavioralEvaluation` never contacts a real provider but still meaningfully validates structural/consistency claims). The rubric-kind (`PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC`) authority path was left unchanged by R2 -- disclosed as an asymmetry below, not silently left unconsidered | New tests: attestation missing/malformed fails closed; attestation `recordContentHash` not matching the recomputed hash of `recordContent` fails closed; attestation `recordContent` naming a different `taskClassId`/`candidateConfigHash` than the candidate being preferred fails closed; a fully consistent, correctly-bound attestation still reaches `preferred` |

## R1 Consolidated Repair Pass (2026-09-17)

This audit is rewritten for R1, a consolidated repair pass fixing four
correctness gaps that Local's independent review of the actual decision
logic found in the original G1-T2 return (which had returned
`COMPLETE_PENDING_REVIEW` with all gates passing, but whose tests matched
its own incomplete implementation rather than the normative design). R1
modifies the same seven paths in place; it creates no eighth file. This
section, and the sections below, describe R1's findings, fixes, and fresh
gate evidence specifically -- not a re-timestamp of the original text.

### Negative-Case-To-Fix Matrix

| Finding | Root defect (original return) | Fix (R1) | Covering test(s) |
|---|---|---|---|
| 1 -- binding not verified | `validateEnvelopeStructure` only checked array-length consistency and non-empty `producerReceiptRef`; `gradeBehavioralEvaluation`/`admitFixtureSet` were imported only in a comment, never invoked | Added structured `producerReceipt` (`{receiptRef, candidateId, candidateConfigHash, traceIds}`) compared against the presenting envelope's own identity; added `g3Fixture`/`g3Traces`/`g3PairedFixture` fields; genuinely invoke `gradeBehavioralEvaluation` and cross-check its `BehavioralEvaluation` against declared `fixtureContentHash`/`traceContentHashes`/a real recomputed `g3ResultHash`; genuinely invoke `admitFixtureSet` once per round over the pooled fixtures | `R1 Finding 1: candidate misattribution despite a passing G3 result` (8 tests: receipt/candidate mismatch, receipt/config mismatch, receipt/traceIds mismatch, wrong `g3ResultHash`, wrong `fixtureContentHash`, wrong `traceContentHashes`, G3-disagreeing `g3Result`, positive control) |
| 2 -- preference authority too permissive; score coverage incomplete | Authority admitted on `kind`+`ref` alone; `valueByCandidateId` silently filtered to only scored candidates before computing the winner | Added `hasAdmissibleBoundEvidence`: `GC026_PROMOTED_PERFORMANCE_REFERENCE` requires `promotionRecordRef`+`promotedAt`; the rubric kind requires a canonical `rubricVersionHash`; missing coverage for any eligible candidate now yields `NO_ADMISSIBLE_PREFERENCE_EVIDENCE` for the whole round | `R1 Finding 2: preference authority bound-evidence requirements` (5 tests: missing GC026 fields, malformed rubric hash, incomplete score coverage, PROPOSAL_ONLY still inadmissible, no-score-laundering still holds) |
| 3 -- fingerprint not hashed; binding could be CURRENT with empty boundAt | `provenanceFingerprint` was the raw pipe-joined preimage string, never hashed; `boundAt` defaulted to `""` while `invalidationStatus` was unconditionally `"CURRENT"` | Added `sha256Hex` (Node `crypto.createHash("sha256")`) and compute the real digest; when `acceptedAt` is missing/empty at preferred-outcome time, withhold `regressionBinding` entirely (`null`) rather than emit `CURRENT`+empty `boundAt` | `R1 Finding 3: real SHA-256 provenanceFingerprint and boundAt/CURRENT consistency` (5 tests: canonical-hash shape, determinism, changes-with-input, withheld-on-missing-acceptedAt, withheld-on-empty-string-acceptedAt, non-empty-boundAt-when-supplied) |
| 4 -- no schema marker; checker silently skipped real output | `OperatingPointAssessment`/`RegressionBinding` never set `schemaVersion`/`contractMarker`, so the Python checker's `_declares_contract` always returned `False` for real TS output, returning `[]` regardless of validity; `preferenceAuthority` was absent from the assessment shape | Added `schemaVersion: "cvf.taskClassCalibrationOwner.assessment.v1"` / `"...regressionBinding.v1"`; added `preferenceAuthority` to `OperatingPointAssessment`; added Python-side bound-evidence field checks mirroring `hasAdmissibleBoundEvidence` | `R1 Finding 4: schemaVersion and preferenceAuthority in output shape` (4 TS tests) plus `RealTypeScriptOutputRoundTripTests` (5 Python tests: real-shape accept, real-binding accept, end-to-end file-check accept, missing-provenanceFingerprint reject, inconsistent-preferred-state reject, missing-boundAt reject) |

## Purpose

Record the `INTERNAL_AGENT` worker's R1 findings, exact code changes, fresh
source verification, and fresh test/gate evidence for the pure offline
task-class calibration owner implementation authorized by
`docs/baselines/CVF_GC018_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md`
and
`docs/work_orders/CVF_AGENT_WORK_ORDER_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md`.

## Target / Source

| Target | Path | Role |
|---|---|---|
| Decision-layer implementation | `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/task.class.calibration.owner.contract.ts` | pure decision-layer implementation (R1 modified) |
| Adversarial test suite | `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/tests/task.class.calibration.owner.contract.test.ts` | adversarial test suite covering every declared negative case plus R1's new findings (R1 modified) |
| Read-only evidence checker | `governance/compat/check_task_class_calibration_owner_evidence.py` | read-only evidence/schema validator plus CLI (R1 modified) |
| Checker test suite | `governance/compat/test_check_task_class_calibration_owner_evidence.py` | checker test suite, hermetic temp files plus a real-TS-output round trip (R1 modified) |
| Normative reference contract | `docs/reference/agent_system_skills/CVF_TASK_CLASS_CALIBRATION_OWNER_CONTRACT.md` | normative reference contract doc (R1 modified) |

## Scope / Methodology

Confirmed HEAD `45e71b8906f146a737bfbc254fe6cb8e27daf047` unchanged,
`git status --short` showing exactly the same seven untracked paths as the
prior return (now modified in place, not re-created), and staging empty.
Read the four flagged code regions in the current files to confirm each
finding before editing (line numbers had shifted slightly from the original
return but the substance matched). Read
`EXTENSIONS/CVF_v1.9_DETERMINISTIC_REPRODUCIBILITY/core/deterministic.hash.ts`
to evaluate `computeDeterministicHash` for Finding 3's SHA-256 need.
Implemented all four fixes in file 1, updated file 3's checker to inspect
the new `preferenceAuthority` bound-evidence fields, rewrote files 2 and 4's
test suites, updated file 5's normative rules, then ran focused TypeScript
tests/typecheck, the Python checker's own test suite, and the full gate
sequence. No provider call, benchmark execution, or configuration mutation
occurred at any step.

## SHA-256 Hash-Helper Decision (Finding 3)

`computeDeterministicHash` (`EXTENSIONS/CVF_v1.9_DETERMINISTIC_REPRODUCIBILITY/core/deterministic.hash.ts`)
was read in full. Its signature is
`computeDeterministicHash(...parts: string[]): string` and it returns
`createHash('sha256').update(payload).digest('hex').slice(0, 32)` -- a
SHA-256 digest **truncated to 32 hex characters**. This module's own
`isCanonicalHash`/`HASH_PATTERN` requires exactly 64 lowercase hex
characters, so `computeDeterministicHash` output would never pass this
module's own canonical-hash check. Rejected for that reason. Instead, this
module now imports `createHash` directly from Node's built-in `node:crypto`
and defines a local `sha256Hex(...parts: string[])` helper
(`createHash("sha256").update(parts.join("|")).digest("hex")`), producing
the full 64-hex-char digest. `node:crypto` is already a direct, established
dependency of several sibling modules in the same package (confirmed by
reading `durable.run.store.ts` and `durable.delegation.ledger.store.ts`,
both of which `import { createHash } from "node:crypto"`), so this
introduces no new external dependency and matches the package's existing
dependency posture. This choice is documented in the module's own header
comment and in the normative contract doc's rule 13.

## Source Verification Table

| Claimed item | Source file | Recomputed SHA-256 | Work-order-cited SHA-256 | Disposition |
|---|---|---|---|---|
| G1 T1 completion review | `docs/reviews/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_COMPLETION_2026-09-17.md` | `4c8a4978ba9da86af8fe45276dbe7f875bc442e296fcd600f8b834e0d95e4644` | `4c8a4978ba9da86af8fe45276dbe7f875bc442e296fcd600f8b834e0d95e4644` | MATCH |
| G1 T1 design manifest | `docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json` | `c8c1f6899e50513141e69113b8ac9faf37669b1fcd785bc2df3b88d8e894505b` | `c8c1f6899e50513141e69113b8ac9faf37669b1fcd785bc2df3b88d8e894505b` | MATCH |
| Paired GC-018 baseline | `docs/baselines/CVF_GC018_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md` | `e1dd9bd830e80327fd728a2f022d72925d1f56dc23e35ca6241dc7fa311ab60b` | `e1dd9bd830e80327fd728a2f022d72925d1f56dc23e35ca6241dc7fa311ab60b` | MATCH |
| Paired work order | `docs/work_orders/CVF_AGENT_WORK_ORDER_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md` | `4563737b85eed9cd4b55b9a675fc2d896b1bfa19ca1b19fc35e07f1a678426e7` | `4563737b85eed9cd4b55b9a675fc2d896b1bfa19ca1b19fc35e07f1a678426e7` | MATCH |

All four recomputed hashes exactly matched the cited values; no drift was
found. G3's contract
(`EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/assf.behavioral.evaluation.contract.ts`)
was re-read in full and is now genuinely imported and invoked by file 1 (via
`gradeBehavioralEvaluation`/`admitFixtureSet`), per the R1 fix for Finding 1;
it was not modified. The benchmark harness and provider-lane readiness
matrix were not touched by R1 (out of scope for the four findings).

## Exact Code Changes Per Finding

**Finding 1** (file 1, `evaluateTaskClassCalibrationRound`): added
`TaskClassCalibrationProducerReceipt` interface and `isValidProducerReceipt`;
added `producerReceipt`/`g3Fixture`/`g3Traces`/`g3PairedFixture` fields to
`TaskClassCalibrationCandidateEnvelope` and their structural validation in
`validateEnvelopeStructure`; added a producer-to-candidate identity
cross-check and a genuine `gradeBehavioralEvaluation` invocation with a
four-way consistency cross-check (`fixtureContentHash`, `traceContentHashes`,
a real recomputed `g3ResultHash`, and `g3Result`/`repeatsObserved`/
`repeatsRequired` agreement) inside the per-candidate decision loop; added a
round-level `admitFixtureSet` invocation over the pooled `g3Fixture` objects,
surfaced as an informational `exclusions` entry.

**Finding 2** (file 1, preference stage): extended
`PreferenceAuthorityDeclaration` with `promotionRecordRef`/`promotedAt`/
`rubricVersionHash`; added `hasAdmissibleBoundEvidence`; the admissibility
check now calls it; `valueByCandidateId` coverage is checked against every
`eligible` candidate (not just those with a score) before computing the
winner, failing closed to `NO_ADMISSIBLE_PREFERENCE_EVIDENCE` on any gap.

**Finding 3** (file 1, provenance/binding construction): added `sha256Hex`;
`provenanceFingerprint` is now its output over the documented pipe-joined
preimage; `regressionBinding` construction now checks
`isNonEmptyString(typedInput.acceptedAt)` and withholds the binding
(`regressionBinding: null`, with a `bindingWithheldReason` disclosed in
`exclusions`) instead of emitting `CURRENT` with `boundAt: ""`.

**Finding 4** (file 1, output shapes): added `schemaVersion` to both
`OperatingPointAssessment` and `RegressionBinding` construction, sourced
from `TASK_CLASS_CALIBRATION_OWNER_SCHEMA_MARKER = "cvf.taskClassCalibrationOwner"`
(exactly matching the Python checker's `SCHEMA_MARKER` constant); added
`preferenceAuthority` to the assessment object.

**File 3** (`check_task_class_calibration_owner_evidence.py`): added a
bound-evidence check inside the `ACCEPTED_PREFERRED` branch of
`check_operating_point_assessment`, mirroring `hasAdmissibleBoundEvidence`:
`GC026_PROMOTED_PERFORMANCE_REFERENCE` requires non-empty
`promotionRecordRef`/`promotedAt`; the rubric kind requires a canonical
`rubricVersionHash` via the existing `_is_canonical_hash` helper.

## Symbols Implemented (R2-Current)

TypeScript (`task.class.calibration.owner.contract.ts`):

- `evaluateTaskClassCalibrationRound(input: unknown): TaskClassCalibrationRoundOutcome`
  -- unchanged signature; internal binding/preference/provenance/admission
  logic rewritten per Findings 1-4 (R1) and R2-1/R2-2/R2-3 (R2).
- `evaluateRegressionBindingInvalidation(binding: unknown, observedFacts: unknown)`
  -- unchanged by R1 or R2.
- `composeComparabilityFingerprintPreimage(inputs: ComparabilityFingerprintInputs): string`
  -- unchanged signature; now genuinely invoked inside
  `evaluateTaskClassCalibrationRound` as of R2-2 (previously exported but
  unused by the module's own evaluation flow).
- `hasAdmissibleBoundEvidence(authority: PreferenceAuthorityDeclaration): boolean`
  -- new in R1 (Finding 2); extended in R2 (R2-3) to require and verify a
  `gc026Attestation`'s structural/hash validity for the GC-026 kind.
- `sha256Hex(...parts: string[]): string` -- new in R1 (Finding 3),
  module-private; reused by R2 for `candidateConfigHash` and
  `gc026Attestation.recordContentHash` recomputation.
- `canonicalSortKeys(value: unknown): unknown` / `canonicalStringify(value: unknown): string`
  -- new in R2 (R2-2/R2-3), module-private: deterministic stable-sorted-keys
  JSON serialization shared by both new hash-recomputation call sites.
- `recomputeCandidateConfigHash(declaredDimensions): string` -- new in R2
  (R2-2), module-private.
- `recomputeGc026RecordContentHash(recordContent): string` -- new in R2
  (R2-3), module-private.
- `isValidProducerReceipt(value: unknown)` -- new in R1 (Finding 1), module-private.
- `isValidGc026AttestationRecordContent(value: unknown)` /
  `isValidGc026Attestation(value: unknown)` -- new in R2 (R2-3), module-private.
- New/extended exported types: `TaskClassCalibrationProducerReceipt` (R1),
  `TASK_CLASS_CALIBRATION_OWNER_SCHEMA_MARKER` (R1 const),
  `TaskClassCalibrationGc026AttestationRecordContent` /
  `TaskClassCalibrationGc026Attestation` (new in R2), extended
  `TaskClassCalibrationCandidateEnvelope` (R1; R2 adds `canonicalVersion`,
  `environmentDescriptorHash`, `acceptanceCriteriaVersion`,
  `gradingRubricVersionHash`, `heldoutPartitionHash` for fingerprint
  recompute), extended `PreferenceAuthorityDeclaration` (R1; R2 adds
  `gc026Attestation`), extended `OperatingPointAssessment` (R1:
  `schemaVersion`, `preferenceAuthority`), extended `RegressionBinding` (R1:
  `schemaVersion`).

Python (`check_task_class_calibration_owner_evidence.py`):

- `check_operating_point_assessment(assessment, *, label=...) -> list[str]`
  -- extended in R1 with GC026/rubric bound-evidence field checks; R2 did
  not further extend this file (R2's three findings are enforced in the
  TypeScript decision layer itself, which is the binding-verification
  owner; the Python checker's role remains read-only evidence-shape
  validation of already-produced `OperatingPointAssessment`/
  `RegressionBinding` documents, not re-deriving the decision).
- `check_regression_binding(binding, *, label=..., claimed_current=False) -> list[str]`
  -- unchanged by R1 or R2.
- `check(assessment_path, binding_path=None, *, claimed_current=False) -> list[str]`
  -- unchanged by R1 or R2.
- `main() -> int` -- unchanged by R1 or R2.

## Test And Gate Command Evidence (Fresh, R1)

| Command | Result |
|---|---|
| `npx vitest run --config vitest.config.ts tests/task.class.calibration.owner.contract.test.ts` (from `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/`) | 76/76 tests PASS (up from 53/53 pre-R1; +23 new tests across the four findings) |
| `npx tsc -p tsconfig.json --noEmit` (from `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/`) | PASS, zero diagnostics |
| `python -m unittest governance.compat.test_check_task_class_calibration_owner_evidence` | 63/63 tests PASS (up from 53/53 pre-R1; +10 new tests: 6 bound-evidence-field tests, 4 real-TS-output round-trip acceptance/rejection tests, minus overlapping originals counted once) |
| `python -m py_compile governance/compat/check_task_class_calibration_owner_evidence.py governance/compat/test_check_task_class_calibration_owner_evidence.py` | PASS |
| `python governance/compat/run_agent_autorun_workflow_gate.py --phase pre-implementation --base 45e71b8906f146a737bfbc254fe6cb8e27daf047 --head HEAD` | COMPLIANT, all gates `[PASS]` including `governed file size compatibility` (see below) |
| `git diff --check` | PASS, no output |
| `python governance/compat/run_worker_return_fast_gate.py` | COMPLIANT: worker-return fast gate passed |

## Test And Gate Command Evidence (Fresh, R2 -- Current, Supersedes R1 Counts Above)

The R1 counts above are historical (as-of-R1). The counts in this section
are the current, independently re-verified state after R2's three fixes and
the subsequent Local-executed file-size repair described below. Where the
two sections disagree, this R2 section is authoritative.

| Command | Result |
|---|---|
| `npx vitest run --config vitest.config.ts task.class.calibration.owner.contract.test.ts` (from `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/`) | 88/88 tests PASS (up from 76/76 post-R1; +12 new tests across the three R2 findings) |
| `npx tsc -p tsconfig.json --noEmit` (from `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/`) | PASS, zero diagnostics |
| `python -m unittest governance.compat.test_check_task_class_calibration_owner_evidence` | 73/73 tests PASS (up from 63/63 post-R1; +10 new tests) |
| `python governance/compat/run_agent_autorun_workflow_gate.py --phase pre-implementation --base 45e71b8906f146a737bfbc254fe6cb8e27daf047 --head HEAD` | `governed file size compatibility` (the only gate this batch's seven paths can affect) reports `[PASS]` -- see `## R2 Governed File Size Fix` below for the intermediate FAIL this PASS supersedes. The overall gate run also currently reports two unrelated `[FAIL]` rows (`Delta execution claim boundary`, `foundation storage layout`), both citing only `docs/reference/external_agent_invocation_control/CVF_AGENT_ORCHESTRATION_PLATFORM_MCP_DISCUSSION_2026-09-17.md` and a one-line pointer edit to `AGENT_HANDOFF_V61_2026-09-16.md` -- an unrelated, concurrent operator/Codex discussion artifact outside this batch's seven owned paths, confirmed by the operator. See `## Unrelated Concurrent Worktree Change (Out Of R2 Scope)` below |
| `git diff --check` | PASS, no output |
| `python governance/compat/run_worker_return_fast_gate.py` | COMPLIANT: worker-return fast gate passed |
| `git rev-parse HEAD` / `git status --short` / `git diff --cached --name-only` | HEAD unchanged at `45e71b8906f146a737bfbc254fe6cb8e27daf047`; exactly the same seven paths, all still untracked; staging empty |

## R2 Governed File Size Fix (Local-Executed, Independently Verified)

The R2 dispatch's own worker pass was interrupted mid-execution by an
account-level rate limit (HTTP 429, monthly spend limit) while it was in the
middle of a size-reduction sub-task it had itself delegated to a further
background agent (which also hit the same limit). At the point of
interruption: HEAD was unchanged, staging was empty, and all three R2
findings' logic fixes were already complete and passing (88/88 TypeScript
tests, 73/73 Python tests, clean typecheck) -- confirmed by Local
independently rerunning the full test suite before touching anything
further. Only the `governed file size compatibility` gate was failing, for
two distinct reasons across two separate corrective sub-passes:

1. **First fail (source and test files both over their hard thresholds):**
   file 1 at 1008 lines (hard threshold 1000 for `general_source`) and file
   2 at 1435 lines (hard threshold 1200 for `test_code`). Local trimmed file
   1's header/doc comments to 999 lines directly (pure comment-collapsing,
   no logic change; reverified 88/88 TypeScript tests and clean typecheck
   immediately after). Local then dispatched a narrowly-scoped, mechanical,
   no-sub-agent-allowed background worker to trim file 2 using only
   comment-collapsing, decorative-blank-line removal, and short
   object-literal/call collapsing -- explicitly forbidden from deleting,
   weakening, or restructuring any test. That worker verified 88/88 passing
   after every batch of edits and returned file 2 at 1178 lines.
2. **Second fail, found only after independently rerunning the gate (not
   assumed passing from the first fix alone):** with file 1 at 999 lines,
   the gate's separate `near_hard_statement_compression` rule
   (`governance/compat/check_governed_file_size.py`) flagged file 1 as
   `FAIL` for containing lines with two or more semicolons once a governed
   file sits within 25 lines of its hard threshold (the exact same class of
   trap the R1 pass had already hit and documented once). The flagged lines
   were themselves ordinary, pre-existing TypeScript (an inline exclusion
   object type, a discriminated-union member, a `for` loop header, a
   template-literal `join("; ")` separator inside a string) -- not new
   statement-packing introduced during this size-fix pass -- but the file's
   proximity to the hard threshold made the rule apply regardless of origin.
   Local fixed this via genuine content reduction only (collapsing three
   remaining multi-line JSDoc blocks to single-line comments, and
   simplifying the bodies of `canonicalSortKeys`, `isValidProducerReceipt`,
   `isValidGc026AttestationRecordContent`, and `isValidGc026Attestation`
   into fewer, still single-statement-per-line, expressions), bringing file
   1 down to 974 lines -- specifically below the near-hard-threshold margin
   (`1000 - 25 = 975`) so the compressed-statement rule no longer applies at
   all, rather than trying to stay just under the raw 1000-line ceiling
   again. The gate was rerun to a genuine `COMPLIANT` (not assumed) after
   this fix, alongside a full rerun of the TypeScript suite (88/88), the
   Python suite (73/73), typecheck, and the worker-return fast gate.

No test was deleted, weakened, or restructured in either sub-pass; both were
verified by rerunning the exact same 88 TypeScript tests to completion
immediately after each batch of edits, not assumed from the edit intent
alone.

### Governed File Size: A Real Mid-Pass Defect Found And Fixed

The first R1 pass over file 1 and file 2 grew both files past their
class-specific near-hard-threshold statement-compression rule
(`governance/compat/check_governed_file_size.py`): packing multiple
statements/declarations onto single lines to stay under the raw line-count
hard threshold is itself a detected violation
(`near_hard_statement_compression`) once a file is within 25 lines of its
class's hard threshold. This was caught by rerunning the pre-implementation
gate mid-pass, not assumed compliant from a raw `wc -l` count alone. The fix
was genuine content reduction (trimmed comment verbosity, removed one unused
test helper function, introduced a shared `receiptFor(...)` test builder to
deduplicate ~12 repeated 5-line `producerReceipt` object literals down to
one line each) rather than statement-packing, verified by rerunning the gate
until `governed file size compatibility` reported `[PASS]` with zero
compressed-line flags. Final sizes: file 1 967 lines (general_source hard
threshold 1000, comfortably below the 975-line near-hard margin); file 2
1184 lines (test_code hard threshold 1200, below the 1175-line near-hard
margin). The corrected TS module's real JSON output (captured via `npx tsx`
before and after this size-fix pass) was byte-identical in both captures,
confirming the size-driven edits were purely structural/stylistic with zero
semantic drift.

## Unrelated Concurrent Worktree Change (Out Of R2 Scope)

While independently re-verifying gate state after the R2 governed-file-size
fix above, the full `run_agent_autorun_workflow_gate.py --phase
pre-implementation` run surfaced two additional `[FAIL]` rows --
`Delta execution claim boundary` and `foundation storage layout` -- and a
subsequent full rerun of `run_worker_return_fast_gate.py` surfaced a third,
`agent packet authority and encoding` (non-ASCII text without a Text
Encoding Exception at one line). All three cite only a single unrelated
artifact:
`docs/reference/external_agent_invocation_control/CVF_AGENT_ORCHESTRATION_PLATFORM_MCP_DISCUSSION_2026-09-17.md`
(new, untracked), plus one-line pointer additions to
`AGENT_HANDOFF_V61_2026-09-16.md` and
`docs/reference/external_agent_invocation_control/README.md` (both
modified) -- none of which appear in any violation message. `git status
--short` confirms this batch's seven paths remain isolated and untouched by
these three files. The operator confirmed this is a separate, concurrent
operator/Codex discussion artifact about platform/host/MCP and
worker/model-assignment options, unrelated to G1 T2, and directed this
worker/session to leave it untouched and report on its own seven-path scope
only. This audit records the observation for Local's awareness but does not
attempt to fix, revert, or otherwise act on those three files, since they
are outside this batch's Write Ownership.

Both `run_agent_autorun_workflow_gate.py --phase pre-implementation` and
`run_worker_return_fast_gate.py` scan the entire working tree, not only a
batch's declared paths, so any unrelated worktree material blocks their
overall `COMPLIANT`/`PASS` verdict regardless of this batch's own
correctness. Within that full scan, every gate row that names one of this
batch's seven paths passes cleanly: `governed file size compatibility`
`[PASS]` (file 1 at 974 lines, file 2 at 1178 lines, zero compressed-line
flags), and no encoding/claim-boundary/storage-layout violation names any
of the seven G1 T2 paths anywhere in either gate's output. The three
failing rows are wholly attributable to the unrelated Codex-discussion
artifact and would clear on their own once that separate, concurrent work
resolves its own encoding/claim-boundary/storage-layout requirements -- no
action by this batch is needed or appropriate.

## Findings / Position

Each of the four findings was independently reproducible against the
pre-R1 code before any edit was made (confirmed by re-reading the exact
flagged regions), and each fix closes the gap without altering any of the
accepted G1 design's decision states, precedence order, partition rule, or
G3/benchmark/readiness-matrix reuse boundary. G3 is now genuinely invoked
(not merely referenced), closing the "G3 output alone cannot attest
candidate/configuration identity" gap the manifest explicitly named. The
preference-authority bound-evidence requirement and complete-coverage rule
close a real "no-score laundering by omission" gap that the manifest's own
`noScoreLaunderingInvariant` implied but the original code did not enforce
for missing (as opposed to explicitly failing) scores. The real SHA-256
`provenanceFingerprint` and the withhold-on-missing-`acceptedAt` rule
directly implement the manifest's literal formula and its
"never rollback/mutate configuration" fail-closed philosophy. The
schema-marker fix closes a checker-blindness gap that had nothing to do with
the decision logic's correctness but made the Python checker's coverage of
that logic entirely illusory for any real TS-produced document.

## Deviations From The Accepted Design (Disclosed, R1-Current)

1. **Binding withheld, never rollback-forced to STALE, on missing
   `acceptedAt`.** The manifest's invalidation section describes `STALE` as
   the outcome of a later-observed invalidation trigger on an
   already-existing binding, not as the disposition for a binding that was
   never producible in the first place. R1 chose to withhold the binding
   entirely (`regressionBinding: null`) rather than force-emit a `STALE`
   binding with a fabricated timestamp, since fabricating any `boundAt`
   value would itself violate the "no hidden system-clock read" purity
   property this module maintains throughout. This choice is documented in
   the module's own comment and in the normative contract doc's rule 15.
2. **`g3ResultHash` recomputation formula is this module's own choice, not
   drawn from the manifest.** The manifest requires `g3ResultHash` to be a
   "hash" but does not specify its preimage. R1 defines it as
   `sha256Hex(result, fixtureId, sourceContentHash, repeatsObserved,
   repeatsRequired)` over the actual `BehavioralEvaluation` G3 returns,
   documented in the module's own comment; a caller supplying a
   differently-derived (but still 64-hex-char) hash will now correctly fail
   closed to `insufficient_evidence`, which is the intended effect.
3. **`rubricEvaluatorAdapter`, `benchmarkReport`, `metricUnit`, and the
   producer-receipt/G3-fixture/trace fields remain optional-or-required
   envelope fields beyond the manifest's literal
   `candidateEvidenceBinding.requiredFields` list**, as disclosed in the
   original (pre-R1) audit; R1 additionally makes `producerReceipt`,
   `g3Fixture`, and `g3Traces` structurally mandatory (not merely present as
   unused fields), since Finding 1 requires them to actually verify binding.

No other deviation from the accepted design's decision states, precedence
order, partition/contamination rule, repeat semantics, or invalidation-
trigger set was made.

## Risk / Corrective Action

| Risk | Mitigation | Residual |
|---|---|---|
| A caller could construct a `g3ResultHash` using a different (but still well-formed) hash formula than this module's chosen preimage, causing a false `insufficient_evidence` for otherwise-valid evidence | Documented explicitly in the module's own comment, in this audit, and in the normative contract doc's rule 4/13; the formula is deterministic and callers can recompute it themselves before submission | Accepted: fail-closed on formula mismatch is the intended and safer default; a future caller-side helper export could reduce friction if this becomes a common integration pain point |
| The governed-file-size near-hard-threshold statement-compression rule was tripped twice: once mid-R1-pass (documented above), and once again during R2 (both the R2 dispatch's own edits and a background line-trim pass pushed file 1/file 2 into the near-hard zone) | R1: reverted packing, applied genuine content reduction. R2: Local independently diagnosed the second trip (found only by rerunning the gate, not assumed from a raw `wc -l` count), fixed it via genuine content reduction (JSDoc collapsing plus simplifying four helper-function bodies), and brought file 1 to 974 lines -- below the near-hard margin entirely rather than sitting just under the raw hard threshold again. Full details in `## R2 Governed File Size Fix` above | Accepted: no residual risk; both gate trips are green and independently reverified, not assumed |
| The R2 dispatch's worker pass was interrupted mid-execution by an account-level rate limit before it could finish its own size-reduction sub-task (which it had itself delegated to a further background agent, also interrupted by the same limit) | Local independently verified the interrupted worktree was safe (HEAD unchanged, staging empty, all three R2 logic fixes already complete and passing) before taking over the remaining mechanical size-reduction work directly, using a narrowly-scoped no-sub-agent-delegation background worker for the bulk of file 2's trim and doing file 1's trim and the compressed-statement fix directly | Accepted: no residual risk; every claim in this audit's R2 sections was independently re-verified by Local via direct command execution, not inherited from the interrupted worker's unfinished state |
| `comparabilityFingerprint` was, as of R1, still supplied (not computed) by this module -- previously accepted as "out of R1's bounded scope" | R2 Finding 2 closes this gap: `comparabilityFingerprint` (and `candidateConfigHash`) are now independently recomputed from their declared constituent fields and cross-checked against the caller's declared value, failing closed to `insufficient_evidence` on mismatch | Resolved by R2; no longer a residual risk |
| R2-3's GC-026 attestation only proves internal consistency of what the caller attests (e.g. that `recordContentHash` really is the hash of `recordContent`, and that `recordContent` names the correct candidate); it cannot prove the attestation reflects a real GC-026 promotion event outside this module's pure/offline boundary | This is an intentional, Local-directed design boundary (this module must never perform I/O or contact a real registry), documented in the module's own comments, the normative contract doc, and this audit -- exactly analogous to how G3's fixture/trace evidence is also never independently verified against a real live execution by this module | Accepted: verifying real-world truth of an attestation is a caller/operator responsibility outside this pure module's boundary, by explicit design, not an oversight |
| R2-3's stricter bound-evidence requirement was applied only to the `GC026_PROMOTED_PERFORMANCE_REFERENCE` preference-authority kind; the `PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC` kind still only requires a canonical-hash-shaped `rubricVersionHash`, with no analogous internally-verifiable attestation content | Disclosed here explicitly rather than left unconsidered; Local's R2 review named this finding specifically about GC-026, and R2 did not expand scope to the rubric kind | Accepted as an open asymmetry; a future tranche may extend the same attestation pattern to the rubric kind if this becomes load-bearing |

## Decision / Disposition

`WORKER_COMPLETE_PENDING_REVIEW`. Every finding in the R1 dispatch, and
every finding in the R2 dispatch, was independently re-verified against the
pre-edit code, fixed with the exact code changes described above, and
covered by new negative/positive tests. Current fresh command evidence
(R2, superseding the R1 counts above): 88/88 TypeScript tests, clean
typecheck, 73/73 Python tests, clean `git diff --check`. The
`governed file size compatibility` gate row -- the only gate row that can
be affected by this batch's seven paths -- is a clean, independently
reverified `[PASS]` (after failing twice across R1 and R2 for two different
reasons, both genuinely fixed, not assumed). As of this audit's finalization,
the *overall* `run_agent_autorun_workflow_gate.py --phase pre-implementation`
and `run_worker_return_fast_gate.py` runs report `VIOLATION` only because
of an unrelated, concurrent, operator-confirmed Codex-discussion artifact
outside this batch's Write Ownership (`##
Unrelated Concurrent Worktree Change (Out Of R2 Scope)` above); no failing
row in either gate names any of this batch's seven paths. HEAD remains
unchanged at `45e71b8906f146a737bfbc254fe6cb8e27daf047` and staging remains
empty throughout. Local review and closure remain a separate step; this
audit makes no self-approval and no runtime, provider, live, configuration-
mutation, G4, public-sync, or deployment claim, and does not claim the
overall repository-wide gate state is clean while the unrelated artifact
remains unresolved.

## Agent Operation Trace Block

| Field | Evidence |
|---|---|
| Actor | `INTERNAL_AGENT` offline implementation worker (R1 consolidated repair pass) |
| Provider or surface | private CVF workspace only |
| Session or invocation | ACEL G1 T2 R1 consolidated repair pass, 2026-09-17 |
| Working directory | repository root (`D:\UNG DUNG AI\TOOL AI 2026\Controlled-Vibe-Framework-CVF`) |
| Command or tool surface | governed reads, `npx tsx` (real-output capture), `vitest`, `tsc`, `python -m unittest`, `python -m py_compile`, `run_agent_autorun_workflow_gate.py`, `run_worker_return_fast_gate.py`, Git status/diff reads |
| Target paths | exactly the same seven paths as the original G1-T2 return, modified in place |
| Allowed scope source | R1 consolidated repair dispatch; Worker Autonomy / No-Question Rule |
| Before status evidence | HEAD `45e71b8906f146a737bfbc254fe6cb8e27daf047`; `git status --short` showing exactly the same seven untracked paths as the prior return; `git diff --cached --name-only` empty |
| After status evidence | same seven paths, now modified; HEAD unchanged; staging empty |
| Diff evidence | `git status --short`; `git diff --check`; pre-implementation gate rerun at the same execution base |
| Approval boundary | R1 consolidated repair of the pure offline G1 implementation only; no commit |
| Claim boundary | no provider/live, real calibration, configuration mutation, G4, runtime, public-sync, or deployment effect |
| Agent type | `INTERNAL_AGENT` worker |
| Invocation ID | `acel-g1-t2-task-class-calibration-owner-implementation-r1-20260917` |
| Expected manifest | the exact seven paths, modified not re-created |
| Actual changed set | the same seven paths |
| Manifest delta | MATCH |
| Deletion or rename disposition | N/A with reason: none |

## Delta Execution Claim Boundary Control Block

| Field | Disposition |
|---|---|
| claimScope | G1 T2 R1 consolidated repair pass audit only |
| claimDisposition | BOUNDED_CLAIM_WITH_EVIDENCE: fresh worker tests and gates evidenced in this audit |
| receiptEvidence | CLAIM_REJECTED_NO_RECEIPT: no real calibration/provider receipt exists for this tranche |
| actionEvidence | ACTION_EVIDENCE_PRESENT: recomputed source hashes, fresh focused test/typecheck/gate command output above, byte-identical real-output verification before/after the size-fix pass |
| invocationBoundary | local synthetic inputs and read-only evidence files only |
| interceptionBoundary | no IDE, shell, git, filesystem, provider, CLI, MCP, or runtime interception claim |
| claimLanguage | four findings fixed and re-verified pending Local review, never empirically calibrated |
| forbiddenExpansion | G4, real calibration, provider/live, configuration mutation, runtime, public-sync, deployment, and automatic successor remain out of scope |

## Finding-To-Governance Learning Disposition

| Finding | Defect class | Learning lane | Disposition | Next control action | Handled this batch or deferred |
|---|---|---|---|---|---|
| Finding 1: binding not actually verified despite passing gates | RULE_GAP | GOVERNANCE_CONTROL_PLANE | RULE_EXISTS | none; the paired normative contract doc's rule 4 already specified binding verification, the original implementation simply did not satisfy it -- no new rule/checker needed, only implementation conformance | handled this batch (file 1 fix, file 2 tests) |
| Finding 2: preference-authority admission too permissive / silent score-subset narrowing | RULE_GAP | GOVERNANCE_CONTROL_PLANE | RULE_EXISTS | none; rule 12 of the normative contract doc already specified an admissible-basis and no-score-laundering requirement -- no new rule/checker needed, only implementation conformance | handled this batch (file 1 fix, file 2 and file 3/4 tests) |
| Finding 3: provenanceFingerprint not a real hash; CURRENT-with-empty-boundAt possible | RULE_GAP | GOVERNANCE_CONTROL_PLANE | RULE_EXISTS | none; rule 13/15 of the normative contract doc already specified the SHA-256 formula and the fail-closed invalidation philosophy -- no new rule/checker needed, only implementation conformance | handled this batch (file 1 fix, file 2 tests) |
| Finding 4: TS output undetectable by Python checker due to missing schema marker | MACHINE_GATE_GAP | GOVERNANCE_CONTROL_PLANE | MACHINE_CHECK_ADDED | file 3's checker now inspects `preferenceAuthority` bound-evidence fields in addition to the pre-existing schema-marker check; this is a machine-check strengthening within the same already-governed checker, not a new standalone checker | handled this batch (file 1, file 3, file 4 changes) |
| Process finding: an original worker return can pass every structural gate while its underlying decision logic is still substantively wrong, because tests were written to match the implementation rather than the normative design | ORCHESTRATOR_PACKET_GAP | GOVERNANCE_CONTROL_PLANE | N/A_WITH_REASON | this is a review-practice observation about how Local conducts independent logic review versus gate-only review; it is session-local practice guidance, not a proposed new CVF rule, template, or machine check, and promoting it into a formal control is out of scope for this bounded R1 repair tranche | handled this batch (observed and disclosed here; no promotion made) |
| R2-1: round-level G3 fixture-set admission was informational only, never gated eligibility, and a happy-path test asserted `preferred` from a POSITIVE-only pooled fixture set | RULE_GAP | GOVERNANCE_CONTROL_PLANE | RULE_EXISTS | none; the accepted G1 manifest's `candidateIdentity`/`g3Boundary` sections already required a G3-admitted positive+negative fixture set -- no new rule/checker needed, only implementation conformance | handled this batch (file 1 fix, file 2 tests reworked) |
| R2-2: candidate `taskClassId` never cross-checked against the round; `candidateConfigHash`/`comparabilityFingerprint` never independently recomputed from constituent fields, despite an already-exported but unused `composeComparabilityFingerprintPreimage` helper | RULE_GAP | GOVERNANCE_CONTROL_PLANE | RULE_EXISTS | none; the work order's binding-verification requirement and the manifest's `candidateEvidenceBinding.verification` already covered this -- R1's audit had mislabeled it "out of R1's bounded scope"; R2 corrects that scoping and implements the fix | handled this batch (file 1 fix, file 2 tests reworked) |
| R2-3: GC-026 promotion authority was caller-asserted only, with no internally-verifiable attestation structure | RULE_GAP | GOVERNANCE_CONTROL_PLANE | RULE_EXISTS | none beyond this batch's own fix; the fix follows Local's explicit direction on how a pure/offline module may meaningfully raise the bar on a caller-supplied authority claim without violating its no-I/O boundary | handled this batch (file 1 fix, file 2 tests); rubric-kind analogue left as a disclosed, not-yet-actioned asymmetry (see Risk / Corrective Action) |
| Process finding: a governed-file-size near-hard-threshold gate trap (`near_hard_statement_compression`) recurred in R2 for a second, different reason than R1's trip, and the R2 dispatch's own worker pass was interrupted by an account-level rate limit before completing its own size-reduction sub-task | WORKER_EXECUTION_ERROR | GOVERNANCE_CONTROL_PLANE | RULE_EXISTS | none; the existing `check_governed_file_size.py` rule worked exactly as designed both times; Local completed the interrupted work directly after independently verifying the worktree was safe, rather than treating the interruption as requiring any rule or process change | handled this batch (observed and disclosed in `## R2 Governed File Size Fix`; no promotion made) |

Runtime/provider/cost learning lane: N/A -- none of the five findings above
originate from runtime behavior, provider output, or cost evidence; all are
pure offline decision-logic and governance-rule-conformance findings,
confirmed by the `## Claim Boundary` sections throughout this batch's
artifacts asserting no runtime/provider/live execution occurred.

## Rescan Intelligence Hardening

- Original source artifact: N/A with reason: not applicable
- Predecessor intake artifact: N/A with reason: not applicable
- Delta ledger status: N/A with reason: not applicable
- Routing matrix status: N/A with reason: not applicable
- Semantic sampling status: N/A with reason: not applicable
- Rescan intelligence verdict: NOT_APPLICABLE_WITH_REASON

Reason: this audit records an R1 consolidated repair pass over exactly
seven already-declared governed paths in response to Local's own
independent code review findings; it is not a corpus rescan or
intake-refresh of a prior external or internal corpus.

## Public Export Disposition

DEFERRED_PRIVATE_ONLY

Reason: this audit references private CVF provenance architecture and
repository source surfaces; public-safe export requires a separate
redaction and public-sync authorization.

## Claim Boundary

This audit records R1 consolidated repair evidence for a pure offline
decision layer and its read-only checker. It does not prove a measured
operating point, does not authorize provider execution, does not open G4,
and grants no runtime, public-export, or production-readiness authority.
Local review and closure remain a separate, later step owned exclusively by
the Local reviewer/closer.
