# CVF Task-Class Calibration Owner Contract

Memory class: FULL_RECORD

Status: CANDIDATE

Date: 2026-09-17

docType: reference_contract

Batch ID: ACEL-G1-T2-TASK-CLASS-CALIBRATION-OWNER-IMPLEMENTATION

EPISTEMIC_PROCESS_NA_WITH_REASON: fixed-schema contract document; it defines
a normative decision model and vocabulary rather than testing an
evidence-comparison hypothesis.

R1 consolidated repair pass (2026-09-17): this document is updated in place
to describe four corrections found by Local's independent review of the
original G1-T2 return's actual logic (not just its passing gates). See
`docs/audits/CVF_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md`
for the full negative-case-to-fix matrix. Summary: (1) candidate evidence
binding is now actually verified, not just shape-checked; (2) preference
authority admission now requires bound-evidence identity fields and full
`valueByCandidateId` coverage over every eligible candidate; (3)
`provenanceFingerprint` is now a real SHA-256 digest and a `RegressionBinding`
is never emitted `CURRENT` with an empty `boundAt`; (4) the TypeScript module
now declares `schemaVersion` so the Python checker actually evaluates real
output, and `preferenceAuthority` is included in the assessment shape.

R2 consolidated repair pass (2026-09-17): this document is updated in place
again for three further corrections found by Local's independent semantic
review of R1's actual code. See the same audit (updated in place for R2) for
the full R2 negative-case-to-fix matrix. Summary: (R2-1) round-level G3
fixture-set admission (`admitFixtureSet` over the round's pooled
`g3Fixture` objects) now genuinely gates every candidate's eligibility --
a non-`ADMITTED` pool fails every candidate closed to
`insufficient_evidence` -- instead of only being an informational
disclosure in `exclusions`; (R2-2) each candidate's declared `taskClassId`
is now cross-checked against the round's declared `taskClassId`, and
`candidateConfigHash`/`comparabilityFingerprint` are now independently
recomputed from their declared constituent fields
(`declaredDimensions`/the comparability-fingerprint formula fields) and
cross-checked, rather than trusted as opaque caller-supplied strings; (R2-3)
a `GC026_PROMOTED_PERFORMANCE_REFERENCE` preference authority now requires a
structured, internally-verifiable `gc026Attestation` object (independently
recomputed `recordContentHash`, and `recordContent` bound to the accepted
candidate's `taskClassId`/`candidateConfigHash`) instead of accepting any
non-empty `promotionRecordRef`/`promotedAt` strings alone.

## Purpose

Define the generic task-class calibration decision-layer contract identified
by the accepted G1 T1 owner-composition design
(`docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json`,
`DESIGN_READY_FOR_SEPARATE_IMPLEMENTATION_WORK_ORDER`). This contract
composes, without replacing, G3 fixture admission/grading, an optional
rubric-evaluator adapter pattern, the proposal-only benchmark harness, and
provider-lane readiness into one pure, offline decision layer that verifies
candidate/evidence binding and assigns an exclusive decision state to every
candidate in one calibration round. It does not perform a real calibration,
does not execute a provider or benchmark run, and does not mutate a live
operating configuration.

## Source Authority

| Authority | Path |
|---|---|
| G1 T1 accepted design completion | `docs/reviews/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_COMPLETION_2026-09-17.md` |
| G1 T1 design manifest | `docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json` |
| G1 T1 human-readable companion | `docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_2026-09-16.md` |
| G1 T2 GC-018 baseline | `docs/baselines/CVF_GC018_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md` |
| G1 T2 work order | `docs/work_orders/CVF_AGENT_WORK_ORDER_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md` |
| G3 behavioral evaluation contract (reused) | `docs/reference/agent_system_skills/CVF_ASSF_BEHAVIORAL_EVALUATION_CONTRACT.md` |
| Provider-lane readiness matrix (reused) | `docs/reference/CVF_PROVIDER_LANE_READINESS_MATRIX.md` |

## Scope / Applies To

Applies to a pure, deterministic, offline decision layer that evaluates one
task-class calibration round over N candidate configuration/evidence
envelopes supplied in memory, and to a read-only Python evidence checker
that validates the resulting `OperatingPointAssessment`/`RegressionBinding`
documents. All inputs are synthetic or supplied data; no provider or
benchmark run occurs.

Does not apply to executing a real provider call, running a real benchmark,
mutating a live operating configuration or package registry, G4
marginal/incremental value measurement, runtime wiring, or any CLI/MCP
adapter. This contract is documentation-only normative reference plus its
paired pure TypeScript implementation and read-only Python evidence checker;
it grants no loader, resolver, or activation authority.

## Composed Owner Surfaces (Reused, Not Redefined)

- `EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/assf.behavioral.evaluation.contract.ts`
  supplies mandatory held-out grading/admission evidence (`gradeBehavioralEvaluation`,
  `admitFixtureSet`), and, since R1, is genuinely imported and invoked by the
  TypeScript decision layer (not merely referenced) to cross-check each
  candidate's declared hashes/result against the real G3 evaluation. This
  contract's owner separately verifies candidate/configuration and
  trace/result binding via a structured `producerReceipt`; G3 output alone
  never attests candidate or live identity.
- `EXTENSIONS/CVF_CONTROL_PLANE_FOUNDATION/src/performance.benchmark.harness.contract.ts`
  may optionally supply exploratory `PROPOSAL_ONLY` evidence. Its
  `evidenceClass` is always the single literal `PROPOSAL_ONLY`; this
  evidence alone can never establish `preferred` or a `RegressionBinding`
  without a separate GC-026 tracker promotion.
- `docs/reference/CVF_PROVIDER_LANE_READINESS_MATRIX.md` supplies the
  provider/model lane status taxonomy, consulted strictly as an
  eligibility precondition, never as ranking or preference evidence.
- An `evaluateHarderCandidate`-shaped rubric-evaluator adapter
  (`EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/harder.value.candidate.contract.ts`)
  may optionally supply secondary eligibility evidence via
  `materialDefectFound`; this is adapter-pattern reuse only, not a modified
  dependency, and never a rubric-only eligibility bypass.

## Evidence Flow

```text
1. candidate envelope : taskClassId, candidateId, candidateConfigHash, and
                         the full evidence-binding field set (fixture/trace/
                         result hashes, producer receipt, partition)
2. binding verification: the decision layer verifies supplied fixture/trace/
                         result hashes and a producer receipt tying each
                         trace to the same candidate/configuration; G3
                         output alone does not attest identity
3. comparability check : candidates under a different comparabilityFingerprint
                         are never merged; forbidden-from-silent-comparison
                         dimensions are checked separately from allowed
                         dimensions
4. partition check     : SEARCH and HELD_OUT membership is predeclared
                         separately from G3 baselineRole; contamination
                         (shared fixture/content/source hash or known tuning
                         exposure) rejects held-out evidence
5. eligibility stage    : complete bound substantive G3 defects, rubric
                         materialDefectFound, budget-ceiling excess, and
                         readiness-status exclusion are all evaluated before
                         any score is considered (no score laundering)
6. preference stage     : only over eligible candidates, and only under an
                         admissible preference authority (a separately
                         GC-026-promoted performance reference, or a
                         predeclared comparable version-bound deterministic
                         rubric); raw PROPOSAL_ONLY evidence alone yields
                         exploratory ranking only
7. decision state        : incomparable | insufficient_evidence | ineligible |
                         eligible_nonpreferred | preferred (exclusive,
                         exhaustive, in this exact precedence order)
8. assessment/binding    : one OperatingPointAssessment records every
                         candidate's state and every exclusion by ID and
                         reason; a RegressionBinding is created only for
                         exactly one admissibly preferred candidate
```

## Normative Rules

1. **Candidate identity, cross-checked and independently recomputed
   (R2-2).** `taskClassId` is a stable dispatcher-declared string bound to
   exactly one G3-admitted fixture set. `candidateId` is a stable string
   unique within one round for one `taskClassId`. `candidateConfigHash` is
   the SHA-256 of canonical versioned `declaredDimensions`. Identity is
   `candidateId` and `candidateConfigHash` together; labels never
   substitute for configuration content. Since R2, this is enforced, not
   merely declared:
   - Every candidate's declared `taskClassId` must exactly equal the
     round's declared `taskClassId`; a mismatch (or a missing/malformed
     `taskClassId`) fails closed to `insufficient_evidence` -- a candidate
     can never silently declare a different task class than the round it
     was submitted into.
   - `candidateConfigHash` is independently recomputed by the decision
     layer as `SHA-256("cvf.taskClassCalibrationOwner.candidateConfigHash.v1"
     | canonicalStringify(declaredDimensions))`, where
     `canonicalStringify` is a stable-sorted-keys JSON serialization (every
     object key at every nesting level sorted lexicographically before
     `JSON.stringify`, array order preserved). A declared
     `candidateConfigHash` that does not equal this recomputed value fails
     closed to `insufficient_evidence`, even when it is a well-formed
     64-hex-char SHA-256 string -- an opaque caller-supplied hash is never
     trusted verbatim.
2. **Duplicate identity blocks the round.** One `candidateId` bound to more
   than one `candidateConfigHash`, or one `candidateConfigHash` claimed by
   more than one `candidateId`, blocks the entire round
   (`BLOCKED_DUPLICATE_CANDIDATE_IDENTITY`); it is never silently
   overwritten or double-counted.
3. **Empty candidate set blocks the round.** A round with zero candidates
   (or malformed top-level round input) is
   `BLOCKED_EMPTY_CANDIDATE_SET`; no `OperatingPointAssessment` is emitted.
4. **Candidate evidence envelope is mandatory, and binding is actually
   verified (R1).** Every candidate must carry `taskClassId`, `candidateId`,
   `candidateConfigHash`, `comparabilityFingerprint`, `fixtureSetContentHash`,
   `fixtureId`, `fixtureContentHash`, `traceIds`, `traceContentHashes`,
   `traceCaptureModes`, `g3ResultHash`, `producerReceiptRef`, a structured
   `producerReceipt` (`{receiptRef, candidateId, candidateConfigHash,
   traceIds}`), and the actual `g3Fixture`/`g3Traces`/optional
   `g3PairedFixture` objects this candidate's evidence is grounded in. The
   decision layer verifies actual supplied bytes and producer-to-candidate
   binding in two concrete steps, not a shape check alone:
   - **Producer-to-candidate binding.** `producerReceipt.candidateId`,
     `.candidateConfigHash`, and `.traceIds` must exactly match the
     candidate/config/trace identity of the envelope presenting the receipt.
     A receipt (or a passing G3 result) bound to a *different* candidate's
     identity fails closed to `insufficient_evidence`, even when the receipt
     and G3 result are themselves real and otherwise valid.
   - **Actual supplied bytes.** The decision layer invokes G3's own
     `gradeBehavioralEvaluation` on the supplied `g3Fixture`/`g3Traces`, then
     cross-checks the returned `BehavioralEvaluation` against the envelope's
     declared `fixtureContentHash` (must equal `g3Fixture.fixtureContentHash`),
     `traceContentHashes` (must structurally match `g3Traces[].sourceContentHash`),
     and `g3ResultHash` (must equal the real recomputed SHA-256 over
     `result|fixtureId|sourceContentHash|repeatsObserved|repeatsRequired`,
     not an arbitrary well-formed-looking hash string). The declared
     `g3Result`/`repeatsObserved`/`repeatsRequired` must also agree with the
     actual G3 evaluation outcome.
   - A round-level `admitFixtureSet` call (G3's positive-plus-negative
     fixture-set admission) is genuinely invoked over the round's pooled
     `g3Fixture` objects. Since R2-1, this is a genuine round-wide
     eligibility gate, not an informational-only disclosure: when the
     pooled result is not `ADMITTED` (`MISSING_POSITIVE_CASE`,
     `MISSING_NEGATIVE_CASE`, or `MALFORMED_FIXTURE_SET`), **every**
     candidate in the round fails closed to `insufficient_evidence` with a
     reason naming the exact admission failure kind and the observed
     positive/negative counts -- no candidate in a round without a
     G3-admitted positive+negative fixture set may reach
     `eligible_nonpreferred` or `preferred`. This check is positioned
     within the `insufficient_evidence` tier, evaluated before the
     per-candidate "missing required held-out G3 admission" check, since it
     is a round-wide precondition every candidate depends on. The result is
     also still surfaced as a disclosure entry in
     `OperatingPointAssessment.exclusions` for transparency.
   - Candidate identity is cross-checked per rule 1 (R2-2): a candidate
     whose declared `taskClassId` does not match the round's, or whose
     `candidateConfigHash`/`comparabilityFingerprint` does not equal its
     independently recomputed value, fails closed to `insufficient_evidence`
     alongside the other binding checks in this rule.
   Missing, ambiguous, or internally inconsistent binding (for example
   mismatched `traceIds`/`traceContentHashes`/`traceCaptureModes` array
   lengths, a misattributed `producerReceipt`, or a hash/result cross-check
   failure) is `insufficient_evidence`; it can never become
   `eligible_nonpreferred` or `preferred`.
5. **Comparability fingerprint, independently recomputed (R2-2).**
   `SHA-256(canonicalVersion | taskClassId | fixtureSetContentHash |
   environmentDescriptorHash | policyId | acceptanceCriteriaVersion |
   gradingRubricVersionHash | heldoutPartitionHash)`. Candidate evidence
   under a different fingerprint is never merged into the same comparison;
   decision state `incomparable` with a named mismatch reason (this is a
   **cross-candidate** check: two different, both internally-consistent
   candidates' fingerprints differ from each other). Since R2, a candidate's
   `comparabilityFingerprint` is additionally, separately verified as
   **internally consistent with its own declared constituent fields**: the
   decision layer recomputes `SHA-256(composeComparabilityFingerprintPreimage(...))`
   from the candidate's own declared `canonicalVersion`, `taskClassId`,
   `fixtureSetContentHash`, `environmentDescriptorHash`, `policyId`,
   `acceptanceCriteriaVersion`, `gradingRubricVersionHash`, and
   `heldoutPartitionHash`, and a mismatch against the candidate's own
   declared `comparabilityFingerprint` fails closed to
   `insufficient_evidence` -- distinct from the cross-candidate
   `incomparable` state above. A single candidate's own fingerprint being
   unverifiable or fabricated is evidentiary insufficiency about that one
   candidate, not a comparability mismatch between two candidates; a future
   reader must not conflate the two checks.
6. **Allowed vs. forbidden-from-silent-comparison dimensions.**
   `effort_reasoning_level_profile`, `prompt_scaffolding_profile`,
   `tool_set_selection`, `context_window_policy`, `budget_ceiling`,
   `topology_when_g2_supplies_reallocation_primitive`, and
   `provider_model_lane_subject_to_readiness_gating` may legitimately vary
   between candidates. `task_case_set_fixture_set`,
   `environment_sandbox_tier`, `policy_risk_ceiling`,
   `acceptance_criteria`, and `grading_rubric_or_fixture_version` must
   never vary silently between compared candidates; any variance in these
   is `incomparable`, never merged.
7. **SEARCH/HELD_OUT partition.** SEARCH and HELD_OUT membership ledgers
   are predeclared separately, before tuning. Only G3-admitted held-out
   evidence may supply acceptance evidence. `baselineRole` (G3's
   WITH/WITHOUT/NONE) is a pairing field, never a partition label.
   Contamination -- a shared fixture ID, canonical input hash, source
   hash, content hash, or known tuning exposure between SEARCH and
   HELD_OUT -- is `insufficient_evidence` with decision-layer defect
   `REUSED_HELDOUT_SEARCH_DATA`; contaminated evidence is never trusted
   even when otherwise passing.
8. **Repeat and missing-data semantics reused directly from G3.**
   `repeatsRequired` is exactly 1 for `DETERMINISTIC` and exactly 3 for
   `STOCHASTIC`, per `gradeBehavioralEvaluation`. A missing trace or
   insufficient repeats is `insufficient_evidence`; a complete bound
   substantive G3 defect is `ineligible`. Neither earns partial credit, and
   partial repeat evidence is never rounded or averaged into a pass.
9. **Exclusive decision-state precedence.** Every candidate receives
   exactly one of five states, checked in this exact order:
   `incomparable` (fingerprint/forbidden-dimension mismatch) before
   `insufficient_evidence` (missing binding, held-out admission, G3
   trace/repeats, or contamination) before `ineligible` (complete bound
   substantive quality/risk/budget/readiness failure) before
   `eligible_nonpreferred` (passed eligibility, not selected) before
   `preferred` (sole best eligible candidate under an admissible
   preference basis).
10. **No score laundering.** A numeric score -- from a rubric-evaluator
    adapter or a benchmark measurement -- can never reverse an eligibility
    failure. `materialDefectFound: true` from any registered rubric
    adapter always makes a candidate `ineligible` regardless of any
    accompanying score.
11. **Readiness is an eligibility gate only.** Provider/model lane
    readiness status (`UNCONFIGURED`/`BLOCKED`/`LIVE`/`CANARY_PASS`/
    `CERTIFIED`/`DEGRADED`/`EXPERIMENTAL`, per the provider-lane readiness
    matrix) is consulted strictly against a predeclared allowed-status set
    to decide eligibility. It is never used for ranking or preference.
12. **Admissible preference authority, with bound-evidence fields, a
    structured GC-026 attestation, and full score coverage (R1, extended
    R2-3).** `preferred` and a `RegressionBinding` require either (a) a
    separately GC-026-promoted performance reference, or (b) a predeclared
    comparable version-bound deterministic rubric -- and, since R1, the
    authority must also carry the bound-evidence field(s) that establish it
    as an actual bound reference to a real, separately-governed event, not
    just a caller-asserted free-text `ref`:
    - `GC026_PROMOTED_PERFORMANCE_REFERENCE` requires non-empty
      `promotionRecordRef` and `promotedAt` fields distinct from `ref`, and,
      since R2-3, a structured `gc026Attestation` object (see below).
    - `PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC` requires a
      canonical SHA-256 `rubricVersionHash` field. (R2 disclosed limitation:
      the rubric kind has no attestation-style internal-consistency
      requirement analogous to R2-3's GC-026 attestation; this asymmetry is
      a deliberately bounded R2 scope decision, not an oversight -- see the
      R2 audit's Risk / Corrective Action table.)

    **GC-026 structured attestation (R2-3).** Because this module is pure
    and offline and must never perform I/O or contact a real registry, a
    bare `promotionRecordRef`/`promotedAt` pair (any non-empty strings) is
    no longer sufficient: `GC026_PROMOTED_PERFORMANCE_REFERENCE` requires a
    `gc026Attestation: { registrySnapshotHash, recordContentHash,
    recordContent: { taskClassId, candidateConfigHash, promotionRecordRef,
    promotedAt } }` object, where:
    - `recordContentHash` must equal the independently recomputed
      `SHA-256("cvf.taskClassCalibrationOwner.gc026RecordContent.v1" |
      canonicalStringify(recordContent))` (the same canonical-serialization
      approach as rule 1's `candidateConfigHash` recomputation, for
      consistency); a fabricated or stale hash fails closed.
    - `recordContent.taskClassId` and `recordContent.candidateConfigHash`
      must name the same task class and candidate configuration as the
      candidate the authority is being used to prefer. This binding check
      depends on which candidate wins preference, so it is enforced at
      **candidate-selection time** in `evaluateTaskClassCalibrationRound`
      (immediately after the sole top-valued winner is determined, before
      `roundOutcome` is set to `ACCEPTED_PREFERRED`) -- not purely at
      authority-admissibility time, mirroring the R1 Finding 1
      producer-receipt binding check: an attestation for a different
      candidate/task-class can never be reused to promote this one. A
      binding failure at this point falls the round back to
      `NO_ADMISSIBLE_PREFERENCE_EVIDENCE`.
    - This verifies the attestation's **internal consistency** only -- it
      never proves the attestation reflects a real GC-026 promotion outside
      this module's pure boundary, exactly as G3's `gradeBehavioralEvaluation`
      never contacts a real provider but still meaningfully validates
      structural/consistency claims. That the attestation is truthful
      remains a caller/operator responsibility.
    An authority missing its kind-specific bound-evidence field(s) (or, for
    GC-026, a missing/malformed/hash-inconsistent/misbound attestation), or
    carrying a malformed/non-canonical version-bound identifier, is never
    admissible: the round falls back to `NO_ADMISSIBLE_PREFERENCE_EVIDENCE`,
    exactly as if no authority were declared at all. Raw `PROPOSAL_ONLY`
    benchmark values (from `PerformanceBenchmarkHarnessContract.generateReport()`)
    may produce only an exploratory ranking, never `preferred`, never a
    `RegressionBinding`, before a separate GC-026 promotion.
    `valueByCandidateId` must additionally carry a valid numeric entry for
    **every** candidate in the round's `eligible` set, not just some;
    incomplete coverage yields `NO_ADMISSIBLE_PREFERENCE_EVIDENCE` for the
    whole round rather than silently narrowing the comparison to the subset
    that happened to have a score. No admissible basis, a tie among
    top-valued eligible candidates, or no eligible candidate at all yields no
    preferred point, with `NO_ADMISSIBLE_PREFERENCE_EVIDENCE`,
    `TIE_NO_AUTOMATIC_PREFERENCE`, or `NO_ELIGIBLE_CANDIDATE` recorded as
    applicable. An unknown/unnamed metric or unit is excluded from
    preference consideration (`UNKNOWN_METRIC_EXCLUDED`); if no admissible
    basis remains after exclusion, no preferred assignment is made.
13. **OperatingPointAssessment provenance fingerprint is a real SHA-256
    digest (R1).** `provenanceFingerprint = SHA-256(canonicalVersion |
    comparabilityFingerprint | acceptedCandidateId | candidateConfigHash |
    orderedEvidenceEnvelopeHashes[] | preferencePolicyHash |
    promotionEvidenceRefOrRubricHash)`. This field is the actual computed
    SHA-256 digest of that pipe-joined preimage (via Node's built-in
    `node:crypto` `createHash("sha256")`), producing a canonical 64-hex-char
    hash -- never the raw preimage string itself. `acceptedAt` is separate
    metadata from the fingerprint's own preimage.
14. **RegressionBinding creation rule.** A `RegressionBinding` is created
    only for exactly one admissibly preferred candidate; never on a tie,
    no eligible candidate, a missing admissible preference basis, or raw
    `PROPOSAL_ONLY` performance ranking alone.
15. **Invalidation, never automatic rollback; never `CURRENT` with an empty
    `boundAt` (R1).** Any of the following marks
    `RegressionBinding.invalidationStatus = STALE` and requires a fresh
    `OperatingPointAssessment` before further reliance: the bound task
    class's `fixtureSetContentHash` changes; the accepted candidate's
    config, bound trace/result, or producer receipt changes; the
    partition, rubric, environment, policy, acceptance-criteria, or
    preference-policy changes; the accepted candidate's provider-lane
    readiness downgrades below the required minimum; the relied-on GC-026
    promotion changes or is withdrawn; or the accepted candidate's budget
    ceiling is lowered below its recorded consumption. Invalidation never
    performs an automatic rollback or configuration mutation; it only
    marks the binding stale and requires fresh evidence. Separately: when a
    `preferred` outcome is reached but `acceptedAt` is missing or empty at
    that moment, the decision layer withholds the `RegressionBinding`
    entirely (`regressionBinding: null`) rather than emitting one with
    `invalidationStatus: CURRENT` and `boundAt: ""`. This choice (withhold
    entirely, rather than force `STALE`) was selected because it keeps the
    invariant simplest to state and verify: a `CURRENT` binding always
    carries a real, non-empty `boundAt`, full stop -- the TypeScript layer
    itself can never hand back the inconsistent combination, and no
    downstream checker is relied on to catch it after the fact. The withheld
    disposition is disclosed in `OperatingPointAssessment.exclusions` rather
    than silently dropped.

16. **Schema marker for checker visibility (R1).** `OperatingPointAssessment`
    and `RegressionBinding` each declare `schemaVersion` containing the
    literal substring `cvf.taskClassCalibrationOwner` (exactly
    `cvf.taskClassCalibrationOwner.assessment.v1` and
    `cvf.taskClassCalibrationOwner.regressionBinding.v1` respectively),
    matching the Python checker's `SCHEMA_MARKER` constant. A document
    lacking this marker is invisible to (silently skipped by) the checker;
    every real document this module produces carries it.
17. **Malformed and unknown input fails closed structurally, never
    throws.** Every field named in `## Candidate Evidence Envelope Schema`
    below is validated explicitly. A missing, empty, wrong-typed,
    unknown-valued, or internally inconsistent value in any of these
    fields fails closed to `insufficient_evidence` (or a more specific
    named state above when it applies) and never throws an uncaught
    exception or silently coerces the value. A field's absence is never
    treated the same as an explicit `false`/`0`/empty value passing a
    truthiness check.
18. **Pure, total, immutable.** Every exported decision function is pure
    and total: given structurally identical inputs it always returns an
    identical, frozen result. No function mutates its input, performs
    network/file/provider I/O, or executes a real calibration or benchmark
    run.

## Candidate Evidence Envelope Schema

| Field | Type | Required | Fail-closed rule |
|---|---|---|---|
| `taskClassId` | non-empty string | always | missing/empty fails closed; mismatch against the round's declared `taskClassId` fails closed to `insufficient_evidence` (R2-2) |
| `candidateId` | non-empty string | always | missing/empty fails closed; duplicate identity blocks the round (rule 2) |
| `candidateConfigHash` | 64-char lowercase hex SHA-256 | always | missing/malformed fails closed; duplicate identity blocks the round (rule 2); mismatch against the recomputed hash of `declaredDimensions` fails closed to `insufficient_evidence` (R2-2) |
| `comparabilityFingerprint` | 64-char lowercase hex SHA-256 | always | missing/malformed fails closed; mismatch against the round's reference fails closed as `incomparable`; mismatch against its own recomputed hash of its declared constituent fields fails closed to `insufficient_evidence` (R2-2, distinct from the `incomparable` cross-candidate check) |
| `canonicalVersion` / `environmentDescriptorHash` / `acceptanceCriteriaVersion` / `gradingRubricVersionHash` / `heldoutPartitionHash` | string / 64-char hex / string / 64-char hex / 64-char hex | always (R2-2) | the remaining `comparabilityFingerprint` formula constituent fields (`taskClassId`/`fixtureSetContentHash` already listed above); missing/malformed fails closed |
| `fixtureSetContentHash` | 64-char lowercase hex SHA-256 | always | missing/malformed fails closed |
| `fixtureId` | non-empty string | always | missing/empty fails closed |
| `fixtureContentHash` | 64-char lowercase hex SHA-256 | always | missing/malformed fails closed |
| `traceIds` | non-empty string array | always | missing/empty fails closed |
| `traceContentHashes` | non-empty array of 64-char lowercase hex SHA-256 | always | missing/malformed/length-mismatched fails closed |
| `traceCaptureModes` | non-empty string array | always | missing/empty/length-mismatched fails closed |
| `g3ResultHash` | 64-char lowercase hex SHA-256 | always | missing/malformed fails closed |
| `producerReceiptRef` | non-empty string | always | missing/empty fails closed as ambiguous binding |
| `producerReceipt` | `{receiptRef, candidateId, candidateConfigHash, traceIds}` | always (R1) | missing/malformed fails closed; identity fields not matching the presenting candidate fails closed to `insufficient_evidence` (producer-to-candidate misattribution) |
| `g3Fixture` / `g3Traces` / `g3PairedFixture` | actual G3 fixture/trace object(s) | `g3Fixture`/`g3Traces` always, `g3PairedFixture` optional (R1) | missing fails closed; `gradeBehavioralEvaluation` is invoked on these and its result is cross-checked against `fixtureContentHash`/`traceContentHashes`/`g3ResultHash`/`g3Result`/`repeatsObserved`/`repeatsRequired` -- any mismatch fails closed to `insufficient_evidence` |
| `partition` | `SEARCH` \| `HELD_OUT` | always | missing/unknown fails closed |
| `g3Result` | one of G3's seven named results | always | missing/unknown fails closed; substantive-defect results fail closed to `ineligible`, missing-evidence results fail closed to `insufficient_evidence` |
| `repeatPolicy` | `DETERMINISTIC` \| `STOCHASTIC` | always | missing/unknown fails closed |
| `repeatsObserved` / `repeatsRequired` | non-negative number | always | missing/wrong-typed fails closed; `repeatsRequired` must equal exactly 1 for `DETERMINISTIC` or exactly 3 for `STOCHASTIC` |
| `heldoutAdmitted` | boolean | always | missing/false with `partition: HELD_OUT` required fails closed to `insufficient_evidence` |
| `declaredDimensions` | object | always | missing fails closed; forbidden-dimension variance fails closed to `incomparable` (rule 6) |
| `policyId` | non-empty string | always | missing/empty fails closed; variance under a matching fingerprint fails closed to `incomparable` |
| `budgetCeiling` / `budgetConsumed` | non-negative number | always | missing/wrong-typed fails closed; consumption exceeding ceiling fails closed to `ineligible` |
| `providerLaneStatus` | readiness status or `null` | optional | unknown value fails closed; a status outside the allowed-status set fails closed to `ineligible` |
| `rubricEvaluatorAdapter` | `{materialDefectFound, score?}` | optional | `materialDefectFound: true` always fails closed to `ineligible`; no score reverses this |
| `benchmarkReport` | `PROPOSAL_ONLY`-shaped object | optional | never sufficient alone for `preferred` or a `RegressionBinding` |
| `contaminationKeys` | string array | always | shared key with a SEARCH-partition candidate fails closed to `insufficient_evidence` with `REUSED_HELDOUT_SEARCH_DATA` |

No field in this schema is validated by truthiness alone: an absent field,
an explicit `false`, and an explicit `0`/empty string are three distinct
conditions, and each is checked by its own explicit rule.

## Decision-State Vocabulary

| State | Meaning |
|---|---|
| `incomparable` | evidence under a different `comparabilityFingerprint`, or a forbidden dimension varies; never compared |
| `insufficient_evidence` | missing or ambiguous candidate/trace binding, held-out admission, G3 trace/repeats, or `REUSED_HELDOUT_SEARCH_DATA` contamination |
| `ineligible` | complete bound evidence establishes substantive quality/risk/budget/readiness failure |
| `eligible_nonpreferred` | passed eligibility; not selected as the round's preferred candidate |
| `preferred` | sole best eligible candidate under a predeclared admissible preference basis; never raw `PROPOSAL_ONLY` performance evidence alone |

## Round-Outcome Vocabulary

| Round outcome | Meaning |
|---|---|
| `ACCEPTED_PREFERRED` | exactly one candidate is `preferred`; a `RegressionBinding` is created |
| `NO_ADMISSIBLE_PREFERENCE_EVIDENCE` | no preference authority is admissible, or no eligible candidate carries a value under it |
| `TIE_NO_AUTOMATIC_PREFERENCE` | two or more eligible candidates share the top admissible preference value |
| `NO_ELIGIBLE_CANDIDATE` | every candidate failed eligibility; no prior accepted operating point is disturbed |

## Dependency Direction

```text
this task-class calibration owner contract (NEW)
        |
        | composes (read-only reuse; never modifies)
        v
G3 behavioral evaluation contract ---- benchmark harness (PROPOSAL_ONLY)
        |                                      |
        | eligibility gate only                | exploratory ranking only
        v                                      v
provider-lane readiness matrix         GC-026 promotion path (EXISTING,
                                        unchanged sole path to baseline truth)
```

The arrow direction is one-way: this new decision layer depends on the four
existing owners (G3, the rubric-evaluator adapter pattern, the benchmark
harness, and the provider-lane readiness matrix); none of the four existing
owners depends on or is modified by this new layer. G4 (marginal/incremental
value measurement) is excluded and deferred; no G4 output, score, ratio,
hook, or interface obligation is created by this contract.

## TypeScript Implementation Pointer

`EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/task.class.calibration.owner.contract.ts`
implements this contract as pure, immutable TypeScript types and functions:
`evaluateTaskClassCalibrationRound` (accepts `unknown`-typed runtime input
and fails closed structurally, per rule 17, rather than trusting a
caller-supplied type annotation), `evaluateRegressionBindingInvalidation`
(rule 15), and `composeComparabilityFingerprintPreimage` (a deterministic
ordered-field preimage helper for rule 5, never a hash implementation
itself). It performs no network call, no credential read, no provider
invocation, no benchmark execution, and no file I/O; it operates only on
already-constructed candidate envelope objects passed to it in memory. Since
R1, it also genuinely imports and invokes
`gradeBehavioralEvaluation`/`admitFixtureSet` from
`assf.behavioral.evaluation.contract.ts` (rule 4) -- not merely referencing
them in a comment -- and computes real SHA-256 digests via Node's built-in
`node:crypto` (rule 13), never `computeDeterministicHash` from
`CVF_v1.9_DETERMINISTIC_REPRODUCIBILITY/core/deterministic.hash` (that helper
truncates to 32 hex characters and would never satisfy this module's own
64-hex-char canonical-hash pattern).

## Python Evidence Checker Pointer

`governance/compat/check_task_class_calibration_owner_evidence.py` is a
read-only checker that validates a supplied `OperatingPointAssessment`
document (and an optional `RegressionBinding` document) against this
contract: it fails when a `preferred` state is claimed without exclusive
admissible evidence (an admissible `preferenceAuthority` carrying its
kind-specific bound-evidence field(s), per rule 12, and a
`provenanceFingerprint`), when more than one candidate is `preferred` in
one assessment, when a `RegressionBinding`'s required fields or its full
`requiredRegradeTriggerSet` are missing or malformed, or when a regression
binding is claimed current (`--claimed-current`) while its
`invalidationStatus` is not `CURRENT`. It does not require every existing
document to adopt this contract's schema marker (`cvf.taskClassCalibrationOwner`,
rule 16) and does not mutate any registry, tracker, generated file,
configuration, or lifecycle document. Since real TS output now declares this
marker (R1), the checker actually evaluates real assessment/binding
documents produced by the TypeScript module instead of silently skipping
them.

Since R2-3, when a document's `preferenceAuthority.kind` is
`GC026_PROMOTED_PERFORMANCE_REFERENCE`, the checker also corroborates the
declared `gc026Attestation`'s internal consistency: it rejects a missing or
malformed attestation object; independently recomputes
`recordContentHash` from `recordContent` via the identical canonical
serialization and hash formula the TypeScript module uses
(`_recompute_gc026_record_content_hash`, mirroring
`recomputeGc026RecordContentHash`) and rejects a mismatch; and rejects a
`recordContent` whose `taskClassId`/`candidateConfigHash` does not match
this same document's declared `taskClassId`/the accepted candidate's
`candidateConfigHash`. This is document-level corroboration only -- the
checker never contacts a real registry and never decides which candidate is
preferred; it only rejects an `ACCEPTED_PREFERRED` document whose own
declared attestation is internally inconsistent, exactly as the TypeScript
module does at evaluation time.

## Negative Cases (Required, All Present In This Contract)

| Negative case | Contract requirement |
|---|---|
| Empty candidate set | Round is `BLOCKED_EMPTY_CANDIDATE_SET`; no `OperatingPointAssessment` is emitted (rule 3). |
| Duplicate candidate identity | One ID with multiple config hashes, or one config hash under multiple IDs, blocks the round; never silently overwritten or double-counted (rule 2). |
| Mixed task-case sets | Candidates with a different `fixtureSetContentHash` are `incomparable`; the round proceeds over the comparable subset, with exclusions disclosed by ID and reason (rule 5). |
| Unequal budgets or policies | Budget-ceiling excess is `ineligible`; a different `policyId` is `incomparable`, never merged (rules 6, 11). |
| Missing held-out evidence or candidate binding | `insufficient_evidence`; a G3 result or candidate label alone does not attest which candidate produced a trace (rule 4). |
| Reused held-out/SEARCH data | `insufficient_evidence` with `REUSED_HELDOUT_SEARCH_DATA`; never trusted even if otherwise passing (rule 7). |
| Stale fingerprints | `incomparable` with the mismatch reason named; stale and current evidence are never silently mixed (rule 5). |
| Incomplete repeats | `insufficient_evidence` using G3's `repeatsObserved`/`repeatsRequired`; never rounded up or averaged into a pass (rule 8). |
| Unknown metrics or units | Excluded and logged `UNKNOWN_METRIC_EXCLUDED`; if no admissible preference basis remains, no preferred assignment (rule 12). |
| Ties | All tied candidates remain `eligible_nonpreferred`; the assessment records `TIE_NO_AUTOMATIC_PREFERENCE` (rule 12). |
| No eligible candidate | Round result `NO_ELIGIBLE_CANDIDATE`; no preferred assignment; no prior accepted operating point is disturbed (rule 9). |
| Proposal-only performance advantage | Exploratory `PROPOSAL_ONLY` ranking only; no preferred or `RegressionBinding` before separate GC-026 promotion (rule 12). |
| Non-admitted round-level fixture set (R2-1) | A POSITIVE-only or NEGATIVE-only pooled `g3Fixture` set fails every candidate in the round closed to `insufficient_evidence`, naming the admission failure kind and observed counts; never merely informational (rule 4). |
| Candidate/round taskClassId mismatch (R2-2) | A candidate declaring a different `taskClassId` than the round's fails closed to `insufficient_evidence` (rule 1). |
| Fabricated candidateConfigHash/comparabilityFingerprint (R2-2) | A well-formed but non-recomputable `candidateConfigHash` or `comparabilityFingerprint` fails closed to `insufficient_evidence`, distinct from the `incomparable` cross-candidate check (rules 1, 5). |
| Missing/malformed/misbound GC-026 attestation (R2-3) | A `GC026_PROMOTED_PERFORMANCE_REFERENCE` authority missing `gc026Attestation`, carrying a `recordContentHash` that does not match the recomputed hash of `recordContent`, or naming a different `taskClassId`/`candidateConfigHash` than the candidate being preferred, is never admissible; the round falls back to `NO_ADMISSIBLE_PREFERENCE_EVIDENCE` (rule 12). |

## Dual Agent Surface Matrix

| Consumer class | Interface or owner surface | Authority and risk boundary | Evidence | Adapter boundary | Disposition |
|---|---|---|---|---|---|
| `INTERNAL_AGENT` | this contract, its paired TypeScript decision layer and Python evidence checker | internal agents may evaluate an already-supplied candidate evidence set and check assessment/binding admission; this contract grants no loader, resolver, provider, runtime, or registry-mutation authority | this contract; the G1 T1 accepted design; the G3 behavioral evaluation contract; the provider-lane readiness matrix | no internal checker, loader, resolver, hook, or generated-index change is authorized by this tranche | `CONTRACT_ONLY` |
| `EXTERNAL_AGENT_CLI_MCP` | future external-agent calibration readout | external agents cannot select, certify, mutate, activate, or execute a configuration through this contract | Dual Agent Surface Accounting Standard | any implemented CLI/MCP adapter requires a later source-verified adapter contract, tests, and public/private boundary review; this tranche implements none | `DEFERRED_WITH_REASON` |

## Delta Execution Claim Boundary Control Block

| Field | Disposition |
|---|---|
| claimScope | ACEL G1 T2 task-class calibration owner normative contract authoring only |
| claimDisposition | BOUNDED_CLAIM_WITH_EVIDENCE -- contract-definition worker-return lane only |
| receiptEvidence | N/A with reason: no runtime execution, provider call, or adapter receipt exists for this tranche |
| actionEvidence | ACTION_EVIDENCE_PRESENT -- G1 T1 accepted design and this contract's own normative rules |
| invocationBoundary | governed local documentation authoring only |
| interceptionBoundary | no IDE, shell, git, filesystem, provider, CLI, MCP, Web runtime, or adapter interception claim |
| claimLanguage | defines a documentation-only task-class calibration owner contract composed under G1, plus pointers to its paired pure implementation and read-only checker |
| forbiddenExpansion | no registry/index mutation, provider/live call, runtime wiring, real calibration, G4 measurement, public-sync, deployment, or automatic successor tranche |

## Claim Boundary

This contract defines the generic task-class calibration decision model
only. It does not implement a runtime, provider, or CLI/MCP adapter; does
not mutate any package, registry, tracker, or generated-index state; does
not execute any provider, agent, benchmark, or live path; and does not
select or certify any real operating point. Reviewer/closer owns completion
review authoring, roadmap status update, session sync, and any material
commit after acceptance.

## Public Export Disposition

DEFERRED_PRIVATE_ONLY

Reason: this contract references private CVF provenance architecture and
repository source surfaces. Public-safe export requires a separate
redaction and public-sync authorization.
