#!/usr/bin/env python3
"""CVF task-class calibration owner evidence checker.

Read-only checker for the ACEL G1 T2 task-class calibration owner contract
(docs/reference/agent_system_skills/CVF_TASK_CLASS_CALIBRATION_OWNER_CONTRACT.md),
implemented per the paired work order
(docs/work_orders/CVF_AGENT_WORK_ORDER_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md)
and the accepted G1 T1 design manifest
(docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json).

Given an explicit OperatingPointAssessment document (and an optional
RegressionBinding document), both supplied as file paths or test-injected
parsed dicts, this checker fails closed when the assessment or binding does
not carry the exact, consistent, non-stale, non-malformed evidence this
contract requires: it rejects malformed/unknown schema, absent or stale
source/fixture/configuration/trace/result hashes, a missing producer
receipt, contaminated holdout evidence, an unsupported preference
authority, a ``preferred`` state without exclusive admissible evidence, and
a stale regression binding claimed current.

This checker does not impose G1 adoption on unrelated existing packages: a
document that does not declare this contract's schema marker is simply
skipped (not evaluated). It never mutates a registry, tracker, generated
file, configuration, or lifecycle document; it only reads and reports.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

SCHEMA_MARKER = "cvf.taskClassCalibrationOwner"

VALID_DECISION_STATES = {
    "incomparable",
    "insufficient_evidence",
    "ineligible",
    "eligible_nonpreferred",
    "preferred",
}

VALID_ROUND_OUTCOMES = {
    "ACCEPTED_PREFERRED",
    "NO_ADMISSIBLE_PREFERENCE_EVIDENCE",
    "TIE_NO_AUTOMATIC_PREFERENCE",
    "NO_ELIGIBLE_CANDIDATE",
}

VALID_PREFERENCE_AUTHORITY_KINDS = {
    "GC026_PROMOTED_PERFORMANCE_REFERENCE",
    "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC",
}

# PROPOSAL_ONLY_EXPLORATORY is a recognized authority kind but is never
# sufficient on its own to admit a `preferred` state or a RegressionBinding;
# it is listed separately so the checker can distinguish "unknown kind"
# (always rejected) from "known but inadmissible kind" (rejected only when
# claimed as the authority behind a preferred/regression outcome).
PROPOSAL_ONLY_AUTHORITY_KIND = "PROPOSAL_ONLY_EXPLORATORY"

VALID_INVALIDATION_STATUSES = {"CURRENT", "STALE"}

REQUIRED_INVALIDATION_TRIGGERS = {
    "fixture_set_content_hash_changes_for_bound_task_class",
    "candidate_config_or_bound_trace_result_or_producer_receipt_changes",
    "partition_rubric_environment_policy_acceptance_or_preference_policy_changes",
    "accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum",
    "gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence",
    "accepted_candidate_budget_ceiling_lowered_below_recorded_consumption",
}

_HASH_PATTERN = re.compile(r"^[0-9a-f]{64}$")


class _Missing:
    """Sentinel distinguishing an absent field from an explicit ``None``."""

    def __repr__(self) -> str:  # pragma: no cover - debug aid only
        return "<MISSING>"


_MISSING = _Missing()


def _get(document: dict[str, Any], field: str) -> Any:
    """Fetch ``field`` from ``document``, returning the ``_MISSING`` sentinel
    when the key is entirely absent. Never uses truthiness: a present but
    falsy value (``False``, ``0``, ``""``) is returned as-is, not treated as
    missing.
    """
    return document.get(field, _MISSING)


def _is_canonical_hash(value: Any) -> bool:
    return isinstance(value, str) and bool(_HASH_PATTERN.match(value))


def _is_nonempty_str(value: Any) -> bool:
    return isinstance(value, str) and len(value.strip()) > 0


def _load_json_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path}: expected JSON object")
    return value


# R2 Finding 3: canonical serialization mirroring the TypeScript module's
# (private) canonicalStringify/recomputeGc026RecordContentHash exactly, so
# this read-only checker can independently recompute the SAME
# gc026Attestation.recordContentHash the TS decision layer computes and
# reject a document whose declared hash does not match -- a document-level
# corroboration of the same binding-verification requirement, not a
# duplicate authority: this checker never decides which candidate is
# preferred, it only rejects an ACCEPTED_PREFERRED document whose own
# declared attestation hash is internally inconsistent.
_GC026_RECORD_CONTENT_HASH_CANONICAL_VERSION = "cvf.taskClassCalibrationOwner.gc026RecordContent.v1"


def _canonical_sort_keys(value: Any) -> Any:
    if isinstance(value, list):
        return [_canonical_sort_keys(item) for item in value]
    if isinstance(value, dict):
        return {key: _canonical_sort_keys(value[key]) for key in sorted(value.keys())}
    return value


def _canonical_stringify(value: Any) -> str:
    return json.dumps(_canonical_sort_keys(value), separators=(",", ":"))


def _recompute_gc026_record_content_hash(record_content: Any) -> str:
    preimage = f"{_GC026_RECORD_CONTENT_HASH_CANONICAL_VERSION}|{_canonical_stringify(record_content)}"
    return hashlib.sha256(preimage.encode("utf-8")).hexdigest()


def _declares_contract(document: dict[str, Any]) -> bool:
    schema_value = document.get("schemaVersion")
    if isinstance(schema_value, str) and SCHEMA_MARKER in schema_value:
        return True
    marker_value = document.get("contractMarker")
    return isinstance(marker_value, str) and SCHEMA_MARKER in marker_value


def check_operating_point_assessment(
    assessment: dict[str, Any],
    *,
    label: str = "<assessment>",
) -> list[str]:
    """Return admission violations for one OperatingPointAssessment document.

    Pure function: never mutates ``assessment``. A document that does not
    declare this contract's schema marker is skipped (empty violation list)
    rather than evaluated, so unrelated existing documents are never forced
    to adopt this contract.
    """
    violations: list[str] = []

    if not isinstance(assessment, dict) or not _declares_contract(assessment):
        return violations

    task_class_id = _get(assessment, "taskClassId")
    if task_class_id is _MISSING or not _is_nonempty_str(task_class_id):
        violations.append(f"{label}: taskClassId is missing or malformed")

    comparability_fingerprint = _get(assessment, "comparabilityFingerprint")
    if comparability_fingerprint is _MISSING or not isinstance(comparability_fingerprint, str):
        violations.append(f"{label}: comparabilityFingerprint is missing or malformed")

    round_outcome = _get(assessment, "roundOutcome")
    if round_outcome is _MISSING or round_outcome not in VALID_ROUND_OUTCOMES:
        violations.append(
            f"{label}: roundOutcome is missing or unknown: {round_outcome!r} "
            f"(expected one of {sorted(VALID_ROUND_OUTCOMES)})"
        )

    accepted_candidate_id = _get(assessment, "acceptedCandidateId")
    decisions = _get(assessment, "candidateDecisions")

    if decisions is _MISSING or not isinstance(decisions, list):
        violations.append(f"{label}: candidateDecisions is missing or not a list")
        decisions = []

    preferred_ids: list[str] = []
    seen_candidate_ids: set[str] = set()
    for index, decision in enumerate(decisions):
        decision_label = f"{label}.candidateDecisions[{index}]"
        if not isinstance(decision, dict):
            violations.append(f"{decision_label}: decision entry must be an object")
            continue

        candidate_id = _get(decision, "candidateId")
        if candidate_id is _MISSING or not _is_nonempty_str(candidate_id):
            violations.append(f"{decision_label}: candidateId is missing or malformed")
        else:
            if candidate_id in seen_candidate_ids:
                violations.append(
                    f"{decision_label}: duplicate candidateId {candidate_id!r} in one "
                    "assessment; a candidate must never be silently double-counted"
                )
            seen_candidate_ids.add(candidate_id)

        candidate_config_hash = _get(decision, "candidateConfigHash")
        if candidate_config_hash is _MISSING or not isinstance(candidate_config_hash, str):
            violations.append(f"{decision_label}: candidateConfigHash is missing or malformed")

        state = _get(decision, "state")
        if state is _MISSING or state not in VALID_DECISION_STATES:
            violations.append(
                f"{decision_label}: state is missing or unknown: {state!r} "
                f"(expected one of {sorted(VALID_DECISION_STATES)})"
            )
        elif state == "preferred":
            if isinstance(candidate_id, str):
                preferred_ids.append(candidate_id)

    # --- exclusivity: at most one preferred candidate ---
    if len(preferred_ids) > 1:
        violations.append(
            f"{label}: more than one candidate carries state=preferred "
            f"({preferred_ids}); preferred must be exclusive to a sole candidate"
        )

    # --- roundOutcome/acceptedCandidateId/preferred-state consistency ---
    if round_outcome == "ACCEPTED_PREFERRED":
        if accepted_candidate_id is _MISSING or not _is_nonempty_str(accepted_candidate_id):
            violations.append(
                f"{label}: roundOutcome=ACCEPTED_PREFERRED requires a non-empty "
                "acceptedCandidateId"
            )
        elif accepted_candidate_id not in preferred_ids:
            violations.append(
                f"{label}: acceptedCandidateId ({accepted_candidate_id!r}) does not match "
                f"any candidateDecisions entry with state=preferred ({preferred_ids})"
            )
        if len(preferred_ids) == 0:
            violations.append(
                f"{label}: roundOutcome=ACCEPTED_PREFERRED but no candidate carries "
                "state=preferred; preferred requires exclusive admissible evidence"
            )
    else:
        if len(preferred_ids) > 0:
            violations.append(
                f"{label}: roundOutcome={round_outcome!r} but a candidate carries "
                f"state=preferred ({preferred_ids}); preferred is only admissible under "
                "ACCEPTED_PREFERRED"
            )
        if accepted_candidate_id is not _MISSING and accepted_candidate_id is not None:
            violations.append(
                f"{label}: roundOutcome={round_outcome!r} must not carry a non-null "
                "acceptedCandidateId"
            )

    # --- preference authority admissibility (required whenever preferred is claimed) ---
    if round_outcome == "ACCEPTED_PREFERRED":
        authority = _get(assessment, "preferenceAuthority")
        if authority is _MISSING or not isinstance(authority, dict):
            violations.append(
                f"{label}: roundOutcome=ACCEPTED_PREFERRED requires an explicit "
                "preferenceAuthority document"
            )
        else:
            kind = authority.get("kind")
            ref = authority.get("ref")
            if kind == PROPOSAL_ONLY_AUTHORITY_KIND:
                violations.append(
                    f"{label}: preferenceAuthority.kind={PROPOSAL_ONLY_AUTHORITY_KIND} is "
                    "exploratory only and can never admit a preferred candidate "
                    "(raw PROPOSAL_ONLY performance evidence is not an admissible basis)"
                )
            elif kind not in VALID_PREFERENCE_AUTHORITY_KINDS:
                violations.append(
                    f"{label}: preferenceAuthority.kind is unsupported: {kind!r} "
                    f"(expected one of {sorted(VALID_PREFERENCE_AUTHORITY_KINDS)})"
                )
            if not _is_nonempty_str(ref):
                violations.append(f"{label}: preferenceAuthority.ref is missing or malformed")

            # R1 Finding 2: an admissible authority must also carry the
            # kind-specific bound-evidence field(s) that establish it is an
            # actual bound reference to a separately-governed event (a real
            # GC-026 promotion, or a real predeclared version-bound rubric),
            # not just a caller-asserted free-text `ref`. This mirrors the
            # TypeScript module's hasAdmissibleBoundEvidence check, so a
            # document lacking these fields is rejected here too, instead of
            # only being caught client-side.
            if kind == "GC026_PROMOTED_PERFORMANCE_REFERENCE":
                promotion_record_ref = authority.get("promotionRecordRef")
                promoted_at = authority.get("promotedAt")
                if not _is_nonempty_str(promotion_record_ref) or not _is_nonempty_str(promoted_at):
                    violations.append(
                        f"{label}: preferenceAuthority.kind=GC026_PROMOTED_PERFORMANCE_REFERENCE "
                        "requires non-empty promotionRecordRef and promotedAt bound-evidence "
                        "fields; ref alone is not a verified bound promotion reference"
                    )

                # R2 Finding 3: GC-026 now requires a structured, internally
                # verifiable gc026Attestation (registrySnapshotHash,
                # recordContentHash independently recomputable, recordContent
                # naming the accepted candidate's taskClassId/
                # candidateConfigHash). This checker corroborates the
                # document's own internal consistency the same way the TS
                # module does at evaluation time; it never contacts a real
                # registry and never decides which candidate is preferred.
                attestation = authority.get("gc026Attestation")
                if not isinstance(attestation, dict):
                    violations.append(
                        f"{label}: preferenceAuthority.kind=GC026_PROMOTED_PERFORMANCE_REFERENCE "
                        "requires a structured gc026Attestation object "
                        "(registrySnapshotHash, recordContentHash, recordContent); missing or "
                        "malformed attestation is never admissible"
                    )
                else:
                    registry_snapshot_hash = attestation.get("registrySnapshotHash")
                    record_content_hash = attestation.get("recordContentHash")
                    record_content = attestation.get("recordContent")
                    if not _is_canonical_hash(registry_snapshot_hash):
                        violations.append(
                            f"{label}: gc026Attestation.registrySnapshotHash is missing or not a "
                            "canonical SHA-256 hash"
                        )
                    if not _is_canonical_hash(record_content_hash):
                        violations.append(
                            f"{label}: gc026Attestation.recordContentHash is missing or not a "
                            "canonical SHA-256 hash"
                        )
                    if not isinstance(record_content, dict):
                        violations.append(
                            f"{label}: gc026Attestation.recordContent is missing or not an object"
                        )
                    else:
                        record_task_class_id = record_content.get("taskClassId")
                        record_candidate_config_hash = record_content.get("candidateConfigHash")
                        record_promotion_record_ref = record_content.get("promotionRecordRef")
                        record_promoted_at = record_content.get("promotedAt")
                        if not _is_nonempty_str(record_task_class_id):
                            violations.append(
                                f"{label}: gc026Attestation.recordContent.taskClassId is missing "
                                "or malformed"
                            )
                        if not _is_canonical_hash(record_candidate_config_hash):
                            violations.append(
                                f"{label}: gc026Attestation.recordContent.candidateConfigHash is "
                                "missing or not a canonical SHA-256 hash"
                            )
                        if not _is_nonempty_str(record_promotion_record_ref):
                            violations.append(
                                f"{label}: gc026Attestation.recordContent.promotionRecordRef is "
                                "missing or malformed"
                            )
                        if not _is_nonempty_str(record_promoted_at):
                            violations.append(
                                f"{label}: gc026Attestation.recordContent.promotedAt is missing or "
                                "malformed"
                            )

                        # Independent recomputation: recordContentHash must equal
                        # the real recomputed hash of recordContent, not an
                        # arbitrary well-formed-looking hash.
                        if _is_canonical_hash(record_content_hash):
                            recomputed = _recompute_gc026_record_content_hash(record_content)
                            if record_content_hash != recomputed:
                                violations.append(
                                    f"{label}: gc026Attestation.recordContentHash does not match "
                                    f"the recomputed hash of recordContent (recomputed={recomputed}); "
                                    "a fabricated or stale attestation hash is never admissible"
                                )

                        # Candidate binding: recordContent must name the same
                        # taskClassId/candidateConfigHash as the accepted
                        # candidate's decision entry in this same document (the
                        # direct analogue of the TS module's candidate-selection
                        # -time attestation binding check).
                        if _is_nonempty_str(record_task_class_id) and record_task_class_id != task_class_id:
                            violations.append(
                                f"{label}: gc026Attestation.recordContent.taskClassId "
                                f"({record_task_class_id!r}) does not match this assessment's "
                                f"taskClassId ({task_class_id!r}); an attestation for a different "
                                "task class can never be reused to promote this candidate"
                            )
                        if _is_canonical_hash(record_candidate_config_hash) and isinstance(
                            accepted_candidate_id, str
                        ):
                            accepted_decision = next(
                                (
                                    d
                                    for d in decisions
                                    if isinstance(d, dict) and d.get("candidateId") == accepted_candidate_id
                                ),
                                None,
                            )
                            accepted_config_hash = (
                                accepted_decision.get("candidateConfigHash")
                                if isinstance(accepted_decision, dict)
                                else None
                            )
                            if (
                                isinstance(accepted_config_hash, str)
                                and record_candidate_config_hash != accepted_config_hash
                            ):
                                violations.append(
                                    f"{label}: gc026Attestation.recordContent.candidateConfigHash "
                                    f"({record_candidate_config_hash!r}) does not match the accepted "
                                    f"candidate's candidateConfigHash ({accepted_config_hash!r}); an "
                                    "attestation for a different candidate can never be reused to "
                                    "promote this one"
                                )
            elif kind == "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC":
                rubric_version_hash = authority.get("rubricVersionHash")
                if not _is_canonical_hash(rubric_version_hash):
                    violations.append(
                        f"{label}: preferenceAuthority.kind="
                        "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC requires a "
                        "canonical SHA-256 rubricVersionHash bound-evidence field; ref alone is "
                        "not a verified version-bound rubric identifier"
                    )

        provenance_fingerprint = _get(assessment, "provenanceFingerprint")
        if provenance_fingerprint is _MISSING or not _is_nonempty_str(provenance_fingerprint):
            violations.append(
                f"{label}: roundOutcome=ACCEPTED_PREFERRED requires a non-empty "
                "provenanceFingerprint"
            )

    return violations


def check_regression_binding(
    binding: dict[str, Any] | None,
    *,
    label: str = "<regressionBinding>",
    claimed_current: bool = False,
) -> list[str]:
    """Return admission violations for one RegressionBinding document.

    Pure function: never mutates ``binding``. When ``binding`` is ``None``
    and ``claimed_current`` is true (a caller is relying on a current
    regression binding that does not exist), that is itself a violation.
    A document that does not declare this contract's schema marker is
    skipped, matching ``check_operating_point_assessment``.
    """
    if binding is None:
        if claimed_current:
            return [f"{label}: a current regression binding was claimed but no binding document was supplied"]
        return []

    if not isinstance(binding, dict) or not _declares_contract(binding):
        return []

    violations: list[str] = []

    for field in (
        "taskClassId",
        "acceptedCandidateId",
        "preferenceAuthorityRef",
        "boundAt",
    ):
        value = _get(binding, field)
        if value is _MISSING or not _is_nonempty_str(value):
            violations.append(f"{label}: {field} is missing or malformed")

    candidate_config_hash = _get(binding, "candidateConfigHash")
    if candidate_config_hash is _MISSING or not isinstance(candidate_config_hash, str):
        violations.append(f"{label}: candidateConfigHash is missing or malformed")

    comparability_fingerprint = _get(binding, "comparabilityFingerprint")
    if comparability_fingerprint is _MISSING or not isinstance(comparability_fingerprint, str):
        violations.append(f"{label}: comparabilityFingerprint is missing or malformed")

    provenance_fingerprint = _get(binding, "provenanceFingerprint")
    if provenance_fingerprint is _MISSING or not _is_nonempty_str(provenance_fingerprint):
        violations.append(f"{label}: provenanceFingerprint is missing or malformed")

    ordered_hashes = _get(binding, "orderedEvidenceEnvelopeHashes")
    if ordered_hashes is _MISSING or not isinstance(ordered_hashes, list) or len(ordered_hashes) == 0:
        violations.append(f"{label}: orderedEvidenceEnvelopeHashes is missing, empty, or not a list")
    else:
        for index, item in enumerate(ordered_hashes):
            if not isinstance(item, str) or not item:
                violations.append(
                    f"{label}: orderedEvidenceEnvelopeHashes[{index}] is missing or malformed"
                )

    invalidation_status = _get(binding, "invalidationStatus")
    if invalidation_status is _MISSING or invalidation_status not in VALID_INVALIDATION_STATUSES:
        violations.append(
            f"{label}: invalidationStatus is missing or unknown: {invalidation_status!r} "
            f"(expected one of {sorted(VALID_INVALIDATION_STATUSES)})"
        )
    elif claimed_current and invalidation_status != "CURRENT":
        violations.append(
            f"{label}: a current regression binding was claimed but invalidationStatus is "
            f"{invalidation_status!r}, not CURRENT; a STALE binding must never be relied on "
            "as current"
        )

    trigger_set = _get(binding, "requiredRegradeTriggerSet")
    if trigger_set is _MISSING or not isinstance(trigger_set, list):
        violations.append(f"{label}: requiredRegradeTriggerSet is missing or not a list")
    else:
        missing_triggers = REQUIRED_INVALIDATION_TRIGGERS - set(trigger_set)
        if missing_triggers:
            violations.append(
                f"{label}: requiredRegradeTriggerSet is missing required trigger(s): "
                f"{sorted(missing_triggers)}"
            )
        unknown_triggers = set(trigger_set) - REQUIRED_INVALIDATION_TRIGGERS
        if unknown_triggers:
            violations.append(
                f"{label}: requiredRegradeTriggerSet contains unrecognized trigger(s): "
                f"{sorted(unknown_triggers)}"
            )

    return violations


def check(
    assessment_path: Path,
    binding_path: Path | None = None,
    *,
    claimed_current: bool = False,
) -> list[str]:
    """Read-only entry point: load explicit assessment/binding paths and check.

    Never writes to either path, and never mutates any registry, tracker,
    generated file, configuration, or lifecycle document.
    """
    try:
        assessment = _load_json_object(assessment_path)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return [f"assessment document load failed: {exc}"]

    violations = check_operating_point_assessment(assessment, label=str(assessment_path))

    binding: dict[str, Any] | None = None
    if binding_path is not None:
        if not binding_path.exists():
            violations.append(f"regression binding document does not exist: {binding_path}")
        else:
            try:
                binding = _load_json_object(binding_path)
            except (OSError, json.JSONDecodeError, ValueError) as exc:
                violations.append(f"regression binding document load failed: {exc}")

    violations.extend(
        check_regression_binding(binding, label=str(binding_path) if binding_path else "<regressionBinding>", claimed_current=claimed_current)
    )

    return violations


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Check read-only admission of task-class calibration owner evidence "
            "(OperatingPointAssessment and optional RegressionBinding)"
        )
    )
    parser.add_argument(
        "--assessment",
        type=Path,
        required=True,
        help="path to the OperatingPointAssessment JSON document",
    )
    parser.add_argument(
        "--binding",
        type=Path,
        default=None,
        help="path to the optional RegressionBinding JSON document",
    )
    parser.add_argument(
        "--claimed-current",
        action="store_true",
        help="fail if the supplied (or missing) regression binding is not CURRENT",
    )
    args = parser.parse_args()

    print("=== CVF Task-Class Calibration Owner Evidence Admission Check ===")
    violations = check(args.assessment, args.binding, claimed_current=args.claimed_current)
    if violations:
        print("ADMISSION VIOLATIONS:")
        for violation in violations:
            print(f"  - {violation}")
        print("\nFAIL - task-class calibration owner evidence admission is not bounded.")
        return 1

    print("PASS - task-class calibration owner evidence admission is bounded and consistent.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
