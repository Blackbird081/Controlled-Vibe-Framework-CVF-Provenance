"""Tests for check_task_class_calibration_owner_evidence.py.

All fixtures are hermetic: every test writes its assessment/binding
documents into a fresh ``tempfile.TemporaryDirectory`` and never touches
repository data. No network, credential, or provider access occurs anywhere
in this file.
"""

import json
import sys
import tempfile
import unittest
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from check_task_class_calibration_owner_evidence import (  # noqa: E402
    _recompute_gc026_record_content_hash,
    check,
    check_operating_point_assessment,
    check_regression_binding,
)

HASH_A = "a" * 64
HASH_B = "b" * 64
HASH_C = "c" * 64


def _gc026_attestation_for(task_class_id: str, candidate_config_hash: str) -> dict:
    """R2 Finding 3: builds a structurally valid, internally-consistent
    gc026Attestation bound to the given taskClassId/candidateConfigHash,
    using the checker's own recomputation helper so the fixture's declared
    recordContentHash is guaranteed formula-identical to what the checker
    (and the TypeScript module) independently recompute.
    """
    record_content = {
        "taskClassId": task_class_id,
        "candidateConfigHash": candidate_config_hash,
        "promotionRecordRef": "promotion-record-1",
        "promotedAt": "2026-09-01T00:00:00Z",
    }
    return {
        "registrySnapshotHash": HASH_A,
        "recordContentHash": _recompute_gc026_record_content_hash(record_content),
        "recordContent": record_content,
    }


def _decision(**overrides) -> dict:
    base = {
        "candidateId": "cand-1",
        "candidateConfigHash": HASH_A,
        "state": "eligible_nonpreferred",
    }
    base.update(overrides)
    return base


def _assessment(**overrides) -> dict:
    base = {
        "schemaVersion": "cvf.taskClassCalibrationOwner.assessment.v1",
        "taskClassId": "task-class-1",
        "comparabilityFingerprint": HASH_B,
        "roundOutcome": "NO_ADMISSIBLE_PREFERENCE_EVIDENCE",
        "acceptedCandidateId": None,
        "candidateDecisions": [_decision()],
    }
    base.update(overrides)
    return base


def _preferred_assessment(**overrides) -> dict:
    base = {
        "schemaVersion": "cvf.taskClassCalibrationOwner.assessment.v1",
        "taskClassId": "task-class-1",
        "comparabilityFingerprint": HASH_B,
        "roundOutcome": "ACCEPTED_PREFERRED",
        "acceptedCandidateId": "cand-1",
        "candidateDecisions": [_decision(state="preferred")],
        "preferenceAuthority": {
            "kind": "GC026_PROMOTED_PERFORMANCE_REFERENCE",
            "ref": "gc026-ref-1",
            "promotionRecordRef": "promotion-record-1",
            "promotedAt": "2026-09-01T00:00:00Z",
            # R2 Finding 3: structured, internally-verifiable attestation
            # bound to this fixture's accepted candidate (cand-1/HASH_A).
            "gc026Attestation": _gc026_attestation_for("task-class-1", HASH_A),
        },
        "provenanceFingerprint": "provenance-hash-1",
    }
    base.update(overrides)
    return base


def _binding(**overrides) -> dict:
    base = {
        "schemaVersion": "cvf.taskClassCalibrationOwner.regressionBinding.v1",
        "taskClassId": "task-class-1",
        "acceptedCandidateId": "cand-1",
        "candidateConfigHash": HASH_A,
        "comparabilityFingerprint": HASH_B,
        "provenanceFingerprint": "provenance-hash-1",
        "orderedEvidenceEnvelopeHashes": [HASH_A, HASH_C],
        "preferenceAuthorityRef": "gc026-ref-1",
        "boundAt": "2026-09-17T00:00:00Z",
        "invalidationStatus": "CURRENT",
        "requiredRegradeTriggerSet": [
            "fixture_set_content_hash_changes_for_bound_task_class",
            "candidate_config_or_bound_trace_result_or_producer_receipt_changes",
            "partition_rubric_environment_policy_acceptance_or_preference_policy_changes",
            "accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum",
            "gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence",
            "accepted_candidate_budget_ceiling_lowered_below_recorded_consumption",
        ],
    }
    base.update(overrides)
    return base


def _write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


class OperatingPointAssessmentTests(unittest.TestCase):
    def test_passing_non_preferred_assessment_admits_with_no_violations(self) -> None:
        violations = check_operating_point_assessment(_assessment())
        self.assertEqual(violations, [])

    def test_passing_preferred_assessment_admits_with_no_violations(self) -> None:
        violations = check_operating_point_assessment(_preferred_assessment())
        self.assertEqual(violations, [])

    def test_document_not_declaring_contract_is_skipped(self) -> None:
        document = {"taskClassId": "task-class-1"}
        violations = check_operating_point_assessment(document)
        self.assertEqual(violations, [])

    def test_missing_task_class_id_fails(self) -> None:
        assessment = _assessment()
        del assessment["taskClassId"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("taskClassId is missing" in v for v in violations))

    def test_missing_comparability_fingerprint_fails(self) -> None:
        assessment = _assessment()
        del assessment["comparabilityFingerprint"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("comparabilityFingerprint is missing" in v for v in violations))

    def test_unknown_round_outcome_fails_closed(self) -> None:
        assessment = _assessment(roundOutcome="MAYBE")
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("roundOutcome is missing or unknown" in v for v in violations))

    def test_missing_candidate_decisions_fails(self) -> None:
        assessment = _assessment()
        del assessment["candidateDecisions"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("candidateDecisions is missing" in v for v in violations))

    def test_non_list_candidate_decisions_fails(self) -> None:
        assessment = _assessment(candidateDecisions="not-a-list")
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("candidateDecisions is missing or not a list" in v for v in violations))

    def test_decision_entry_not_object_fails(self) -> None:
        assessment = _assessment(candidateDecisions=["not-an-object"])
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("decision entry must be an object" in v for v in violations))

    def test_decision_missing_candidate_id_fails(self) -> None:
        decision = _decision()
        del decision["candidateId"]
        assessment = _assessment(candidateDecisions=[decision])
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("candidateId is missing" in v for v in violations))

    def test_decision_missing_candidate_config_hash_fails(self) -> None:
        decision = _decision()
        del decision["candidateConfigHash"]
        assessment = _assessment(candidateDecisions=[decision])
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("candidateConfigHash is missing" in v for v in violations))

    def test_decision_unknown_state_fails_closed(self) -> None:
        decision = _decision(state="SOMETHING_ELSE")
        assessment = _assessment(candidateDecisions=[decision])
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("state is missing or unknown" in v for v in violations))

    def test_duplicate_candidate_id_in_one_assessment_fails(self) -> None:
        assessment = _assessment(
            candidateDecisions=[_decision(candidateId="cand-1"), _decision(candidateId="cand-1")]
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("duplicate candidateId" in v for v in violations))

    def test_more_than_one_preferred_candidate_fails(self) -> None:
        assessment = _assessment(
            roundOutcome="ACCEPTED_PREFERRED",
            acceptedCandidateId="cand-1",
            candidateDecisions=[
                _decision(candidateId="cand-1", state="preferred"),
                _decision(candidateId="cand-2", state="preferred"),
            ],
            preferenceAuthority={"kind": "GC026_PROMOTED_PERFORMANCE_REFERENCE", "ref": "ref-1"},
            provenanceFingerprint="fingerprint-1",
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("more than one candidate carries state=preferred" in v for v in violations))

    def test_accepted_preferred_without_accepted_candidate_id_fails(self) -> None:
        assessment = _preferred_assessment(acceptedCandidateId=None)
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("roundOutcome=ACCEPTED_PREFERRED requires a non-empty acceptedCandidateId" in v for v in violations)
        )

    def test_accepted_candidate_id_not_matching_preferred_decision_fails(self) -> None:
        assessment = _preferred_assessment(acceptedCandidateId="cand-does-not-exist")
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("does not match any candidateDecisions entry" in v for v in violations))

    def test_accepted_preferred_with_no_preferred_decision_fails(self) -> None:
        assessment = _preferred_assessment(candidateDecisions=[_decision(state="eligible_nonpreferred")])
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("no candidate carries state=preferred" in v for v in violations)
        )

    def test_non_accepted_preferred_outcome_with_preferred_decision_fails(self) -> None:
        assessment = _assessment(
            roundOutcome="TIE_NO_AUTOMATIC_PREFERENCE",
            candidateDecisions=[_decision(state="preferred")],
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("preferred is only admissible under ACCEPTED_PREFERRED" in v for v in violations)
        )

    def test_non_accepted_preferred_outcome_with_nonnull_accepted_candidate_id_fails(self) -> None:
        assessment = _assessment(roundOutcome="NO_ELIGIBLE_CANDIDATE", acceptedCandidateId="cand-1")
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("must not carry a non-null acceptedCandidateId" in v for v in violations))

    # --- preference authority admissibility ---
    def test_preferred_without_preference_authority_fails(self) -> None:
        assessment = _preferred_assessment()
        del assessment["preferenceAuthority"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("requires an explicit preferenceAuthority" in v for v in violations))

    def test_preferred_with_proposal_only_authority_fails_closed(self) -> None:
        assessment = _preferred_assessment(
            preferenceAuthority={"kind": "PROPOSAL_ONLY_EXPLORATORY", "ref": "benchmark-1"}
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("exploratory only and can never admit a preferred candidate" in v for v in violations))

    def test_preferred_with_unknown_authority_kind_fails_closed(self) -> None:
        assessment = _preferred_assessment(preferenceAuthority={"kind": "MADE_UP_KIND", "ref": "ref-1"})
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("preferenceAuthority.kind is unsupported" in v for v in violations))

    def test_preferred_with_rubric_authority_kind_passes(self) -> None:
        assessment = _preferred_assessment(
            preferenceAuthority={
                "kind": "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC",
                "ref": "rubric-v1",
                "rubricVersionHash": HASH_A,
            }
        )
        violations = check_operating_point_assessment(assessment)
        self.assertEqual(violations, [])

    def test_preferred_authority_missing_ref_fails(self) -> None:
        assessment = _preferred_assessment(
            preferenceAuthority={
                "kind": "GC026_PROMOTED_PERFORMANCE_REFERENCE",
                "ref": "",
                "promotionRecordRef": "promotion-record-1",
                "promotedAt": "2026-09-01T00:00:00Z",
            }
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("preferenceAuthority.ref is missing or malformed" in v for v in violations))

    # --- R1 Finding 2: preference-authority bound-evidence field checks ---
    def test_preferred_gc026_authority_missing_promotion_record_ref_fails(self) -> None:
        assessment = _preferred_assessment(
            preferenceAuthority={
                "kind": "GC026_PROMOTED_PERFORMANCE_REFERENCE",
                "ref": "gc026-ref-1",
                "promotedAt": "2026-09-01T00:00:00Z",
                # promotionRecordRef deliberately omitted
            }
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("requires non-empty promotionRecordRef and promotedAt" in v for v in violations)
        )

    def test_preferred_gc026_authority_missing_promoted_at_fails(self) -> None:
        assessment = _preferred_assessment(
            preferenceAuthority={
                "kind": "GC026_PROMOTED_PERFORMANCE_REFERENCE",
                "ref": "gc026-ref-1",
                "promotionRecordRef": "promotion-record-1",
                # promotedAt deliberately omitted
            }
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("requires non-empty promotionRecordRef and promotedAt" in v for v in violations)
        )

    def test_preferred_rubric_authority_missing_rubric_version_hash_fails(self) -> None:
        assessment = _preferred_assessment(
            preferenceAuthority={
                "kind": "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC",
                "ref": "rubric-v1",
                # rubricVersionHash deliberately omitted
            }
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("requires a canonical SHA-256 rubricVersionHash" in v for v in violations)
        )

    def test_preferred_rubric_authority_malformed_rubric_version_hash_fails(self) -> None:
        assessment = _preferred_assessment(
            preferenceAuthority={
                "kind": "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC",
                "ref": "rubric-v1",
                "rubricVersionHash": "not-a-canonical-hash",
            }
        )
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("requires a canonical SHA-256 rubricVersionHash" in v for v in violations)
        )

    def test_preferred_without_provenance_fingerprint_fails(self) -> None:
        assessment = _preferred_assessment()
        del assessment["provenanceFingerprint"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("requires a non-empty provenanceFingerprint" in v for v in violations)
        )

    def test_never_mutates_input(self) -> None:
        assessment = _preferred_assessment()
        snapshot = json.loads(json.dumps(assessment))
        check_operating_point_assessment(assessment)
        self.assertEqual(assessment, snapshot)


class RegressionBindingTests(unittest.TestCase):
    def test_passing_current_binding_admits_with_no_violations(self) -> None:
        violations = check_regression_binding(_binding(), claimed_current=True)
        self.assertEqual(violations, [])

    def test_none_binding_without_claim_is_skipped(self) -> None:
        violations = check_regression_binding(None, claimed_current=False)
        self.assertEqual(violations, [])

    def test_none_binding_with_claimed_current_fails(self) -> None:
        violations = check_regression_binding(None, claimed_current=True)
        self.assertTrue(any("no binding document was supplied" in v for v in violations))

    def test_document_not_declaring_contract_is_skipped(self) -> None:
        violations = check_regression_binding({"taskClassId": "x"}, claimed_current=True)
        self.assertEqual(violations, [])

    def test_missing_task_class_id_fails(self) -> None:
        binding = _binding()
        del binding["taskClassId"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("taskClassId is missing" in v for v in violations))

    def test_missing_accepted_candidate_id_fails(self) -> None:
        binding = _binding()
        del binding["acceptedCandidateId"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("acceptedCandidateId is missing" in v for v in violations))

    def test_missing_preference_authority_ref_fails(self) -> None:
        binding = _binding()
        del binding["preferenceAuthorityRef"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("preferenceAuthorityRef is missing" in v for v in violations))

    def test_missing_bound_at_fails(self) -> None:
        binding = _binding()
        del binding["boundAt"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("boundAt is missing" in v for v in violations))

    def test_missing_candidate_config_hash_fails(self) -> None:
        binding = _binding()
        del binding["candidateConfigHash"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("candidateConfigHash is missing" in v for v in violations))

    def test_missing_comparability_fingerprint_fails(self) -> None:
        binding = _binding()
        del binding["comparabilityFingerprint"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("comparabilityFingerprint is missing" in v for v in violations))

    def test_missing_provenance_fingerprint_fails(self) -> None:
        binding = _binding()
        del binding["provenanceFingerprint"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("provenanceFingerprint is missing" in v for v in violations))

    def test_missing_ordered_evidence_hashes_fails(self) -> None:
        binding = _binding()
        del binding["orderedEvidenceEnvelopeHashes"]
        violations = check_regression_binding(binding)
        self.assertTrue(
            any("orderedEvidenceEnvelopeHashes is missing, empty, or not a list" in v for v in violations)
        )

    def test_empty_ordered_evidence_hashes_fails(self) -> None:
        binding = _binding(orderedEvidenceEnvelopeHashes=[])
        violations = check_regression_binding(binding)
        self.assertTrue(
            any("orderedEvidenceEnvelopeHashes is missing, empty, or not a list" in v for v in violations)
        )

    def test_malformed_ordered_evidence_hash_entry_fails(self) -> None:
        binding = _binding(orderedEvidenceEnvelopeHashes=[""])
        violations = check_regression_binding(binding)
        self.assertTrue(any("orderedEvidenceEnvelopeHashes[0] is missing or malformed" in v for v in violations))

    def test_unknown_invalidation_status_fails_closed(self) -> None:
        binding = _binding(invalidationStatus="MAYBE_STALE")
        violations = check_regression_binding(binding)
        self.assertTrue(any("invalidationStatus is missing or unknown" in v for v in violations))

    def test_stale_binding_claimed_current_fails(self) -> None:
        binding = _binding(invalidationStatus="STALE")
        violations = check_regression_binding(binding, claimed_current=True)
        self.assertTrue(
            any("a current regression binding was claimed but invalidationStatus is" in v for v in violations)
        )

    def test_stale_binding_not_claimed_current_passes(self) -> None:
        binding = _binding(invalidationStatus="STALE")
        violations = check_regression_binding(binding, claimed_current=False)
        self.assertEqual(violations, [])

    def test_missing_required_regrade_trigger_fails(self) -> None:
        binding = _binding(
            requiredRegradeTriggerSet=["fixture_set_content_hash_changes_for_bound_task_class"]
        )
        violations = check_regression_binding(binding)
        self.assertTrue(any("missing required trigger(s)" in v for v in violations))

    def test_unknown_regrade_trigger_fails(self) -> None:
        binding = _binding()
        binding["requiredRegradeTriggerSet"] = list(binding["requiredRegradeTriggerSet"]) + ["made_up_trigger"]
        violations = check_regression_binding(binding)
        self.assertTrue(any("unrecognized trigger(s)" in v for v in violations))

    def test_never_mutates_input(self) -> None:
        binding = _binding()
        snapshot = json.loads(json.dumps(binding))
        check_regression_binding(binding, claimed_current=True)
        self.assertEqual(binding, snapshot)


class FileCheckTests(unittest.TestCase):
    def test_check_reads_hermetic_temp_files_and_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            binding_path = root / "binding.json"
            _write_json(assessment_path, _preferred_assessment())
            _write_json(binding_path, _binding())

            violations = check(assessment_path, binding_path, claimed_current=True)

            self.assertEqual(violations, [])

    def test_check_without_binding_path_skips_binding_checks(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            _write_json(assessment_path, _assessment())

            violations = check(assessment_path)

            self.assertEqual(violations, [])

    def test_check_fails_when_binding_path_does_not_exist(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            missing_binding_path = root / "missing-binding.json"
            _write_json(assessment_path, _assessment())

            violations = check(assessment_path, missing_binding_path)

            self.assertTrue(any("does not exist" in v for v in violations))

    def test_check_fails_on_malformed_assessment_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            assessment_path.write_text("{not valid json", encoding="utf-8")

            violations = check(assessment_path)

            self.assertTrue(any("assessment document load failed" in v for v in violations))

    def test_check_fails_on_malformed_binding_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            binding_path = root / "binding.json"
            _write_json(assessment_path, _assessment())
            binding_path.write_text("{not valid json", encoding="utf-8")

            violations = check(assessment_path, binding_path)

            self.assertTrue(any("regression binding document load failed" in v for v in violations))

    def test_check_does_not_mutate_temp_files_on_disk(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            binding_path = root / "binding.json"
            _write_json(assessment_path, _preferred_assessment())
            _write_json(binding_path, _binding())
            assessment_bytes_before = assessment_path.read_bytes()
            binding_bytes_before = binding_path.read_bytes()

            check(assessment_path, binding_path, claimed_current=True)

            self.assertEqual(assessment_path.read_bytes(), assessment_bytes_before)
            self.assertEqual(binding_path.read_bytes(), binding_bytes_before)

    def test_check_reports_stale_binding_claimed_current_end_to_end(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            binding_path = root / "binding.json"
            _write_json(assessment_path, _preferred_assessment())
            _write_json(binding_path, _binding(invalidationStatus="STALE"))

            violations = check(assessment_path, binding_path, claimed_current=True)

            self.assertTrue(any("invalidationStatus is" in v for v in violations))


# --- R2 Finding 1/2/3: genuine round-trip fixtures (R2 recapture) ---
#
# REAL_TS_ASSESSMENT/REAL_TS_REGRESSION_BINDING below are not hand-waved
# shapes: they are the byte-accurate, field-complete JSON actually printed by
# `evaluateTaskClassCalibrationRound` from
# EXTENSIONS/CVF_EXECUTION_PLANE_FOUNDATION/src/mao/task.class.calibration.owner.contract.ts,
# recaptured for this R2 pass via `tsc` (compiling the module to CommonJS
# in a scratch directory) plus a plain `node` invocation against two
# candidate envelopes: cand-1 (taskClassId task-class-1, a real G3
# POSITIVE/DETERMINISTIC fixture+trace pair, candidateConfigHash/
# comparabilityFingerprint genuinely recomputed per R2-2's canonical
# derivation, a GC026_PROMOTED_PERFORMANCE_REFERENCE authority carrying a
# structured, internally-consistent gc026Attestation per R2-3) and
# cand-negative-companion (a NEGATIVE-class G3 fixture contributed purely so
# the round's pooled fixture set is genuinely POSITIVE+NEGATIVE G3-admitted
# per R2-1, itself excluded as insufficient_evidence). Every field name,
# nesting, and value (including the real recomputed SHA-256
# provenanceFingerprint/g3ResultHash/candidateConfigHash/
# comparabilityFingerprint/gc026Attestation.recordContentHash-derived
# hashes) is copied verbatim from that real run's stdout, not approximated.
REAL_TS_ASSESSMENT: dict = {
    "schemaVersion": "cvf.taskClassCalibrationOwner.assessment.v1",
    "taskClassId": "task-class-1",
    "comparabilityFingerprint": "ba962142db33998a50934ac70e6d7c69dbd7304e91b966298df3a652e7c8e3b4",
    "candidateDecisions": [
        {
            "candidateId": "cand-1",
            "candidateConfigHash": "d5679dc498149e5c6b7644dc0bb49a69402963fe8b27543f15425fbbe64f1f6a",
            "state": "preferred",
            "reasons": [],
        },
        {
            "candidateId": "cand-negative-companion",
            "candidateConfigHash": "41e144b03284eabdfdd2c24ebaf476506e0b0f209624a5799e7672d122a1c3b5",
            "state": "insufficient_evidence",
            "reasons": [
                "candidate evidence binding could not be verified against actual "
                "supplied bytes: declared g3ResultHash does not match the "
                "recomputed SHA-256 over the actual G3 evaluation result "
                "(recomputed=7beaf90bcd8f63492c2198b8b3c3e054fa7a6f903777b2436a4cc65b6a53d272)"
            ],
        },
    ],
    "exclusions": [
        {
            "candidateId": "cand-negative-companion",
            "reason": (
                "candidate evidence binding could not be verified against actual "
                "supplied bytes: declared g3ResultHash does not match the "
                "recomputed SHA-256 over the actual G3 evaluation result "
                "(recomputed=7beaf90bcd8f63492c2198b8b3c3e054fa7a6f903777b2436a4cc65b6a53d272)"
            ),
        }
    ],
    "acceptedCandidateId": "cand-1",
    "preferenceAuthority": {
        "kind": "GC026_PROMOTED_PERFORMANCE_REFERENCE",
        "ref": "gc026-ref-1",
        "promotionRecordRef": "promotion-record-1",
        "promotedAt": "2026-09-01T00:00:00Z",
        "gc026Attestation": {
            "registrySnapshotHash": "1" * 64,
            "recordContentHash": "258a4d5fd63b75f5e9095db4ac87761ac0ae0f2e338052438a2b5309bc4c2f0b",
            "recordContent": {
                "taskClassId": "task-class-1",
                "candidateConfigHash": "d5679dc498149e5c6b7644dc0bb49a69402963fe8b27543f15425fbbe64f1f6a",
                "promotionRecordRef": "promotion-record-1",
                "promotedAt": "2026-09-01T00:00:00Z",
            },
        },
        "valueByCandidateId": {"cand-1": 42},
    },
    "provenanceFingerprint": "6ea1d6759dec2b7b7a8b7e68d21a27f45d11c696fa233b8075b6e387a9a466c9",
    "roundOutcome": "ACCEPTED_PREFERRED",
    "acceptedAt": "2026-09-17T00:00:00Z",
    "claimBoundary": (
        "pure offline decision layer over supplied synthetic candidate evidence; "
        "never invokes a provider, never executes a real calibration or benchmark "
        "run, never mutates a live operating configuration, and never certifies G4 "
        "marginal/incremental value"
    ),
}

REAL_TS_REGRESSION_BINDING: dict = {
    "schemaVersion": "cvf.taskClassCalibrationOwner.regressionBinding.v1",
    "taskClassId": "task-class-1",
    "acceptedCandidateId": "cand-1",
    "candidateConfigHash": "d5679dc498149e5c6b7644dc0bb49a69402963fe8b27543f15425fbbe64f1f6a",
    "comparabilityFingerprint": "ba962142db33998a50934ac70e6d7c69dbd7304e91b966298df3a652e7c8e3b4",
    "provenanceFingerprint": "6ea1d6759dec2b7b7a8b7e68d21a27f45d11c696fa233b8075b6e387a9a466c9",
    "orderedEvidenceEnvelopeHashes": [
        "63ae93afd16e95c5ceea112ab53bc9ef7b31a8f761ee4fba7f89505933877c0b",
        "c" * 64,
        "c" * 64,
    ],
    "preferenceAuthorityRef": "gc026-ref-1",
    "boundAt": "2026-09-17T00:00:00Z",
    "invalidationStatus": "CURRENT",
    "requiredRegradeTriggerSet": [
        "fixture_set_content_hash_changes_for_bound_task_class",
        "candidate_config_or_bound_trace_result_or_producer_receipt_changes",
        "partition_rubric_environment_policy_acceptance_or_preference_policy_changes",
        "accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum",
        "gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence",
        "accepted_candidate_budget_ceiling_lowered_below_recorded_consumption",
    ],
}


class RealTypeScriptOutputRoundTripTests(unittest.TestCase):
    """R1 Finding 4: the checker must actually evaluate real TS output.

    Before this R1 pass, the TS module never set schemaVersion/contractMarker,
    so `_declares_contract` caused every real TS-produced document to be
    silently skipped (empty violation list) regardless of validity. These
    tests feed the exact real TS output (captured above) through the checker
    end-to-end and confirm: (a) a genuinely valid ACCEPTED_PREFERRED
    assessment is now actually evaluated and accepted, and (b) an
    ACCEPTED_PREFERRED assessment using this same real schema shape but with
    a missing required field or an inconsistent preferred state is now
    correctly rejected with non-empty violations, not `[]`.
    """

    def test_real_ts_output_is_recognized_and_admitted_with_no_violations(self) -> None:
        violations = check_operating_point_assessment(REAL_TS_ASSESSMENT)
        self.assertEqual(violations, [])

    def test_real_ts_regression_binding_is_recognized_and_admitted_current(self) -> None:
        violations = check_regression_binding(REAL_TS_REGRESSION_BINDING, claimed_current=True)
        self.assertEqual(violations, [])

    def test_real_ts_shape_end_to_end_file_check_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            assessment_path = root / "assessment.json"
            binding_path = root / "binding.json"
            _write_json(assessment_path, REAL_TS_ASSESSMENT)
            _write_json(binding_path, REAL_TS_REGRESSION_BINDING)

            violations = check(assessment_path, binding_path, claimed_current=True)

            self.assertEqual(violations, [])

    def test_malformed_real_shaped_assessment_missing_provenance_fingerprint_is_rejected_not_empty(
        self,
    ) -> None:
        # This is the exact class of case the reviewer found: before the R1
        # fix, a malformed ACCEPTED_PREFERRED assessment using the real TS
        # schema shape returned `[]` (silently skipped) because the document
        # never declared a recognized schema marker. Now that real TS output
        # declares schemaVersion, this same real shape -- with a required
        # field stripped -- must produce non-empty violations.
        malformed = dict(REAL_TS_ASSESSMENT)
        malformed = {k: v for k, v in malformed.items() if k != "provenanceFingerprint"}
        violations = check_operating_point_assessment(malformed)
        self.assertNotEqual(violations, [])
        self.assertTrue(any("provenanceFingerprint" in v for v in violations))

    def test_malformed_real_shaped_assessment_inconsistent_preferred_state_is_rejected_not_empty(
        self,
    ) -> None:
        # Real schema shape, but roundOutcome and the preferred candidate
        # decisions are made inconsistent (acceptedCandidateId points at a
        # candidate that no longer carries state=preferred).
        malformed_decisions = [
            {
                "candidateId": "cand-1",
                "candidateConfigHash": "a" * 64,
                "state": "eligible_nonpreferred",
                "reasons": [],
            }
        ]
        malformed = {**REAL_TS_ASSESSMENT, "candidateDecisions": malformed_decisions}
        violations = check_operating_point_assessment(malformed)
        self.assertNotEqual(violations, [])
        self.assertTrue(any("no candidate carries state=preferred" in v for v in violations))

    def test_malformed_real_shaped_binding_missing_bound_at_is_rejected_not_empty(self) -> None:
        malformed = {k: v for k, v in REAL_TS_REGRESSION_BINDING.items() if k != "boundAt"}
        violations = check_regression_binding(malformed, claimed_current=True)
        self.assertNotEqual(violations, [])
        self.assertTrue(any("boundAt is missing" in v for v in violations))


class Gc026AttestationTests(unittest.TestCase):
    """R2 Finding 3: the checker corroborates a GC-026 authority's
    structured attestation the same way the TypeScript module does at
    evaluation time -- internal consistency only, never a live registry
    lookup. Every test here uses `_preferred_assessment()`'s cand-1/HASH_A
    identity so only the attestation itself varies.
    """

    def test_missing_gc026_attestation_fails(self) -> None:
        assessment = _preferred_assessment()
        del assessment["preferenceAuthority"]["gc026Attestation"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("requires a structured gc026Attestation object" in v for v in violations))

    def test_gc026_attestation_not_an_object_fails(self) -> None:
        assessment = _preferred_assessment()
        assessment["preferenceAuthority"]["gc026Attestation"] = "not-an-object"
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("requires a structured gc026Attestation object" in v for v in violations))

    def test_missing_registry_snapshot_hash_fails(self) -> None:
        assessment = _preferred_assessment()
        del assessment["preferenceAuthority"]["gc026Attestation"]["registrySnapshotHash"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("registrySnapshotHash is missing" in v for v in violations))

    def test_record_content_not_an_object_fails(self) -> None:
        assessment = _preferred_assessment()
        assessment["preferenceAuthority"]["gc026Attestation"]["recordContent"] = "not-an-object"
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("recordContent is missing or not an object" in v for v in violations))

    def test_record_content_missing_promotion_record_ref_fails(self) -> None:
        assessment = _preferred_assessment()
        del assessment["preferenceAuthority"]["gc026Attestation"]["recordContent"]["promotionRecordRef"]
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(any("recordContent.promotionRecordRef is missing" in v for v in violations))

    def test_record_content_hash_not_matching_recomputed_hash_fails(self) -> None:
        # Well-formed but fabricated recordContentHash: not the real
        # recomputed hash of recordContent.
        assessment = _preferred_assessment()
        assessment["preferenceAuthority"]["gc026Attestation"]["recordContentHash"] = HASH_C
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any("recordContentHash does not match the recomputed hash" in v for v in violations)
        )

    def test_record_content_names_different_task_class_id_fails(self) -> None:
        # An attestation internally consistent (real recomputed hash) but
        # bound to a DIFFERENT taskClassId than this assessment's.
        record_content = {
            "taskClassId": "task-class-DIFFERENT",
            "candidateConfigHash": HASH_A,
            "promotionRecordRef": "promotion-record-1",
            "promotedAt": "2026-09-01T00:00:00Z",
        }
        assessment = _preferred_assessment()
        assessment["preferenceAuthority"]["gc026Attestation"] = {
            "registrySnapshotHash": HASH_A,
            "recordContentHash": _recompute_gc026_record_content_hash(record_content),
            "recordContent": record_content,
        }
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any(
                "recordContent.taskClassId" in v and "does not match this assessment's taskClassId" in v
                for v in violations
            )
        )

    def test_record_content_names_different_candidate_config_hash_fails(self) -> None:
        # Direct analogue of R1's candidate-misattribution test, for
        # promotion attestation instead of G3 binding: internally consistent
        # attestation (real recomputed hash), but bound to a DIFFERENT
        # candidateConfigHash than the accepted candidate's.
        assessment = _preferred_assessment()
        assessment["preferenceAuthority"]["gc026Attestation"] = _gc026_attestation_for("task-class-1", HASH_B)
        violations = check_operating_point_assessment(assessment)
        self.assertTrue(
            any(
                "recordContent.candidateConfigHash" in v
                and "does not match the accepted candidate's candidateConfigHash" in v
                for v in violations
            )
        )

    def test_fully_consistent_correctly_bound_attestation_passes(self) -> None:
        # Positive control: a genuine, fully consistent, correctly-bound
        # attestation still reaches admission with no violations.
        violations = check_operating_point_assessment(_preferred_assessment())
        self.assertEqual(violations, [])

    def test_never_mutates_input(self) -> None:
        assessment = _preferred_assessment()
        snapshot = json.loads(json.dumps(assessment))
        check_operating_point_assessment(assessment)
        self.assertEqual(assessment, snapshot)


if __name__ == "__main__":
    unittest.main()
