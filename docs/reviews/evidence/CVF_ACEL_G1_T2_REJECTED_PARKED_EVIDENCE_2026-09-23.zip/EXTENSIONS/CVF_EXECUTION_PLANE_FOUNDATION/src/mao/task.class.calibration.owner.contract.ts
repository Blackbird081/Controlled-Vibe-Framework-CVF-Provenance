// CVF ACEL G1-T2 - Task-Class Calibration Owner Contract (offline, pure). Implements docs/reference/agent_system_skills/CVF_TASK_CLASS_CALIBRATION_OWNER_CONTRACT.md per the paired G1-T2 work order/baseline, composing (without modifying) the accepted G1 T1 design manifest (docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json).
// Full negative-case-to-fix matrix (both repair passes): docs/audits/CVF_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md. R1/R2 fixes documented inline at each site (search "R1 Finding" / "R2-"); summary: binding is cross-checked via producerReceipt plus a genuine G3 invocation; preference authority requires bound-evidence fields and full score coverage; hashes (provenanceFingerprint, candidateConfigHash, comparabilityFingerprint, gc026Attestation.recordContentHash) are real, independently recomputed digests, never trusted as opaque strings; round-level G3 fixture-set admission genuinely gates eligibility.
// No network/credential/provider/benchmark/file I/O occurs here. Every exported function is pure and total: identical inputs always return an identical, frozen result, and no runtime input - however malformed, missing, empty, unknown, or inconsistent - can throw or bypass validation. Never selects a real operating point, never mutates configuration, never asserts G4 marginal-value measurement.
// Reused/composed owner surfaces (REUSE ONLY; never modified here): assf.behavioral.evaluation.contract.ts (G3 grading/admission, genuinely invoked); performance.benchmark.harness.contract.ts (optional exploratory PROPOSAL_ONLY evidence, minimal shape); CVF_PROVIDER_LANE_READINESS_MATRIX.md (eligibility precondition only).
// SHA-256: uses `node:crypto` `createHash("sha256")` directly for a full 64-hex-char hash (`computeDeterministicHash` truncates to 32); `node:crypto` is already a sibling-module dependency.
import { createHash } from "node:crypto";
import { gradeBehavioralEvaluation, admitFixtureSet, type BehavioralEvaluation, type FixtureSetAdmissionEvaluation } from "./assf.behavioral.evaluation.contract";

// --- Structural validation helpers (mirrors G3's) ---
function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}
function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}

const HASH_PATTERN = /^[0-9a-f]{64}$/; // SHA-256 canonical hash format, reused exactly from the G3 contract

function isCanonicalHash(value: unknown): value is string {
  return typeof value === "string" && HASH_PATTERN.test(value);
}

function isNonEmptyStringArray(value: unknown): value is string[] {
  return isStringArray(value) && value.length > 0 && value.every((item) => item.trim().length > 0);
}

function sha256Hex(...parts: string[]): string { // real SHA-256 over a deterministically pipe-joined preimage; pure, total, never throws
  return createHash("sha256").update(parts.join("|")).digest("hex");
}

// --- R2 Finding 2/3: canonical serialization for hash recomputation. Deterministically sorts object keys at every nesting level (arrays keep declared order) before JSON-encoding, so two callers supplying the same logical `declaredDimensions`/`recordContent` value with differently ordered keys still recompute the identical hash ("stable-sorted-keys JSON stringify", per CVF_TASK_CLASS_CALIBRATION_OWNER_CONTRACT.md). Pure, total, never throws: `bigint`/`function`/`symbol`/`undefined` coerce to `null` via JSON.stringify's own replacer semantics. ---
function canonicalSortKeys(value: unknown): unknown {
  if (Array.isArray(value)) return value.map((item) => canonicalSortKeys(item));
  if (!isPlainObject(value)) return value;
  const sorted: Record<string, unknown> = {};
  for (const key of Object.keys(value).sort()) sorted[key] = canonicalSortKeys(value[key]);
  return sorted;
}

function canonicalStringify(value: unknown): string {
  try {
    return JSON.stringify(canonicalSortKeys(value)) ?? "null";
  } catch {
    // JSON.stringify throws only on a circular reference; fails closed to a fixed sentinel preimage.
    return "<CIRCULAR_UNSERIALIZABLE>";
  }
}

const CANDIDATE_CONFIG_HASH_CANONICAL_VERSION = "cvf.taskClassCalibrationOwner.candidateConfigHash.v1"; // versioned hash-formula prefix
const GC026_RECORD_CONTENT_HASH_CANONICAL_VERSION = "cvf.taskClassCalibrationOwner.gc026RecordContent.v1";

function recomputeCandidateConfigHash(declaredDimensions: Readonly<Record<string, unknown>>): string { // R2 Finding 2: candidate's declaredDimensions hash
  return sha256Hex(CANDIDATE_CONFIG_HASH_CANONICAL_VERSION, canonicalStringify(declaredDimensions));
}

function recomputeGc026RecordContentHash(recordContent: unknown): string { // R2 Finding 3: GC-026 attestation's recordContent hash
  return sha256Hex(GC026_RECORD_CONTENT_HASH_CANONICAL_VERSION, canonicalStringify(recordContent));
}

// --- Provider-lane readiness (eligibility-only; never ranking evidence); status taxonomy reused verbatim from CVF_PROVIDER_LANE_READINESS_MATRIX.md. ---
export type ProviderLaneReadinessStatus =
  "UNCONFIGURED" | "BLOCKED" | "LIVE" | "CANARY_PASS" | "CERTIFIED" | "DEGRADED" | "EXPERIMENTAL";

const VALID_READINESS_STATUSES: readonly ProviderLaneReadinessStatus[] = [
  "UNCONFIGURED", "BLOCKED", "LIVE", "CANARY_PASS", "CERTIFIED", "DEGRADED", "EXPERIMENTAL",
];

// --- G3 repeat-policy semantics (reused directly; never re-derived) ---
export type CandidateRepeatPolicy = "DETERMINISTIC" | "STOCHASTIC";
const VALID_REPEAT_POLICIES: readonly CandidateRepeatPolicy[] = ["DETERMINISTIC", "STOCHASTIC"];
const REQUIRED_REPEATS_BY_POLICY: Readonly<Record<CandidateRepeatPolicy, number>> = {
  DETERMINISTIC: 1,
  STOCHASTIC: 3,
};

// G3's admitted-evidence result vocabulary; only PASS_WITH_EVIDENCE from an admitted held-out fixture supplies acceptance evidence (others insufficient_evidence/ineligible below).
export type G3BoundResult =
  "PASS_WITH_EVIDENCE" | "FAIL_WITH_DEFECTS" | "INCOMPLETE_TRACE" | "UNDECLARED_TOOL_USE"
  | "STALE_REPLAY_PROVENANCE" | "NONEQUIVALENT_BASELINE_PAIR" | "INSUFFICIENT_REPEAT_EVIDENCE";

const VALID_G3_RESULTS: readonly G3BoundResult[] = [
  "PASS_WITH_EVIDENCE", "FAIL_WITH_DEFECTS", "INCOMPLETE_TRACE", "UNDECLARED_TOOL_USE",
  "STALE_REPLAY_PROVENANCE", "NONEQUIVALENT_BASELINE_PAIR", "INSUFFICIENT_REPEAT_EVIDENCE",
];

// "Complete bound substantive G3 defect" results vs. missing/incomplete-evidence results.
const G3_SUBSTANTIVE_DEFECT_RESULTS: ReadonlySet<G3BoundResult> = new Set([
  "FAIL_WITH_DEFECTS", "UNDECLARED_TOOL_USE", "NONEQUIVALENT_BASELINE_PAIR",
]);
const G3_MISSING_EVIDENCE_RESULTS: ReadonlySet<G3BoundResult> = new Set([
  "INCOMPLETE_TRACE", "STALE_REPLAY_PROVENANCE", "INSUFFICIENT_REPEAT_EVIDENCE",
]);

// --- Producer receipt (R1 Finding 1: a bare producerReceiptRef names nothing to check). ---
export interface TaskClassCalibrationProducerReceipt {
  readonly receiptRef: string;
  readonly candidateId: string;
  readonly candidateConfigHash: string;
  readonly traceIds: readonly string[];
}

function isValidProducerReceipt(value: unknown): value is TaskClassCalibrationProducerReceipt {
  return (
    isPlainObject(value) && isNonEmptyString(value.receiptRef) && isNonEmptyString(value.candidateId) &&
    isCanonicalHash(value.candidateConfigHash) && isNonEmptyStringArray(value.traceIds)
  );
}

// --- Candidate evidence envelope (G1 manifest candidateEvidenceBinding.requiredFields) ---
export interface TaskClassCalibrationCandidateEnvelope {
  readonly taskClassId: string;
  readonly candidateId: string;
  readonly candidateConfigHash: string;
  readonly comparabilityFingerprint: string;
  // R2 Finding 2: remaining fields for comparabilityFingerprint recompute/cross-check.
  readonly canonicalVersion: string;
  readonly environmentDescriptorHash: string;
  readonly acceptanceCriteriaVersion: string;
  readonly gradingRubricVersionHash: string;
  readonly heldoutPartitionHash: string;

  readonly fixtureSetContentHash: string;
  readonly fixtureId: string;
  readonly fixtureContentHash: string;
  readonly traceIds: readonly string[];
  readonly traceContentHashes: readonly string[];
  readonly traceCaptureModes: readonly string[];
  readonly g3ResultHash: string;
  readonly producerReceiptRef: string;
  // R1 Finding 1: structured receipt naming the identity attested to (producerReceiptRef alone is unverifiable).
  readonly producerReceipt: TaskClassCalibrationProducerReceipt;
  // R1 Finding 1: actual G3 fixture/trace(s)/optional paired-fixture, in-memory (no file I/O); genuinely invoked/cross-checked.
  readonly g3Fixture: unknown;
  readonly g3Traces: unknown;
  readonly g3PairedFixture?: unknown;
  readonly partition: "SEARCH" | "HELD_OUT"; // predeclared separately from G3 baselineRole
  // G3-bound evaluation summary (reused fields; verified, not re-run, here).
  readonly g3Result: G3BoundResult;
  readonly repeatPolicy: CandidateRepeatPolicy;
  readonly repeatsObserved: number;
  readonly repeatsRequired: number;
  readonly heldoutAdmitted: boolean;
  readonly declaredDimensions: Readonly<Record<string, unknown>>; // allowed vs forbidden-from-silent-comparison
  readonly policyId: string;
  readonly budgetCeiling: number;
  readonly budgetConsumed: number;
  readonly providerLaneStatus: ProviderLaneReadinessStatus | null;
  // Optional secondary rubric-evaluator adapter; materialDefectFound=true always ineligible (never a bypass).
  readonly rubricEvaluatorAdapter?: {
    readonly materialDefectFound: boolean;
    readonly score?: number;
  } | null;
  // Optional exploratory PROPOSAL_ONLY benchmark evidence (minimal shape; never sufficient for preferred/RegressionBinding).
  readonly benchmarkReport?: {
    readonly evidenceClass: "PROPOSAL_ONLY";
    readonly totalMeasurements: number;
    readonly reportHash: string;
  } | null;
  readonly metricUnit?: string | null; // unknown_metrics_or_units detection
  // Contamination-detection fields: a match against a SEARCH-partition candidate's keys makes held-out evidence untrusted.
  readonly contaminationKeys: readonly string[];
}

// --- Preference authority (admissible basis only; never raw PROPOSAL_ONLY alone) ---
export type PreferenceAuthorityKind =
  "GC026_PROMOTED_PERFORMANCE_REFERENCE" | "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC" | "PROPOSAL_ONLY_EXPLORATORY";

// R2 Finding 3: the caller-supplied attestation backing a GC026_PROMOTED_PERFORMANCE_REFERENCE authority. Stays pure/offline (never contacts a real registry), so it requires a richer, internally-verifiable structure with its own checked consistency: `recordContentHash` is independently recomputable; `recordContent` must name the same taskClassId/candidateConfigHash as the candidate preferred, so an attestation for a different candidate is never reusable.
export interface TaskClassCalibrationGc026AttestationRecordContent {
  readonly taskClassId: string;
  readonly candidateConfigHash: string;
  readonly promotionRecordRef: string;
  readonly promotedAt: string;
}

export interface TaskClassCalibrationGc026Attestation {
  readonly registrySnapshotHash: string;
  readonly recordContentHash: string;
  readonly recordContent: TaskClassCalibrationGc026AttestationRecordContent;
}

function isValidGc026AttestationRecordContent(value: unknown): value is TaskClassCalibrationGc026AttestationRecordContent {
  return (
    isPlainObject(value) && isNonEmptyString(value.taskClassId) && isCanonicalHash(value.candidateConfigHash) &&
    isNonEmptyString(value.promotionRecordRef) && isNonEmptyString(value.promotedAt)
  );
}

function isValidGc026Attestation(value: unknown): value is TaskClassCalibrationGc026Attestation {
  return (
    isPlainObject(value) && isCanonicalHash(value.registrySnapshotHash) &&
    isCanonicalHash(value.recordContentHash) && isValidGc026AttestationRecordContent(value.recordContent)
  );
}

export interface PreferenceAuthorityDeclaration {
  readonly kind: PreferenceAuthorityKind;
  readonly ref: string;
  // Value per candidateId (higher preferred); PROPOSAL_ONLY_EXPLORATORY is same shape but never admissible.
  readonly valueByCandidateId: Readonly<Record<string, number>>;
  // R1 Finding 2: bound-evidence identity fields required per `kind` (a bound reference, not a free-text label). GC026 requires promotionRecordRef+promotedAt; rubric requires rubricVersionHash.
  readonly promotionRecordRef?: string;
  readonly promotedAt?: string;
  readonly rubricVersionHash?: string;
  // R2 Finding 3: required, structured, internally-verifiable attestation for GC026_PROMOTED_PERFORMANCE_REFERENCE; not required for rubric (out of R2-3's scope; see contract doc/audit).
  readonly gc026Attestation?: TaskClassCalibrationGc026Attestation;
}

// R1 Finding 2 (kind-level bound-evidence fields) plus R2 Finding 3 (GC026 attestation structural validity, independent of candidate). Candidate binding is checked separately at selection time in evaluateTaskClassCalibrationRound, since it depends on the winner.
function hasAdmissibleBoundEvidence(authority: PreferenceAuthorityDeclaration): boolean {
  if (authority.kind === "GC026_PROMOTED_PERFORMANCE_REFERENCE") {
    return (
      isNonEmptyString(authority.promotionRecordRef) &&
      isNonEmptyString(authority.promotedAt) &&
      isValidGc026Attestation(authority.gc026Attestation) &&
      // R2 Finding 3(a): recordContentHash must be the real recomputed hash of recordContent.
      authority.gc026Attestation.recordContentHash ===
        recomputeGc026RecordContentHash(authority.gc026Attestation.recordContent)
    );
  }
  if (authority.kind === "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC") {
    return isCanonicalHash(authority.rubricVersionHash);
  }
  return false;
}

// --- Decision states (exhaustive, exclusive; exact precedence order) ---
export type TaskClassCalibrationDecisionState =
  "incomparable" | "insufficient_evidence" | "ineligible" | "eligible_nonpreferred" | "preferred";

export interface TaskClassCalibrationCandidateDecision {
  readonly candidateId: string;
  readonly candidateConfigHash: string;
  readonly state: TaskClassCalibrationDecisionState;
  readonly reasons: readonly string[];
}

// R1 Finding 4: canonical schema marker, matching the Python checker's SCHEMA_MARKER exactly so real TS-produced documents are evaluated rather than silently skipped.
export const TASK_CLASS_CALIBRATION_OWNER_SCHEMA_MARKER = "cvf.taskClassCalibrationOwner";
const ASSESSMENT_SCHEMA_VERSION = `${TASK_CLASS_CALIBRATION_OWNER_SCHEMA_MARKER}.assessment.v1`;
const REGRESSION_BINDING_SCHEMA_VERSION = `${TASK_CLASS_CALIBRATION_OWNER_SCHEMA_MARKER}.regressionBinding.v1`;

export interface OperatingPointAssessment {
  readonly schemaVersion: string;
  readonly taskClassId: string;
  readonly comparabilityFingerprint: string;
  readonly candidateDecisions: readonly TaskClassCalibrationCandidateDecision[];
  readonly exclusions: readonly { readonly candidateId: string; readonly reason: string }[];
  readonly acceptedCandidateId: string | null;
  // R1 Finding 4: included so the Python checker's preference-authority validation has a real field to inspect.
  readonly preferenceAuthority: PreferenceAuthorityDeclaration | null;
  readonly provenanceFingerprint: string | null;
  readonly roundOutcome: "ACCEPTED_PREFERRED" | "NO_ADMISSIBLE_PREFERENCE_EVIDENCE" | "TIE_NO_AUTOMATIC_PREFERENCE" | "NO_ELIGIBLE_CANDIDATE";
  readonly acceptedAt: string | null;
  readonly claimBoundary: string;
}

export interface RegressionBinding {
  readonly schemaVersion: string;
  readonly taskClassId: string;
  readonly acceptedCandidateId: string;
  readonly candidateConfigHash: string;
  readonly comparabilityFingerprint: string;
  readonly provenanceFingerprint: string;
  readonly orderedEvidenceEnvelopeHashes: readonly string[];
  readonly preferenceAuthorityRef: string;
  readonly boundAt: string;
  readonly invalidationStatus: "CURRENT" | "STALE";
  readonly requiredRegradeTriggerSet: readonly string[];
}

export type InvalidationTrigger =
  | "fixture_set_content_hash_changes_for_bound_task_class"
  | "candidate_config_or_bound_trace_result_or_producer_receipt_changes"
  | "partition_rubric_environment_policy_acceptance_or_preference_policy_changes"
  | "accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum"
  | "gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence"
  | "accepted_candidate_budget_ceiling_lowered_below_recorded_consumption";

const ALL_INVALIDATION_TRIGGERS: readonly InvalidationTrigger[] = [
  "fixture_set_content_hash_changes_for_bound_task_class",
  "candidate_config_or_bound_trace_result_or_producer_receipt_changes",
  "partition_rubric_environment_policy_acceptance_or_preference_policy_changes",
  "accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum",
  "gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence", "accepted_candidate_budget_ceiling_lowered_below_recorded_consumption",
];

const CLAIM_BOUNDARY =
  "pure offline decision layer over supplied synthetic candidate evidence; never invokes a provider, " +
  "never executes a real calibration or benchmark run, never mutates a live operating configuration, and never certifies G4 marginal/incremental value";

// --- Forbidden-from-silent-comparison / allowed dimension vocabulary ---
const ALLOWED_CANDIDATE_DIMENSIONS: ReadonlySet<string> = new Set([
  "effort_reasoning_level_profile", "prompt_scaffolding_profile", "tool_set_selection",
  "context_window_policy", "budget_ceiling", "topology_when_g2_supplies_reallocation_primitive",
  "provider_model_lane_subject_to_readiness_gating",
]);

const FORBIDDEN_FROM_SILENT_COMPARISON_DIMENSIONS: ReadonlySet<string> = new Set([
  "task_case_set_fixture_set", "environment_sandbox_tier", "policy_risk_ceiling",
  "acceptance_criteria", "grading_rubric_or_fixture_version",
]);

// --- Structural validation of one candidate envelope ---
function validateEnvelopeStructure(value: unknown): string[] {
  const problems: string[] = [];
  if (!isPlainObject(value)) {
    return ["candidate envelope must be an object"];
  }

  if (!isNonEmptyString(value.taskClassId)) problems.push("taskClassId must be a non-empty string");
  if (!isNonEmptyString(value.candidateId)) problems.push("candidateId must be a non-empty string");
  if (!isCanonicalHash(value.candidateConfigHash)) problems.push("candidateConfigHash must be a canonical SHA-256 hash");
  if (!isCanonicalHash(value.comparabilityFingerprint)) problems.push("comparabilityFingerprint must be a canonical SHA-256 hash");
  if (!isNonEmptyString(value.canonicalVersion)) problems.push("canonicalVersion must be a non-empty string");
  if (!isCanonicalHash(value.environmentDescriptorHash)) problems.push("environmentDescriptorHash must be a canonical SHA-256 hash");
  if (!isNonEmptyString(value.acceptanceCriteriaVersion)) problems.push("acceptanceCriteriaVersion must be a non-empty string");
  if (!isCanonicalHash(value.gradingRubricVersionHash)) problems.push("gradingRubricVersionHash must be a canonical SHA-256 hash");
  if (!isCanonicalHash(value.heldoutPartitionHash)) problems.push("heldoutPartitionHash must be a canonical SHA-256 hash");
  if (!isCanonicalHash(value.fixtureSetContentHash)) problems.push("fixtureSetContentHash must be a canonical SHA-256 hash");
  if (!isNonEmptyString(value.fixtureId)) problems.push("fixtureId must be a non-empty string");
  if (!isCanonicalHash(value.fixtureContentHash)) problems.push("fixtureContentHash must be a canonical SHA-256 hash");
  if (!isNonEmptyStringArray(value.traceIds)) problems.push("traceIds must be a non-empty array of strings");
  if (!Array.isArray(value.traceContentHashes) || value.traceContentHashes.length === 0 || !value.traceContentHashes.every((h) => isCanonicalHash(h))) {
    problems.push("traceContentHashes must be a non-empty array of canonical SHA-256 hashes");
  }
  if (!isNonEmptyStringArray(value.traceCaptureModes)) problems.push("traceCaptureModes must be a non-empty array of strings");
  if (!isCanonicalHash(value.g3ResultHash)) problems.push("g3ResultHash must be a canonical SHA-256 hash");
  if (!isNonEmptyString(value.producerReceiptRef)) problems.push("producerReceiptRef must be a non-empty string");
  if (!isValidProducerReceipt(value.producerReceipt)) {
    problems.push("producerReceipt must be an object with receiptRef, candidateId, canonical-hash candidateConfigHash, and a non-empty traceIds array");
  }
  if (value.g3Fixture === undefined) problems.push("g3Fixture must be supplied (the actual G3 fixture object this evidence is grounded in)");
  if (value.g3Traces === undefined) problems.push("g3Traces must be supplied (the actual G3 trace object(s) this evidence is grounded in)");
  if (value.partition !== "SEARCH" && value.partition !== "HELD_OUT") problems.push("partition must be SEARCH or HELD_OUT");
  if (typeof value.g3Result !== "string" || !VALID_G3_RESULTS.includes(value.g3Result as G3BoundResult)) {
    problems.push(`g3Result must be one of ${VALID_G3_RESULTS.join(", ")}`);
  }
  if (typeof value.repeatPolicy !== "string" || !VALID_REPEAT_POLICIES.includes(value.repeatPolicy as CandidateRepeatPolicy)) {
    problems.push(`repeatPolicy must be one of ${VALID_REPEAT_POLICIES.join(", ")}`);
  }
  if (typeof value.repeatsObserved !== "number" || !Number.isFinite(value.repeatsObserved) || value.repeatsObserved < 0) {
    problems.push("repeatsObserved must be a non-negative finite number");
  }
  if (typeof value.repeatsRequired !== "number" || !Number.isFinite(value.repeatsRequired) || value.repeatsRequired < 0) {
    problems.push("repeatsRequired must be a non-negative finite number");
  }
  if (typeof value.heldoutAdmitted !== "boolean") problems.push("heldoutAdmitted must be a boolean");
  if (!isPlainObject(value.declaredDimensions)) problems.push("declaredDimensions must be an object");
  if (!isNonEmptyString(value.policyId)) problems.push("policyId must be a non-empty string");
  if (typeof value.budgetCeiling !== "number" || !Number.isFinite(value.budgetCeiling) || value.budgetCeiling < 0) {
    problems.push("budgetCeiling must be a non-negative finite number");
  }
  if (typeof value.budgetConsumed !== "number" || !Number.isFinite(value.budgetConsumed) || value.budgetConsumed < 0) {
    problems.push("budgetConsumed must be a non-negative finite number");
  }
  if (value.providerLaneStatus !== null && (typeof value.providerLaneStatus !== "string" || !VALID_READINESS_STATUSES.includes(value.providerLaneStatus as ProviderLaneReadinessStatus))) {
    problems.push(`providerLaneStatus must be null or one of ${VALID_READINESS_STATUSES.join(", ")}`);
  }
  if (value.rubricEvaluatorAdapter !== undefined && value.rubricEvaluatorAdapter !== null) {
    if (!isPlainObject(value.rubricEvaluatorAdapter) || typeof value.rubricEvaluatorAdapter.materialDefectFound !== "boolean") {
      problems.push("rubricEvaluatorAdapter, when present, must be an object with a boolean materialDefectFound");
    }
  }
  if (value.benchmarkReport !== undefined && value.benchmarkReport !== null) {
    if (!isPlainObject(value.benchmarkReport) || value.benchmarkReport.evidenceClass !== "PROPOSAL_ONLY" || typeof value.benchmarkReport.totalMeasurements !== "number" || !isCanonicalHash(value.benchmarkReport.reportHash)) {
      problems.push("benchmarkReport, when present, must be a PROPOSAL_ONLY-shaped object with totalMeasurements and reportHash");
    }
  }
  if (value.metricUnit !== undefined && value.metricUnit !== null && (typeof value.metricUnit !== "string" || value.metricUnit.trim().length === 0)) {
    problems.push("metricUnit, when present, must be null or a non-empty string");
  }
  if (!isStringArray(value.contaminationKeys)) problems.push("contaminationKeys must be an array of strings");

  return problems;
}

function toTypedEnvelope(value: unknown): TaskClassCalibrationCandidateEnvelope {
  return value as TaskClassCalibrationCandidateEnvelope;
}

// --- Comparability fingerprint: SHA-256(canonicalVersion | taskClassId | fixtureSetContentHash | environmentDescriptorHash | policyId | acceptanceCriteriaVersion | gradingRubricVersionHash | heldoutPartitionHash). Callers supply the already-computed value; this module only verifies stability/consistency across one round. ---
export interface ComparabilityFingerprintInputs {
  readonly canonicalVersion: string;
  readonly taskClassId: string;
  readonly fixtureSetContentHash: string;
  readonly environmentDescriptorHash: string;
  readonly policyId: string;
  readonly acceptanceCriteriaVersion: string;
  readonly gradingRubricVersionHash: string;
  readonly heldoutPartitionHash: string;
}

// Deterministically composes the exact ordered field string the comparability fingerprint hashes, so a caller can verify a supplied `comparabilityFingerprint` without this module owning a hash implementation. Pure, total, never throws (non-string fields coerce to "").
export function composeComparabilityFingerprintPreimage(inputs: ComparabilityFingerprintInputs): string {
  const field = (v: unknown): string => (typeof v === "string" ? v : "");
  return [
    field(inputs.canonicalVersion), field(inputs.taskClassId), field(inputs.fixtureSetContentHash),
    field(inputs.environmentDescriptorHash), field(inputs.policyId), field(inputs.acceptanceCriteriaVersion),
    field(inputs.gradingRubricVersionHash), field(inputs.heldoutPartitionHash),
  ].join("|");
}

// --- Dimension comparison ---
function forbiddenDimensionVaries(a: Readonly<Record<string, unknown>>, b: Readonly<Record<string, unknown>>): string | null {
  for (const key of FORBIDDEN_FROM_SILENT_COMPARISON_DIMENSIONS) {
    const hasA = Object.prototype.hasOwnProperty.call(a, key);
    const hasB = Object.prototype.hasOwnProperty.call(b, key);
    if (!hasA && !hasB) continue;
    const va = hasA ? JSON.stringify(a[key]) : undefined;
    const vb = hasB ? JSON.stringify(b[key]) : undefined;
    if (va !== vb) return key;
  }
  return null;
}

// --- Round input ---
export interface TaskClassCalibrationRoundInput {
  readonly taskClassId: string;
  readonly candidates: readonly unknown[];
  readonly preferenceAuthority?: PreferenceAuthorityDeclaration | null;
  readonly allowedProviderLaneStatuses?: readonly ProviderLaneReadinessStatus[];
  readonly acceptedAt?: string | null;
  readonly canonicalVersion?: string;
}

export type TaskClassCalibrationRoundOutcome =
  | { readonly kind: "BLOCKED_EMPTY_CANDIDATE_SET" }
  | { readonly kind: "BLOCKED_DUPLICATE_CANDIDATE_IDENTITY"; readonly detail: string }
  | { readonly kind: "ASSESSED"; readonly assessment: OperatingPointAssessment; readonly regressionBinding: RegressionBinding | null };

const DEFAULT_CANONICAL_VERSION = "cvf.taskClassCalibrationOwner.v1";
const DEFAULT_ALLOWED_STATUSES: readonly ProviderLaneReadinessStatus[] = ["LIVE", "CANARY_PASS", "CERTIFIED"];

// Evaluates one task-class calibration round over N candidate evidence envelopes and produces exclusive decision states plus an optional OperatingPointAssessment/RegressionBinding. Pure, total, never throws, and never mutates any input. No provider, network, or benchmark execution occurs.
export function evaluateTaskClassCalibrationRound(input: unknown): TaskClassCalibrationRoundOutcome {
  if (!isPlainObject(input) || !isNonEmptyString((input as Record<string, unknown>).taskClassId)) {
    return Object.freeze({ kind: "BLOCKED_EMPTY_CANDIDATE_SET" as const });
  }
  const typedInput = input as unknown as TaskClassCalibrationRoundInput;

  const candidatesRaw = Array.isArray(typedInput.candidates) ? typedInput.candidates : [];
  if (candidatesRaw.length === 0) {
    return Object.freeze({ kind: "BLOCKED_EMPTY_CANDIDATE_SET" as const });
  }

  // A structurally malformed candidate is insufficient_evidence, not round-blocking (only identity dup/true emptiness block the round).
  const structuralProblemsByIndex = candidatesRaw.map((c) => validateEnvelopeStructure(c));

  // Duplicate identity blocks the whole round, never silently overwritten/double-counted ("one ID two hashes" and "one hash two IDs"); malformed id/hash cannot collide.
  const idToHashes = new Map<string, Set<string>>();
  const hashToIds = new Map<string, Set<string>>();
  for (let i = 0; i < candidatesRaw.length; i += 1) {
    const c = candidatesRaw[i];
    if (!isPlainObject(c)) continue;
    const id = typeof c.candidateId === "string" ? c.candidateId : null;
    const hash = typeof c.candidateConfigHash === "string" ? c.candidateConfigHash : null;
    if (id === null || hash === null) continue;
    if (!idToHashes.has(id)) idToHashes.set(id, new Set());
    idToHashes.get(id)!.add(hash);
    if (!hashToIds.has(hash)) hashToIds.set(hash, new Set());
    hashToIds.get(hash)!.add(id);
  }
  for (const [id, hashes] of idToHashes) {
    if (hashes.size > 1) {
      return Object.freeze({
        kind: "BLOCKED_DUPLICATE_CANDIDATE_IDENTITY" as const,
        detail: `candidateId ${id} is bound to ${hashes.size} distinct candidateConfigHash values`,
      });
    }
  }
  for (const [hash, ids] of hashToIds) {
    if (ids.size > 1) {
      return Object.freeze({
        kind: "BLOCKED_DUPLICATE_CANDIDATE_IDENTITY" as const,
        detail: `candidateConfigHash ${hash} is claimed by ${ids.size} distinct candidateId values`,
      });
    }
  }

  // --- Contamination: HELD_OUT sharing a contaminationKey with SEARCH is REUSED_HELDOUT_SEARCH_DATA. ---
  const searchContaminationKeys = new Set<string>();
  for (const c of candidatesRaw) {
    if (isPlainObject(c) && c.partition === "SEARCH" && isStringArray(c.contaminationKeys)) {
      for (const key of c.contaminationKeys) searchContaminationKeys.add(key);
    }
  }

  // Round-level G3 fixture-set admission (Finding 1; R2-1: a genuine eligibility gate, not just a disclosure). Invoked over pooled g3Fixture objects from every candidate: a round not ADMITTED (MISSING_POSITIVE_CASE/MISSING_NEGATIVE_CASE/MALFORMED_FIXTURE_SET) never certifies ANY candidate eligible.
  const roundFixturePool: unknown[] = [];
  for (const c of candidatesRaw) {
    if (isPlainObject(c) && c.g3Fixture !== undefined) {
      roundFixturePool.push(c.g3Fixture);
    }
  }
  const roundFixtureSetAdmission: FixtureSetAdmissionEvaluation =
    roundFixturePool.length > 0
      ? admitFixtureSet(roundFixturePool)
      : admitFixtureSet([]);
  const roundFixtureSetAdmitted = roundFixtureSetAdmission.admission === "ADMITTED";
  const roundFixtureSetAdmissionFailureReason =
    `round-level G3 fixture-set admission failed: ${roundFixtureSetAdmission.admission} ` +
    `(positiveCount=${roundFixtureSetAdmission.positiveCount}, negativeCount=${roundFixtureSetAdmission.negativeCount}); ` +
    "no candidate in this round may become eligible without a G3-admitted positive+negative fixture set";

  // --- Per-candidate decision ---
  type WorkingDecision = {
    candidateId: string;
    candidateConfigHash: string;
    state: TaskClassCalibrationDecisionState;
    reasons: string[];
    envelope: TaskClassCalibrationCandidateEnvelope | null;
  };

  const allowedStatuses = new Set<ProviderLaneReadinessStatus>(
    Array.isArray(typedInput.allowedProviderLaneStatuses) && typedInput.allowedProviderLaneStatuses.length > 0
      ? typedInput.allowedProviderLaneStatuses
      : DEFAULT_ALLOWED_STATUSES,
  );

  // Reference fingerprint: the first structurally valid candidate's; others compare against it.
  let referenceFingerprint: string | null = null;
  let referenceFixtureSetHash: string | null = null;
  let referenceDimensions: Readonly<Record<string, unknown>> | null = null;
  for (let i = 0; i < candidatesRaw.length; i += 1) {
    if (structuralProblemsByIndex[i].length === 0) {
      const env = toTypedEnvelope(candidatesRaw[i]);
      referenceFingerprint = env.comparabilityFingerprint;
      referenceFixtureSetHash = env.fixtureSetContentHash;
      referenceDimensions = env.declaredDimensions;
      break;
    }
  }

  const decisions: WorkingDecision[] = candidatesRaw.map((raw, i) => {
    const rawIdForLabel =
      isPlainObject(raw) && typeof raw.candidateId === "string" && raw.candidateId
        ? raw.candidateId
        : `<unidentified-candidate-${i}>`;
    const rawHashForLabel =
      isPlainObject(raw) && typeof raw.candidateConfigHash === "string" ? raw.candidateConfigHash : "";

    const structuralProblems = structuralProblemsByIndex[i];
    if (structuralProblems.length > 0) {
      return {
        candidateId: rawIdForLabel,
        candidateConfigHash: rawHashForLabel,
        state: "insufficient_evidence" as const,
        reasons: [`malformed candidate envelope: ${structuralProblems.join("; ")}`],
        envelope: null,
      };
    }

    const env = toTypedEnvelope(raw);
    const reasons: string[] = [];
    // Builds the WorkingDecision shape so every fail-closed return below stays one line.
    const fail = (state: TaskClassCalibrationDecisionState, reason: string) => {
      reasons.push(reason);
      return { candidateId: env.candidateId, candidateConfigHash: env.candidateConfigHash, state, reasons, envelope: env };
    };

    // 1. incomparable - fingerprint mismatch or forbidden-dimension variance.
    if (referenceFingerprint !== null && env.comparabilityFingerprint !== referenceFingerprint) {
      const fixtureMismatch =
        referenceFixtureSetHash !== null && env.fixtureSetContentHash !== referenceFixtureSetHash;
      return fail(
        "incomparable",
        fixtureMismatch
          ? "stale/mismatched comparabilityFingerprint: fixtureSetContentHash differs from the round's reference fingerprint (mixed_task_case_sets)"
          : "stale/mismatched comparabilityFingerprint: candidate evidence is under a different comparabilityFingerprint than the round's reference (stale_fingerprints)",
      );
    }
    if (referenceDimensions !== null) {
      const forbiddenKey = forbiddenDimensionVaries(referenceDimensions, env.declaredDimensions);
      if (forbiddenKey !== null) {
        return fail(
          "incomparable",
          `forbidden-from-silent-comparison dimension "${forbiddenKey}" varies from the round's reference candidate; never silently merged`,
        );
      }
    }
    if (referenceFingerprint !== null && env.comparabilityFingerprint === referenceFingerprint) {
      // policyId is checked separately (unequal_budgets_or_policies) even if fingerprint matches.
      const referencePolicyCandidate = candidatesRaw.find(
        (c, j) => structuralProblemsByIndex[j].length === 0 && toTypedEnvelope(c).comparabilityFingerprint === referenceFingerprint,
      );
      if (referencePolicyCandidate) {
        const referencePolicyId = toTypedEnvelope(referencePolicyCandidate).policyId;
        if (env.policyId !== referencePolicyId) {
          return fail(
            "incomparable",
            `policyId ("${env.policyId}") differs from the round's reference policyId ("${referencePolicyId}"); different policies are never merged`,
          );
        }
      }
    }

    // 2. insufficient_evidence - missing/ambiguous binding, held-out admission, G3 trace/repeats, or contamination. R2-1: round-level G3 fixture-set admission gate, checked first (round-wide precondition).
    if (!roundFixtureSetAdmitted) {
      return fail("insufficient_evidence", roundFixtureSetAdmissionFailureReason);
    }

    if (env.partition === "HELD_OUT") {
      const contaminated = env.contaminationKeys.some((key) => searchContaminationKeys.has(key));
      if (contaminated) {
        return fail(
          "insufficient_evidence",
          "REUSED_HELDOUT_SEARCH_DATA: held-out evidence shares a contamination key with SEARCH-partition evidence in this round",
        );
      }
    }

    if (env.partition !== "HELD_OUT" || !env.heldoutAdmitted) {
      return fail(
        "insufficient_evidence",
        "missing required held-out G3 admission: only a G3-admitted held-out fixture may supply acceptance evidence",
      );
    }

    // R2-2: candidate-declared taskClassId must match the round's; never silently certify a different task class.
    if (env.taskClassId !== typedInput.taskClassId) {
      return fail(
        "insufficient_evidence",
        `candidate declares taskClassId ("${env.taskClassId}") that does not match the round's declared taskClassId ("${typedInput.taskClassId}")`,
      );
    }

    // R2-2: candidateConfigHash must equal the recomputed SHA-256 of declaredDimensions.
    const recomputedCandidateConfigHash = recomputeCandidateConfigHash(env.declaredDimensions);
    if (env.candidateConfigHash !== recomputedCandidateConfigHash) {
      return fail(
        "insufficient_evidence",
        `declared candidateConfigHash does not match the recomputed hash of declaredDimensions (recomputed=${recomputedCandidateConfigHash})`,
      );
    }

    // R2-2: comparabilityFingerprint must equal the recomputed hash of its declared fields. Distinct from the tier-1 incomparable check (two candidates' declared fingerprints): this checks whether a *single* candidate's own fingerprint is itself verifiable.
    const recomputedComparabilityFingerprint = sha256Hex(
      composeComparabilityFingerprintPreimage({
        canonicalVersion: env.canonicalVersion,
        taskClassId: env.taskClassId,
        fixtureSetContentHash: env.fixtureSetContentHash,
        environmentDescriptorHash: env.environmentDescriptorHash,
        policyId: env.policyId,
        acceptanceCriteriaVersion: env.acceptanceCriteriaVersion,
        gradingRubricVersionHash: env.gradingRubricVersionHash,
        heldoutPartitionHash: env.heldoutPartitionHash,
      }),
    );
    if (env.comparabilityFingerprint !== recomputedComparabilityFingerprint) {
      return fail(
        "insufficient_evidence",
        `declared comparabilityFingerprint does not match the recomputed hash of its declared constituent fields (recomputed=${recomputedComparabilityFingerprint}); a single candidate's own unverifiable/fabricated fingerprint is evidentiary insufficiency, distinct from the cross-candidate incomparable mismatch check`,
      );
    }

    // Binding verification (Finding 1): trace array lengths must agree.
    if (env.traceIds.length !== env.traceContentHashes.length || env.traceIds.length !== env.traceCaptureModes.length) {
      return fail(
        "insufficient_evidence",
        "ambiguous candidate/trace binding: traceIds, traceContentHashes, and traceCaptureModes have inconsistent lengths",
      );
    }

    // Producer-to-candidate binding (Finding 1a): mismatch fails closed even when real/PASS_WITH_EVIDENCE.
    const receipt = env.producerReceipt;
    const receiptTraceIdSet = new Set(receipt.traceIds);
    const receiptMismatch =
      receipt.candidateId !== env.candidateId ||
      receipt.candidateConfigHash !== env.candidateConfigHash ||
      receiptTraceIdSet.size !== new Set(env.traceIds).size ||
      env.traceIds.some((id) => !receiptTraceIdSet.has(id));
    if (receiptMismatch) {
      return fail(
        "insufficient_evidence",
        `producer-to-candidate binding mismatch: producerReceipt names candidateId=${receipt.candidateId}, candidateConfigHash=${receipt.candidateConfigHash}, traceIds=[${receipt.traceIds.join(",")}], which does not match the presenting candidate (candidateId=${env.candidateId}, candidateConfigHash=${env.candidateConfigHash}, traceIds=[${env.traceIds.join(",")}]); a receipt or G3 result bound to a different candidate can never attest this candidate's evidence`,
      );
    }

    // Actual supplied bytes (Finding 1b): invoke G3's grading; cross-check against declared hashes below.
    const g3Evaluation: BehavioralEvaluation = gradeBehavioralEvaluation(env.g3Fixture, env.g3Traces, env.g3PairedFixture);

    const declaredFixture = isPlainObject(env.g3Fixture) ? env.g3Fixture : null;
    const declaredFixtureContentHash =
      declaredFixture && isCanonicalHash(declaredFixture.fixtureContentHash) ? declaredFixture.fixtureContentHash : null;
    const fixtureContentHashConsistent = declaredFixtureContentHash === env.fixtureContentHash;

    const declaredTraces = Array.isArray(env.g3Traces) ? env.g3Traces : [];
    const traceContentHashesConsistent =
      declaredTraces.length === env.traceContentHashes.length &&
      declaredTraces.every(
        (t, idx) => isPlainObject(t) && isCanonicalHash(t.sourceContentHash) && t.sourceContentHash === env.traceContentHashes[idx],
      );

    // g3ResultHash must be the real recomputed SHA-256, not an arbitrary hash.
    const recomputedG3ResultHash = sha256Hex(
      g3Evaluation.result,
      g3Evaluation.fixtureId,
      g3Evaluation.sourceContentHash,
      String(g3Evaluation.repeatsObserved),
      String(g3Evaluation.repeatsRequired),
    );
    const g3ResultHashConsistent = recomputedG3ResultHash === env.g3ResultHash;
    const g3EvaluationBoundToThisFixture = g3Evaluation.fixtureId === env.fixtureId;

    if (!fixtureContentHashConsistent || !traceContentHashesConsistent || !g3ResultHashConsistent || !g3EvaluationBoundToThisFixture) {
      const detail: string[] = [];
      if (!fixtureContentHashConsistent) detail.push("declared fixtureContentHash does not match the supplied g3Fixture.fixtureContentHash");
      if (!traceContentHashesConsistent) detail.push("declared traceContentHashes do not structurally match the supplied g3Traces[].sourceContentHash values");
      if (!g3ResultHashConsistent) detail.push(`declared g3ResultHash does not match the recomputed SHA-256 over the actual G3 evaluation result (recomputed=${recomputedG3ResultHash})`);
      if (!g3EvaluationBoundToThisFixture) detail.push(`G3 evaluation fixtureId (${g3Evaluation.fixtureId}) does not match the envelope's declared fixtureId (${env.fixtureId})`);
      return fail("insufficient_evidence", `candidate evidence binding could not be verified against actual supplied bytes: ${detail.join("; ")}`);
    }

    // Declared g3Result/repeatsObserved/repeatsRequired must match actual G3 output.
    if (
      g3Evaluation.result !== env.g3Result ||
      g3Evaluation.repeatsObserved !== env.repeatsObserved ||
      g3Evaluation.repeatsRequired !== env.repeatsRequired
    ) {
      return fail(
        "insufficient_evidence",
        `declared g3Result/repeatsObserved/repeatsRequired (${env.g3Result}/${env.repeatsObserved}/${env.repeatsRequired}) does not match the actual G3 evaluation (${g3Evaluation.result}/${g3Evaluation.repeatsObserved}/${g3Evaluation.repeatsRequired})`,
      );
    }

    const requiredRepeats = REQUIRED_REPEATS_BY_POLICY[env.repeatPolicy];
    if (env.repeatsRequired !== requiredRepeats) {
      return fail(
        "insufficient_evidence",
        `repeatsRequired (${env.repeatsRequired}) is inconsistent with repeatPolicy ${env.repeatPolicy} (must be exactly ${requiredRepeats})`,
      );
    }

    if (G3_MISSING_EVIDENCE_RESULTS.has(env.g3Result)) {
      return fail(
        "insufficient_evidence",
        `G3 evidence is missing/incomplete: result=${env.g3Result} (repeatsObserved=${env.repeatsObserved}, repeatsRequired=${env.repeatsRequired}); never rounded or averaged into a pass`,
      );
    }

    if (env.g3Result === "PASS_WITH_EVIDENCE" && env.repeatsObserved !== requiredRepeats) {
      return fail(
        "insufficient_evidence",
        `${env.repeatsObserved} consecutive passing repeat(s) observed; exactly ${requiredRepeats} required for repeatPolicy ${env.repeatPolicy}`,
      );
    }

    // 3. ineligible - complete bound substantive defect, risk, readiness, or budget failure (no-score-laundering).
    if (G3_SUBSTANTIVE_DEFECT_RESULTS.has(env.g3Result)) {
      return fail("ineligible", `complete bound substantive G3 defect: result=${env.g3Result}`);
    }

    if (env.rubricEvaluatorAdapter && env.rubricEvaluatorAdapter.materialDefectFound === true) {
      return fail("ineligible", "rubric-evaluator adapter reports materialDefectFound=true; no numeric score can reverse this eligibility failure");
    }

    if (env.budgetConsumed > env.budgetCeiling) {
      return fail("ineligible", `budgetConsumed (${env.budgetConsumed}) exceeds declared budgetCeiling (${env.budgetCeiling})`);
    }

    if (env.providerLaneStatus !== null && !allowedStatuses.has(env.providerLaneStatus)) {
      return fail(
        "ineligible",
        `providerLaneStatus (${env.providerLaneStatus}) is outside the predeclared allowed-status set {${Array.from(allowedStatuses).join(", ")}}`,
      );
    }

    // 4/5. eligible: eligible_nonpreferred unless later selected preferred.
    return { candidateId: env.candidateId, candidateConfigHash: env.candidateConfigHash, state: "eligible_nonpreferred" as const, reasons: [], envelope: env };
  });

  // --- Preference stage (stage 2): only over eligible candidates. ---
  const eligible = decisions.filter((d) => d.state === "eligible_nonpreferred" && d.envelope !== null);

  const exclusions = decisions
    .filter((d) => d.state !== "eligible_nonpreferred" && d.state !== "preferred")
    .map((d) => ({ candidateId: d.candidateId, reason: d.reasons.join("; ") || d.state }));

  // R2-1: also surface the round-level admission result as a disclosure entry.
  if (!roundFixtureSetAdmitted) {
    exclusions.push({
      candidateId: "",
      reason: `round-level G3 fixture-set admission: ${roundFixtureSetAdmission.admission} (positiveCount=${roundFixtureSetAdmission.positiveCount}, negativeCount=${roundFixtureSetAdmission.negativeCount}); every candidate in this round fails closed to insufficient_evidence as a result`,
    });
  }

  let roundOutcome: OperatingPointAssessment["roundOutcome"];
  let acceptedCandidateId: string | null = null;

  // Finding 2: admissible authority, retained to echo into the output shape.
  let admissiblePreferenceAuthority: PreferenceAuthorityDeclaration | null = null;

  if (eligible.length === 0) {
    roundOutcome = "NO_ELIGIBLE_CANDIDATE";
  } else {
    const authority = typedInput.preferenceAuthority ?? null;
    // Admissibility requires kind-specific bound-evidence field(s) too.
    const admissibleAuthority =
      authority !== null &&
      isPlainObject(authority) &&
      (authority.kind === "GC026_PROMOTED_PERFORMANCE_REFERENCE" ||
        authority.kind === "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC") &&
      isNonEmptyString(authority.ref) &&
      isPlainObject(authority.valueByCandidateId) &&
      hasAdmissibleBoundEvidence(authority as PreferenceAuthorityDeclaration);

    if (!admissibleAuthority) {
      // No authority, PROPOSAL_ONLY_EXPLORATORY, or missing bound-evidence.
      roundOutcome = "NO_ADMISSIBLE_PREFERENCE_EVIDENCE";
    } else {
      admissiblePreferenceAuthority = authority as PreferenceAuthorityDeclaration;
      const values = eligible.map((d) => ({
        candidateId: d.candidateId,
        value: admissiblePreferenceAuthority!.valueByCandidateId[d.candidateId],
      }));

      // Finding 2: coverage must include every eligible candidate, or the round yields NO_ADMISSIBLE_PREFERENCE_EVIDENCE.
      const missingCoverage = values.some((v) => typeof v.value !== "number" || !Number.isFinite(v.value));

      if (missingCoverage) {
        roundOutcome = "NO_ADMISSIBLE_PREFERENCE_EVIDENCE";
        admissiblePreferenceAuthority = null;
      } else {
        const maxValue = Math.max(...values.map((v) => v.value));
        const winners = values.filter((v) => v.value === maxValue);
        if (winners.length > 1) {
          roundOutcome = "TIE_NO_AUTOMATIC_PREFERENCE";
        } else {
          const soleWinnerCandidateId = winners[0].candidateId;

          // R2-3: GC-026 attestation-to-candidate binding, enforced here (not at authority-admissibility time) since it depends on WHICH candidate wins: recordContent must name the sole winner's taskClassId/candidateConfigHash (mirrors R1 producer-receipt binding).
          const soleWinnerEnvelope = eligible.find((d) => d.candidateId === soleWinnerCandidateId)!.envelope!;
          const attestationBindingFailure =
            admissiblePreferenceAuthority!.kind === "GC026_PROMOTED_PERFORMANCE_REFERENCE" &&
            admissiblePreferenceAuthority!.gc026Attestation !== undefined &&
            (admissiblePreferenceAuthority!.gc026Attestation.recordContent.taskClassId !== typedInput.taskClassId ||
              admissiblePreferenceAuthority!.gc026Attestation.recordContent.candidateConfigHash !==
                soleWinnerEnvelope.candidateConfigHash);

          if (attestationBindingFailure) {
            roundOutcome = "NO_ADMISSIBLE_PREFERENCE_EVIDENCE";
            admissiblePreferenceAuthority = null;
          } else {
            roundOutcome = "ACCEPTED_PREFERRED";
            acceptedCandidateId = soleWinnerCandidateId;
          }
        }
      }
    }
  }

  const finalDecisions: TaskClassCalibrationCandidateDecision[] = decisions.map((d) => {
    if (d.state === "eligible_nonpreferred" && d.candidateId === acceptedCandidateId) {
      return Object.freeze({
        candidateId: d.candidateId,
        candidateConfigHash: d.candidateConfigHash,
        state: "preferred" as const,
        reasons: Object.freeze([...d.reasons]),
      });
    }
    return Object.freeze({
      candidateId: d.candidateId,
      candidateConfigHash: d.candidateConfigHash,
      state: d.state,
      reasons: Object.freeze([...d.reasons]),
    });
  });

  // Provenance fingerprint (Finding 3): the real SHA-256 digest of the pipe-joined preimage.
  let provenanceFingerprint: string | null = null;
  let regressionBinding: RegressionBinding | null = null;
  // Records why no RegressionBinding is emitted when acceptedAt is missing/empty.
  let bindingWithheldReason: string | null = null;

  if (roundOutcome === "ACCEPTED_PREFERRED" && acceptedCandidateId !== null && admissiblePreferenceAuthority !== null) {
    const acceptedWorking = eligible.find((d) => d.candidateId === acceptedCandidateId)!;
    const acceptedEnv = acceptedWorking.envelope!;
    const canonicalVersion = isNonEmptyString(typedInput.canonicalVersion)
      ? typedInput.canonicalVersion
      : DEFAULT_CANONICAL_VERSION;

    const orderedEvidenceEnvelopeHashes = Object.freeze(
      [...acceptedEnv.traceContentHashes, acceptedEnv.g3ResultHash, acceptedEnv.fixtureContentHash].slice().sort(),
    );

    const authority = admissiblePreferenceAuthority;
    const promotionEvidenceRefOrRubricHash =
      authority.kind === "GC026_PROMOTED_PERFORMANCE_REFERENCE"
        ? (authority.promotionRecordRef as string)
        : (authority.rubricVersionHash as string);

    provenanceFingerprint = sha256Hex(
      canonicalVersion,
      acceptedEnv.comparabilityFingerprint,
      acceptedCandidateId,
      acceptedEnv.candidateConfigHash,
      orderedEvidenceEnvelopeHashes.join(","),
      authority.kind,
      promotionEvidenceRefOrRubricHash,
    );

    // Never emit CURRENT with an empty boundAt: withhold the binding instead of relying on a downstream checker.
    if (!isNonEmptyString(typedInput.acceptedAt)) {
      bindingWithheldReason =
        "acceptedAt is missing or empty at preferred-outcome time; a RegressionBinding is never emitted CURRENT with an empty boundAt, so no RegressionBinding is produced for this round";
    } else {
      regressionBinding = Object.freeze({
        schemaVersion: REGRESSION_BINDING_SCHEMA_VERSION,
        taskClassId: typedInput.taskClassId,
        acceptedCandidateId,
        candidateConfigHash: acceptedEnv.candidateConfigHash,
        comparabilityFingerprint: acceptedEnv.comparabilityFingerprint,
        provenanceFingerprint,
        orderedEvidenceEnvelopeHashes,
        preferenceAuthorityRef: authority.ref,
        boundAt: typedInput.acceptedAt,
        invalidationStatus: "CURRENT" as const,
        requiredRegradeTriggerSet: Object.freeze([...ALL_INVALIDATION_TRIGGERS]),
      });
    }
  }

  const assessment: OperatingPointAssessment = Object.freeze({
    schemaVersion: ASSESSMENT_SCHEMA_VERSION,
    taskClassId: typedInput.taskClassId,
    comparabilityFingerprint: referenceFingerprint ?? "",
    candidateDecisions: Object.freeze(finalDecisions),
    exclusions: Object.freeze(
      (bindingWithheldReason !== null
        ? [...exclusions, { candidateId: acceptedCandidateId ?? "", reason: bindingWithheldReason }]
        : exclusions
      ).map((e) => Object.freeze({ ...e })),
    ),
    acceptedCandidateId,
    preferenceAuthority: admissiblePreferenceAuthority,
    provenanceFingerprint,
    roundOutcome,
    acceptedAt: roundOutcome === "ACCEPTED_PREFERRED" && isNonEmptyString(typedInput.acceptedAt) ? typedInput.acceptedAt : null,
    claimBoundary: CLAIM_BOUNDARY,
  });

  return Object.freeze({ kind: "ASSESSED" as const, assessment, regressionBinding });
}

// Evaluates whether a previously bound RegressionBinding must be treated as STALE given currently-observed invalidation-relevant facts. Pure, total, never throws, never mutates `binding`. Never performs an automatic rollback - the caller alone requires a fresh assessment before reliance.
export function evaluateRegressionBindingInvalidation(
  binding: unknown, observedFacts: unknown,
): { readonly invalidationStatus: "CURRENT" | "STALE"; readonly triggeredBy: readonly InvalidationTrigger[] } {
  if (!isPlainObject(binding) || !isPlainObject(observedFacts)) {
    // Malformed input fails closed to STALE: an invalidation check that cannot be performed must never silently report CURRENT.
    return Object.freeze({
      invalidationStatus: "STALE" as const,
      triggeredBy: Object.freeze(["candidate_config_or_bound_trace_result_or_producer_receipt_changes" as const]),
    });
  }

  const triggered: InvalidationTrigger[] = [];

  if (observedFacts.fixtureSetContentHashChanged === true) triggered.push("fixture_set_content_hash_changes_for_bound_task_class");
  if (observedFacts.candidateConfigOrTraceOrReceiptChanged === true) triggered.push("candidate_config_or_bound_trace_result_or_producer_receipt_changes");
  if (observedFacts.partitionRubricEnvironmentPolicyOrPreferencePolicyChanged === true) triggered.push("partition_rubric_environment_policy_acceptance_or_preference_policy_changes");
  if (observedFacts.providerLaneReadinessDowngradedBelowMinimum === true) triggered.push("accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum");
  if (observedFacts.gc026PromotionChangedOrWithdrawn === true) triggered.push("gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence");
  if (observedFacts.budgetCeilingLoweredBelowConsumption === true) triggered.push("accepted_candidate_budget_ceiling_lowered_below_recorded_consumption");

  return Object.freeze({
    invalidationStatus: triggered.length > 0 ? ("STALE" as const) : ("CURRENT" as const),
    triggeredBy: Object.freeze(triggered),
  });
}
