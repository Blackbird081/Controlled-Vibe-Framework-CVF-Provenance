// CVF ACEL G1-T2 - Task-Class Calibration Owner Contract adversarial test suite. Every test uses synthetic, in-memory fixtures only; no network, provider, credential, or benchmark execution occurs anywhere in this file. Covers every negativeCases row in docs/audits/CVF_ACEL_G1_T1_EMPIRICAL_CALIBRATION_OWNER_COMPOSITION_DESIGN_MANIFEST_2026-09-16.json plus the additional required tests named in the paired work order. Full negative-case-to-fix matrix (both repair passes): docs/audits/CVF_ACEL_G1_T2_TASK_CLASS_CALIBRATION_OWNER_IMPLEMENTATION_2026-09-17.md
// R1 repair pass (2026-09-17): fixtures supply a structured producerReceipt plus real G3 fixture/trace objects (g3Fixture/g3Traces), since the module under test now actually invokes G3's gradeBehavioralEvaluation/admitFixtureSet.
// R2 repair pass (2026-09-17): (a) baseCandidate() declares comparabilityFingerprint's remaining constituent fields and derives candidateConfigHash/comparabilityFingerprint genuinely from those fields instead of arbitrary HASH_A/HASH_B literals, since the module now independently recomputes and cross-checks both. (b) Every round needing at least one eligible_nonpreferred/preferred candidate includes a companion NEGATIVE G3 fixture (withNegativeCompanion) so the round's pooled g3Fixture set is genuinely POSITIVE+NEGATIVE admitted, per the R2-1 fix making round-level admission a genuine eligibility gate.

import { createHash } from "node:crypto";
import { describe, expect, it } from "vitest";
import {
  evaluateTaskClassCalibrationRound,
  evaluateRegressionBindingInvalidation,
  composeComparabilityFingerprintPreimage,
  type TaskClassCalibrationRoundInput,
  type TaskClassCalibrationGc026Attestation,
  type TaskClassCalibrationRoundOutcome,
} from "../src/mao/task.class.calibration.owner.contract";

function sha256Hex(...parts: string[]): string {
  return createHash("sha256").update(parts.join("|")).digest("hex");
}

// Asserts (and type-narrows) that a round outcome is ASSESSED, replacing the repeated 2-line `expect(...).toBe("ASSESSED"); if (...) throw ...` boilerplate at every call site with one line, with identical assertion behavior (a non-ASSESSED outcome still fails the test with a clear message).
function assertAssessed(
  outcome: TaskClassCalibrationRoundOutcome,
): asserts outcome is Extract<TaskClassCalibrationRoundOutcome, { kind: "ASSESSED" }> {
  expect(outcome.kind).toBe("ASSESSED");
  if (outcome.kind !== "ASSESSED") throw new Error("unreachable");
}

const HASH_A = "a".repeat(64);
const HASH_B = "b".repeat(64);
const HASH_C = "c".repeat(64);
const HASH_1 = "1".repeat(64);
const HASH_2 = "2".repeat(64);
const HASH_3 = "3".repeat(64);

// Real, valid G3 fixture/trace pair builders: a POSITIVE, DETERMINISTIC, baselineRole=NONE fixture with one allowed transition and one required event, grading to PASS_WITH_EVIDENCE with a matching-transition trace. transitionKey mirrors the private helper in assf.behavioral.evaluation.contract.ts.
function transitionKey(event: Record<"from" | "action" | "to", string>): string {
  const encode = (segment: string): string => `${segment.length}:${segment}`;
  return `${encode(event.from)}|${encode(event.action)}|${encode(event.to)}`;
}

const ALLOWED_TRANSITION = { from: "start", action: "run", to: "end" };
const REQUIRED_EVENT_KEY = transitionKey(ALLOWED_TRANSITION);

function makeValidG3Fixture(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    fixtureId: "fixture-1",
    fixtureClass: "POSITIVE",
    repeatPolicy: "DETERMINISTIC",
    baselineRole: "NONE",
    canonicalInputBytes: "synthetic-input-bytes",
    sourceContentHash: HASH_C,
    fixtureContentHash: HASH_C,
    allowedTransitions: [ALLOWED_TRANSITION],
    requiredEvents: [REQUIRED_EVENT_KEY],
    requiredOutputObservations: [],
    outcomeAssertions: [],
    evaluationClockIso: "2026-09-17T00:00:00Z",
    ...overrides,
  };
}

// R2-1: a NEGATIVE-class companion fixture, distinct fixtureId/content from the default POSITIVE fixture above, used purely to make a round's pooled g3Fixture set genuinely POSITIVE+NEGATIVE G3-admitted. Its own trace deliberately uses an undeclared transition, so the companion candidate that presents it grades to UNDECLARED_TOOL_USE (ineligible) and can never itself become eligible_nonpreferred/preferred/contend for a tie.
function makeNegativeCompanionG3Fixture(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    fixtureId: "fixture-negative-companion",
    fixtureClass: "NEGATIVE",
    repeatPolicy: "DETERMINISTIC",
    baselineRole: "NONE",
    canonicalInputBytes: "synthetic-negative-input-bytes",
    sourceContentHash: HASH_2,
    fixtureContentHash: HASH_2,
    allowedTransitions: [ALLOWED_TRANSITION],
    requiredEvents: [REQUIRED_EVENT_KEY],
    requiredOutputObservations: [],
    outcomeAssertions: [],
    evaluationClockIso: "2026-09-17T00:00:00Z",
    ...overrides,
  };
}

function makeValidG3Trace(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    traceId: "trace-1",
    fixtureId: "fixture-1",
    captureMode: "OFFLINE_SYNTHETIC",
    sourceContentHash: HASH_C,
    provenanceSourceCommit: null,
    provenanceExpiry: null,
    events: [ALLOWED_TRANSITION],
    outputObservations: [],
    outcomeValues: {},
    selfReportedPass: null,
    ...overrides,
  };
}

// Computes the g3ResultHash a caller must declare for a given (real) G3 evaluation outcome, using the exact same formula the module under test recomputes internally: sha256Hex(result, fixtureId, sourceContentHash, repeatsObserved, repeatsRequired).
function computeG3ResultHash(params: {
  result: string;
  fixtureId: string;
  sourceContentHash: string;
  repeatsObserved: number;
  repeatsRequired: number;
}): string {
  return sha256Hex(
    params.result,
    params.fixtureId,
    params.sourceContentHash,
    String(params.repeatsObserved),
    String(params.repeatsRequired),
  );
}

// A single-repeat DETERMINISTIC PASS_WITH_EVIDENCE g3ResultHash for the default fixture/trace pair below (fixtureId=fixture-1, sourceContentHash=HASH_C, repeatsObserved=1, repeatsRequired=1).
const DEFAULT_PASS_G3_RESULT_HASH = computeG3ResultHash({ result: "PASS_WITH_EVIDENCE", fixtureId: "fixture-1", sourceContentHash: HASH_C, repeatsObserved: 1, repeatsRequired: 1 });

// Standard "receipt genuinely matches the presenting candidate" shape, for every candidate override needing its own non-default identity (cand-2, cand-heldout, etc.). `candidateConfigHashSeed` is the same literal (e.g. HASH_1) also passed to `baseCandidate({ candidateConfigHash: <seed> })`; applying the identical derivation here keeps the receipt's declared hash matching the presenting candidate's actually-declared (derived) hash.
function receiptFor(
  candidateId: string,
  candidateConfigHashSeed: string,
  traceIds: string[] = ["trace-1"],
): Record<string, unknown> {
  const candidateConfigHash = computeCandidateConfigHashForTest({
    effort_reasoning_level_profile: "high",
    __testIdentitySeed: candidateConfigHashSeed,
  });
  return { receiptRef: `receipt-${candidateId}`, candidateId, candidateConfigHash, traceIds };
}

// Counterpart to receiptFor: builds a receipt from an ALREADY-RESOLVED (not seed) candidateConfigHash, for baseCandidate's own default receipt, which must not derive its hash a second time (double-hashing would mismatch).
function receiptForResolvedHash(
  candidateId: string,
  resolvedCandidateConfigHash: string,
  traceIds: string[] = ["trace-1"],
): Record<string, unknown> {
  return { receiptRef: `receipt-${candidateId}`, candidateId, candidateConfigHash: resolvedCandidateConfigHash, traceIds };
}

// R2-2: canonical stable-sorted-keys JSON stringify, mirroring the module's own (private) canonicalStringify, so tests can independently recompute the same hashes the module will (kept separate since tests must not import a private helper, but must stay formula-identical).
function canonicalSortKeysForTest(value: unknown): unknown {
  if (Array.isArray(value)) return value.map((item) => canonicalSortKeysForTest(item));
  if (value !== null && typeof value === "object") {
    const record = value as Record<string, unknown>;
    const sorted: Record<string, unknown> = {};
    for (const key of Object.keys(record).sort()) sorted[key] = canonicalSortKeysForTest(record[key]);
    return sorted;
  }
  return value;
}
function canonicalStringifyForTest(value: unknown): string {
  return JSON.stringify(canonicalSortKeysForTest(value)) ?? "null";
}

const CANDIDATE_CONFIG_HASH_CANONICAL_VERSION = "cvf.taskClassCalibrationOwner.candidateConfigHash.v1";
const GC026_RECORD_CONTENT_HASH_CANONICAL_VERSION = "cvf.taskClassCalibrationOwner.gc026RecordContent.v1";

function computeCandidateConfigHashForTest(declaredDimensions: Record<string, unknown>): string {
  return sha256Hex(CANDIDATE_CONFIG_HASH_CANONICAL_VERSION, canonicalStringifyForTest(declaredDimensions));
}

function computeGc026RecordContentHashForTest(recordContent: Record<string, unknown>): string {
  return sha256Hex(GC026_RECORD_CONTENT_HASH_CANONICAL_VERSION, canonicalStringifyForTest(recordContent));
}

// Mirrors composeComparabilityFingerprintPreimage's exact ordered-field join, so tests can independently recompute comparabilityFingerprint.
function computeComparabilityFingerprintForTest(fields: {
  canonicalVersion: string;
  taskClassId: string;
  fixtureSetContentHash: string;
  environmentDescriptorHash: string;
  policyId: string;
  acceptanceCriteriaVersion: string;
  gradingRubricVersionHash: string;
  heldoutPartitionHash: string;
}): string {
  return sha256Hex([fields.canonicalVersion, fields.taskClassId, fields.fixtureSetContentHash, fields.environmentDescriptorHash, fields.policyId, fields.acceptanceCriteriaVersion, fields.gradingRubricVersionHash, fields.heldoutPartitionHash].join("|"));
}

// Default constituent-field values shared by every base candidate unless overridden; kept as one object so derivation and declaration never drift.
const DEFAULT_COMPARABILITY_FIELDS = {
  canonicalVersion: "cvf.taskClassCalibrationOwner.v1",
  taskClassId: "task-class-1",
  fixtureSetContentHash: HASH_3,
  environmentDescriptorHash: HASH_1,
  policyId: "policy-1",
  acceptanceCriteriaVersion: "ac-v1",
  gradingRubricVersionHash: HASH_2,
  heldoutPartitionHash: HASH_3,
};

// R2-2: builds one candidate envelope whose candidateConfigHash and comparabilityFingerprint are genuinely derived from declaredDimensions/constituent fields, matching the module's own recomputation, instead of arbitrary literals.
// Identity convention: an explicit `candidateConfigHash`/`comparabilityFingerprint` literal (e.g. HASH_A) passed by a call site is a DISTINGUISHING IDENTITY seed, not a value trusted verbatim -- it folds into declaredDimensions/constituent fields, and the real recomputed hash of that seeded input is what's actually declared (same literal => same identity; different literal => different identity, exactly as before). A test needing a deliberately WRONG hash overrides it again via `hashOverrides`.
function baseCandidate(
  overrides: Record<string, unknown> = {},
  hashOverrides: Record<string, unknown> = {},
): Record<string, unknown> {
  const candidateConfigHashSeed = overrides.candidateConfigHash as string | undefined;
  const declaredDimensions = (overrides.declaredDimensions as Record<string, unknown>) ?? {
    effort_reasoning_level_profile: "high",
    ...(candidateConfigHashSeed ? { __testIdentitySeed: candidateConfigHashSeed } : {}),
  };

  const comparabilityFingerprintSeed = overrides.comparabilityFingerprint as string | undefined;
  const comparabilityFields = {
    canonicalVersion: (overrides.canonicalVersion as string) ?? DEFAULT_COMPARABILITY_FIELDS.canonicalVersion,
    taskClassId: (overrides.taskClassId as string) ?? DEFAULT_COMPARABILITY_FIELDS.taskClassId,
    fixtureSetContentHash:
      (overrides.fixtureSetContentHash as string) ?? DEFAULT_COMPARABILITY_FIELDS.fixtureSetContentHash,
    environmentDescriptorHash:
      (overrides.environmentDescriptorHash as string) ?? DEFAULT_COMPARABILITY_FIELDS.environmentDescriptorHash,
    policyId: (overrides.policyId as string) ?? DEFAULT_COMPARABILITY_FIELDS.policyId,
    acceptanceCriteriaVersion:
      (overrides.acceptanceCriteriaVersion as string) ?? DEFAULT_COMPARABILITY_FIELDS.acceptanceCriteriaVersion,
    gradingRubricVersionHash:
      (overrides.gradingRubricVersionHash as string) ?? DEFAULT_COMPARABILITY_FIELDS.gradingRubricVersionHash,
    // A comparabilityFingerprint literal seed folds into
    // heldoutPartitionHash (a real constituent field) only when it is
    // itself a canonical-hash-shaped value; otherwise the fingerprint
    // derives from the plain defaults (a non-canonical literal there is
    // exercised directly via hashOverrides instead).
    heldoutPartitionHash:
      (overrides.heldoutPartitionHash as string) ??
      (comparabilityFingerprintSeed && /^[0-9a-f]{64}$/.test(comparabilityFingerprintSeed)
        ? comparabilityFingerprintSeed
        : DEFAULT_COMPARABILITY_FIELDS.heldoutPartitionHash),
  };
  const candidateId = (overrides.candidateId as string) ?? "cand-1";
  const derivedCandidateConfigHash = computeCandidateConfigHashForTest(declaredDimensions);
  const derivedComparabilityFingerprint = computeComparabilityFingerprintForTest(comparabilityFields);

  // Every key baseCandidate itself derives/composes above must never be
  // re-clobbered back to a caller's raw literal by the generic trailing
  // override spread below (that would undo the derivation and break the
  // module's new recomputation checks); each is excluded from `rest` and
  // reapplied deliberately (derived value, or an explicit hashOverrides
  // value for the tests that must supply a genuinely wrong hash).
  const {
    candidateConfigHash: _omitCandidateConfigHash,
    comparabilityFingerprint: _omitComparabilityFingerprint,
    canonicalVersion: _omitCanonicalVersion,
    taskClassId: _omitTaskClassId,
    fixtureSetContentHash: _omitFixtureSetContentHash,
    environmentDescriptorHash: _omitEnvironmentDescriptorHash,
    policyId: _omitPolicyId,
    acceptanceCriteriaVersion: _omitAcceptanceCriteriaVersion,
    gradingRubricVersionHash: _omitGradingRubricVersionHash,
    heldoutPartitionHash: _omitHeldoutPartitionHash,
    declaredDimensions: _omitDeclaredDimensions,
    candidateId: _omitCandidateId,
    ...rest
  } = overrides;

  return {
    ...comparabilityFields,
    candidateId,
    candidateConfigHash: derivedCandidateConfigHash,
    comparabilityFingerprint: derivedComparabilityFingerprint,
    fixtureId: "fixture-1",
    fixtureContentHash: HASH_C,
    traceIds: ["trace-1"],
    traceContentHashes: [HASH_C],
    traceCaptureModes: ["OFFLINE_SYNTHETIC"],
    g3ResultHash: DEFAULT_PASS_G3_RESULT_HASH,
    producerReceiptRef: "receipt-1",
    producerReceipt: receiptForResolvedHash(candidateId, derivedCandidateConfigHash),
    g3Fixture: makeValidG3Fixture(),
    g3Traces: [makeValidG3Trace()],
    partition: "HELD_OUT",
    g3Result: "PASS_WITH_EVIDENCE",
    repeatPolicy: "DETERMINISTIC",
    repeatsObserved: 1,
    repeatsRequired: 1,
    heldoutAdmitted: true,
    declaredDimensions,
    budgetCeiling: 100,
    budgetConsumed: 10,
    providerLaneStatus: "CERTIFIED",
    contaminationKeys: ["fixture-1"],
    ...rest,
    ...hashOverrides,
  };
}

// R2-1: a companion candidate contributing only a NEGATIVE-class g3Fixture to the round's pooled fixture set, so admitFixtureSet's round-level admission genuinely sees POSITIVE+NEGATIVE. Its trace deliberately uses an undeclared transition, so it grades to UNDECLARED_TOOL_USE (ineligible) and can never itself win preference or create a tie.
function negativeCompanionCandidate(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  const candidateId = (overrides.candidateId as string) ?? "cand-negative-companion";
  const declaredDimensions = { effort_reasoning_level_profile: "companion" };
  const derivedCandidateConfigHash = computeCandidateConfigHashForTest(declaredDimensions);
  return baseCandidate({
    candidateId,
    declaredDimensions,
    fixtureId: "fixture-negative-companion",
    fixtureContentHash: HASH_2,
    traceContentHashes: [HASH_2],
    g3Fixture: makeNegativeCompanionG3Fixture(),
    g3Traces: [makeValidG3Trace({ fixtureId: "fixture-negative-companion", sourceContentHash: HASH_2, events: [{ from: "start", action: "unlisted-action", to: "end" }] })],
    g3Result: "UNDECLARED_TOOL_USE",
    g3ResultHash: computeG3ResultHash({ result: "UNDECLARED_TOOL_USE", fixtureId: "fixture-negative-companion", sourceContentHash: HASH_2, repeatsObserved: 1, repeatsRequired: 1 }),
    producerReceipt: receiptForResolvedHash(candidateId, derivedCandidateConfigHash),
    ...overrides,
  });
}

// R2-1 convenience: appends a negativeCompanionCandidate() to a candidate list, so the round's pooled g3Fixture set is genuinely POSITIVE+NEGATIVE admitted without every describe block re-deriving this by hand.
function withNegativeCompanion(candidates: Record<string, unknown>[]): Record<string, unknown>[] {
  return [...candidates, negativeCompanionCandidate()];
}

// Convenience for the extremely common "second candidate, cand-2/HASH_1, with a correctly bound receipt" shape used across two-candidate tests; collapses the recurring 5-line baseCandidate({candidateId, candidateConfigHash, producerReceipt, ...}) call into passing just the distinguishing overrides.
function secondCandidate(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return baseCandidate({
    candidateId: "cand-2",
    candidateConfigHash: HASH_1,
    producerReceipt: receiptFor("cand-2", HASH_1),
    ...overrides,
  });
}

// R2-3: builds a structurally valid, internally-consistent gc026Attestation bound to the given taskClassId/candidateConfigHash (the candidate the authority is meant to prefer).
function gc026AttestationFor(taskClassId: string, candidateConfigHash: string): TaskClassCalibrationGc026Attestation {
  const recordContent = {
    taskClassId,
    candidateConfigHash,
    promotionRecordRef: "promotion-record-1",
    promotedAt: "2026-09-01T00:00:00Z",
  };
  return {
    registrySnapshotHash: HASH_1,
    recordContentHash: computeGc026RecordContentHashForTest(recordContent),
    recordContent,
  };
}

// Matches the DEFAULT baseCandidate()'s derived candidateConfigHash exactly (declaredDimensions = { effort_reasoning_level_profile: "high", __testIdentitySeed: HASH_A }, per baseCandidate's own seeding convention when a caller passes `candidateConfigHash: HASH_A`).
const DEFAULT_CAND_1_CANDIDATE_CONFIG_HASH = computeCandidateConfigHashForTest({
  effort_reasoning_level_profile: "high",
  __testIdentitySeed: HASH_A,
});

const GC026_AUTHORITY = (
  valueByCandidateId: Record<string, number>,
  boundTo: { taskClassId: string; candidateConfigHash: string } = {
    taskClassId: "task-class-1",
    candidateConfigHash: DEFAULT_CAND_1_CANDIDATE_CONFIG_HASH,
  },
) => ({
  kind: "GC026_PROMOTED_PERFORMANCE_REFERENCE" as const,
  ref: "gc026-ref-1",
  promotionRecordRef: "promotion-record-1",
  promotedAt: "2026-09-01T00:00:00Z",
  gc026Attestation: gc026AttestationFor(boundTo.taskClassId, boundTo.candidateConfigHash),
  valueByCandidateId,
});

const RUBRIC_AUTHORITY = (valueByCandidateId: Record<string, number>) => ({
  kind: "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC" as const,
  ref: "rubric-v1",
  rubricVersionHash: HASH_1,
  valueByCandidateId,
});

// R2-1: roundInput auto-appends a negativeCompanionCandidate() by default, since most tests are unrelated to round-level fixture-set admission and need it genuinely POSITIVE+NEGATIVE admitted. Explicit opt-out (`skipNegativeCompanion: true`) is used only by the small set of tests that specifically exercise the R2-1 admission gate itself.
function roundInput(
  candidates: Record<string, unknown>[],
  overrides: Partial<TaskClassCalibrationRoundInput> & { skipNegativeCompanion?: boolean } = {},
) {
  const { skipNegativeCompanion, ...roundOverrides } = overrides;
  // An empty candidates array must stay genuinely empty (BLOCKED_EMPTY_CANDIDATE_SET coverage): the companion is never appended to an already-empty round.
  const effectiveCandidates =
    skipNegativeCompanion || candidates.length === 0 ? candidates : withNegativeCompanion(candidates);
  return {
    taskClassId: "task-class-1",
    candidates: effectiveCandidates,
    ...roundOverrides,
  } as unknown;
}

// Runs a round (optionally with round overrides, e.g. a preferenceAuthority or acceptedAt) and returns the full outcome, collapsing the extremely common "evaluate -> assertAssessed" 2-line shape into one call.
function assessedOutcome(
  candidates: Record<string, unknown>[],
  overrides: Partial<TaskClassCalibrationRoundInput> & { skipNegativeCompanion?: boolean } = {},
) {
  const outcome = evaluateTaskClassCalibrationRound(roundInput(candidates, overrides));
  assertAssessed(outcome);
  return outcome;
}
// As assessedOutcome, but returns the sole candidateDecisions[0] decision (state + reasons) directly, for the equally common single-candidate case.
function singleCandidateDecision(
  candidates: Record<string, unknown>[],
  overrides: Partial<TaskClassCalibrationRoundInput> & { skipNegativeCompanion?: boolean } = {},
) {
  return assessedOutcome(candidates, overrides).assessment.candidateDecisions[0];
}
function singleCandidateState(
  candidates: Record<string, unknown>[],
  overrides: Partial<TaskClassCalibrationRoundInput> & { skipNegativeCompanion?: boolean } = {},
): string {
  return singleCandidateDecision(candidates, overrides).state;
}
// Finds one candidate's decision by id in an already-ASSESSED outcome, collapsing the common `outcome.assessment.candidateDecisions.find((d) => d.candidateId === X)` lookup into one call.
function decisionOf(outcome: ReturnType<typeof assessedOutcome>, candidateId: string) {
  return outcome.assessment.candidateDecisions.find((d) => d.candidateId === candidateId);
}
// Runs a two-candidate round (c1 plus a secondCandidate() with the given overrides) and returns cand-2's decision state directly, for the common "does varying this dimension on a second candidate make it incomparable" shape used throughout the comparability-check describe blocks.
function secondCandidateState(
  c1: Record<string, unknown>,
  c2Overrides: Record<string, unknown> = {},
  roundOverrides: Partial<TaskClassCalibrationRoundInput> & { skipNegativeCompanion?: boolean } = {},
): string | undefined {
  const c2 = secondCandidate(c2Overrides);
  const outcome = assessedOutcome([c1, c2], roundOverrides);
  return decisionOf(outcome, "cand-2")?.state;
}
const ACCEPTED_AT = "2026-09-17T00:00:00Z";
// Runs a round for the default cand-1 candidate under the standard "GC026 authority preferring cand-1, acceptedAt supplied" shape used by most ACCEPTED_PREFERRED / RegressionBinding tests, collapsing the extremely common candidate + authority + acceptedAt boilerplate.
function acceptedOutcome(
  candidateOverrides: Record<string, unknown> = {},
  roundOverrides: Partial<TaskClassCalibrationRoundInput> = {},
) {
  const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, ...candidateOverrides });
  return assessedOutcome([c1], {
    preferenceAuthority: GC026_AUTHORITY({ "cand-1": 42 }),
    acceptedAt: ACCEPTED_AT,
    ...roundOverrides,
  });
}

describe("evaluateTaskClassCalibrationRound - empty_candidate_set", () => {
  it("blocks an empty candidate array with BLOCKED_EMPTY_CANDIDATE_SET and no assessment", () => {
    const outcome = evaluateTaskClassCalibrationRound(roundInput([]));
    expect(outcome.kind).toBe("BLOCKED_EMPTY_CANDIDATE_SET");
  });
  it("blocks malformed top-level input (not an object) the same way", () => {
    const outcome = evaluateTaskClassCalibrationRound(null);
    expect(outcome.kind).toBe("BLOCKED_EMPTY_CANDIDATE_SET");
  });
  it("blocks input missing taskClassId", () => {
    const outcome = evaluateTaskClassCalibrationRound({ candidates: [baseCandidate()] });
    expect(outcome.kind).toBe("BLOCKED_EMPTY_CANDIDATE_SET");
  });
});

describe("evaluateTaskClassCalibrationRound - duplicate_candidate_ids", () => {
  // Merged: both use the identical "one candidateId, two hashes" fixture; the second assertion (no silent overwrite/double-count) is folded in rather than repeating the fixture in a separate test.
  it("blocks the round when one candidateId has two distinct candidateConfigHash values, with no assessment produced", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_1 });
    const outcome = evaluateTaskClassCalibrationRound(roundInput([c1, c2]));
    expect(outcome.kind).toBe("BLOCKED_DUPLICATE_CANDIDATE_IDENTITY");
    expect((outcome as { assessment?: unknown }).assessment).toBeUndefined();
  });

  it("blocks the round when one candidateConfigHash is claimed by two distinct candidateIds", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = baseCandidate({ candidateId: "cand-2", candidateConfigHash: HASH_A });
    const outcome = evaluateTaskClassCalibrationRound(roundInput([c1, c2]));
    expect(outcome.kind).toBe("BLOCKED_DUPLICATE_CANDIDATE_IDENTITY");
  });
});

describe("evaluateTaskClassCalibrationRound - mixed_task_case_sets", () => {
  it("marks a candidate under a different fixtureSetContentHash incomparable and proceeds over the comparable subset", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = secondCandidate({ comparabilityFingerprint: HASH_2, fixtureSetContentHash: HASH_3 });
    const outcome = assessedOutcome([c1, c2]);
    expect(decisionOf(outcome, "cand-2")?.state).toBe("incomparable");
    expect(decisionOf(outcome, "cand-1")?.state).not.toBe("incomparable");
    expect(outcome.assessment.exclusions.find((e) => e.candidateId === "cand-2")).toBeDefined();
  });
});

describe("evaluateTaskClassCalibrationRound - unequal_budgets_or_policies", () => {
  it("marks a candidate exceeding its declared budget ceiling as ineligible", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, budgetCeiling: 5, budgetConsumed: 10 });
    expect(singleCandidateState([c1])).toBe("ineligible");
  });

  it("marks a candidate with a different policyId under the same fingerprint incomparable, never merged", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, policyId: "policy-1" });
    expect(secondCandidateState(c1, { policyId: "policy-2" })).toBe("incomparable");
  });
});

describe("evaluateTaskClassCalibrationRound - missing_heldout_evidence_or_candidate_binding", () => {
  it("marks a SEARCH-partition-only candidate insufficient_evidence (no held-out admission)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, partition: "SEARCH", heldoutAdmitted: false });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("marks a candidate with ambiguous trace binding (mismatched array lengths) insufficient_evidence even though a G3 result string is present", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, traceIds: ["trace-1", "trace-2"], traceContentHashes: [HASH_C], traceCaptureModes: ["OFFLINE_SYNTHETIC"] });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("marks a structurally malformed envelope (missing producerReceiptRef) insufficient_evidence; G3 result alone never attests identity", () => {
    const malformed = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    delete (malformed as Record<string, unknown>).producerReceiptRef;
    const outcome = assessedOutcome([malformed]);
    expect(outcome.assessment.candidateDecisions[0].state).toBe("insufficient_evidence");
  });

  it("marks an envelope with a missing producerReceipt structure insufficient_evidence (R1: a bare ref alone is not verifiable)", () => {
    const malformed = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    delete (malformed as Record<string, unknown>).producerReceipt;
    const outcome = assessedOutcome([malformed]);
    expect(outcome.assessment.candidateDecisions[0].state).toBe("insufficient_evidence");
  });
});

describe("evaluateTaskClassCalibrationRound - R1 Finding 1: candidate misattribution despite a passing G3 result", () => {
  it("rejects a candidate whose g3ResultHash/traceContentHashes are present but producerReceiptRef is empty, even though g3Result is PASS_WITH_EVIDENCE", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, producerReceiptRef: "" });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("rejects a candidate whose producerReceipt is real, structurally valid, and names a PASS_WITH_EVIDENCE G3 result, but is bound to a DIFFERENT candidateId than the one presenting it (strict binding, not just length-check)", () => {
    // misattributed: names a different candidate
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, producerReceipt: { receiptRef: "receipt-1", candidateId: "cand-OTHER", candidateConfigHash: HASH_A, traceIds: ["trace-1"] } });
    const decision = singleCandidateDecision([c1]);
    // Must never sneak through as eligible/preferred despite a real, passing G3 evaluation.
    expect(decision.state).toBe("insufficient_evidence");
    expect(decision.reasons.some((r) => r.includes("producer-to-candidate binding mismatch"))).toBe(true);
  });

  it("rejects a candidate whose producerReceipt is bound to a DIFFERENT candidateConfigHash than the one presenting it", () => {
    // misattributed: names a different config hash
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, producerReceipt: { receiptRef: "receipt-1", candidateId: "cand-1", candidateConfigHash: HASH_1, traceIds: ["trace-1"] } });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("rejects a candidate whose producerReceipt names a DIFFERENT traceIds set than the envelope's own traceIds", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, producerReceipt: { receiptRef: "receipt-1", candidateId: "cand-1", candidateConfigHash: HASH_A, traceIds: ["trace-DIFFERENT"] } });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("rejects a candidate whose declared g3ResultHash does not match the recomputed SHA-256 over the actual G3 evaluation (arbitrary well-formed-looking hash)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, g3ResultHash: HASH_2 }); // well-formed but not the real recomputed hash
    const decision = singleCandidateDecision([c1]);
    expect(decision.state).toBe("insufficient_evidence");
    expect(decision.reasons.some((r) => r.includes("could not be verified against actual supplied bytes"))).toBe(true);
  });

  it("rejects a candidate whose declared fixtureContentHash does not match the supplied g3Fixture.fixtureContentHash", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, fixtureContentHash: HASH_2 }); // does not match g3Fixture.fixtureContentHash (HASH_C)
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("rejects a candidate whose declared traceContentHashes do not structurally match the supplied g3Traces[].sourceContentHash values", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, traceContentHashes: [HASH_2] }); // does not match g3Traces[0].sourceContentHash (HASH_C)
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("rejects a candidate whose declared g3Result disagrees with the actual G3 evaluation outcome", () => {
    // g3Traces events use an undeclared transition, so the real G3 evaluation will actually be UNDECLARED_TOOL_USE, not PASS_WITH_EVIDENCE.
    const c1 = baseCandidate({
      candidateId: "cand-1",
      candidateConfigHash: HASH_A,
      g3Result: "PASS_WITH_EVIDENCE",
      g3Traces: [makeValidG3Trace({ events: [{ from: "start", action: "unlisted-action", to: "end" }] })],
      g3ResultHash: computeG3ResultHash({ result: "PASS_WITH_EVIDENCE", fixtureId: "fixture-1", sourceContentHash: HASH_C, repeatsObserved: 1, repeatsRequired: 1 }),
    });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("accepts a candidate whose producerReceipt and G3 invocation are genuinely, correctly bound to the presenting candidate (positive control for the binding checks above)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    expect(singleCandidateState([c1])).toBe("eligible_nonpreferred");
  });
});

describe("evaluateTaskClassCalibrationRound - reused_heldout_search_data", () => {
  // Merged: both share the "HELD_OUT candidate shares a contamination key with a SEARCH candidate" fixture shape; the second variant additionally sets an otherwise-passing G3 result to prove contamination is never bypassed even when the evidence would otherwise be PASS_WITH_EVIDENCE.
  it("marks held-out evidence insufficient_evidence with REUSED_HELDOUT_SEARCH_DATA when it shares a contamination key with SEARCH evidence, even when otherwise PASS_WITH_EVIDENCE", () => {
    const search = baseCandidate({ candidateId: "cand-search", candidateConfigHash: HASH_A, partition: "SEARCH", heldoutAdmitted: false, contaminationKeys: ["shared-key"] });
    const heldout = baseCandidate({
      candidateId: "cand-heldout",
      candidateConfigHash: HASH_1,
      partition: "HELD_OUT",
      heldoutAdmitted: true,
      g3Result: "PASS_WITH_EVIDENCE",
      repeatsObserved: 1,
      repeatsRequired: 1,
      contaminationKeys: ["shared-key"],
      producerReceipt: receiptFor("cand-heldout", HASH_1),
    });
    const decision = decisionOf(assessedOutcome([search, heldout]), "cand-heldout");
    expect(decision?.state).toBe("insufficient_evidence");
    expect(decision?.reasons.some((r) => r.includes("REUSED_HELDOUT_SEARCH_DATA"))).toBe(true);
    expect(decision?.state).not.toBe("preferred");
    expect(decision?.state).not.toBe("eligible_nonpreferred");
  });
});

describe("evaluateTaskClassCalibrationRound - stale_fingerprints", () => {
  it("marks a candidate under a stale (mismatched) comparabilityFingerprint incomparable with a named mismatch reason", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    // same fixture set, but different fingerprint (e.g. rubric version changed)
    const c2 = secondCandidate({ comparabilityFingerprint: HASH_2, fixtureSetContentHash: HASH_3 });
    const decision = decisionOf(assessedOutcome([c1, c2]), "cand-2");
    expect(decision?.state).toBe("incomparable");
    expect(decision?.reasons.length).toBeGreaterThan(0);
  });
});

describe("evaluateTaskClassCalibrationRound - incomplete_repeats", () => {
  it("marks STOCHASTIC evidence with repeatsObserved < repeatsRequired insufficient_evidence, never rounded up", () => {
    const c1 = baseCandidate({
      candidateId: "cand-1",
      candidateConfigHash: HASH_A,
      repeatPolicy: "STOCHASTIC",
      repeatsObserved: 2,
      repeatsRequired: 3,
      g3Result: "INSUFFICIENT_REPEAT_EVIDENCE",
      g3Traces: [makeValidG3Trace(), makeValidG3Trace({ traceId: "trace-2" })],
      traceIds: ["trace-1", "trace-2"],
      traceContentHashes: [HASH_C, HASH_C],
      traceCaptureModes: ["OFFLINE_SYNTHETIC", "OFFLINE_SYNTHETIC"],
      producerReceipt: receiptFor("cand-1", HASH_A, ["trace-1", "trace-2"]),
      g3ResultHash: computeG3ResultHash({ result: "INSUFFICIENT_REPEAT_EVIDENCE", fixtureId: "fixture-1", sourceContentHash: HASH_C, repeatsObserved: 2, repeatsRequired: 3 }),
    });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });
});

describe("evaluateTaskClassCalibrationRound - unknown_metrics_or_units", () => {
  it("records NO_ADMISSIBLE_PREFERENCE_EVIDENCE when no preference authority names the candidate's metric", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1], {
      preferenceAuthority: RUBRIC_AUTHORITY({}), // no value for cand-1: unknown metric excluded
    });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
  });
});

describe("evaluateTaskClassCalibrationRound - ties", () => {
  it("keeps all tied candidates eligible_nonpreferred and records TIE_NO_AUTOMATIC_PREFERENCE", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = secondCandidate();
    const outcome = assessedOutcome([c1, c2], {
      preferenceAuthority: GC026_AUTHORITY({ "cand-1": 10, "cand-2": 10 }),
    });
    expect(outcome.assessment.roundOutcome).toBe("TIE_NO_AUTOMATIC_PREFERENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
    for (const d of outcome.assessment.candidateDecisions) {
      if (d.candidateId === "cand-1" || d.candidateId === "cand-2") {
        expect(d.state).toBe("eligible_nonpreferred");
      }
    }
  });
});

describe("evaluateTaskClassCalibrationRound - no_eligible_candidate", () => {
  it("records NO_ELIGIBLE_CANDIDATE with no preferred assignment when every candidate fails eligibility, deterministically across repeated runs", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, budgetCeiling: 1, budgetConsumed: 100 });
    const outcome1 = evaluateTaskClassCalibrationRound(roundInput([c1]));
    const outcome2 = evaluateTaskClassCalibrationRound(roundInput([c1]));
    assertAssessed(outcome1);
    expect(outcome1.assessment.roundOutcome).toBe("NO_ELIGIBLE_CANDIDATE");
    expect(outcome1.assessment.acceptedCandidateId).toBeNull();
    // Disturbs no prior accepted operating point: this module carries no mutable prior-state store, so identical input reproduces identically.
    expect(outcome1).toEqual(outcome2);
  });
});

describe("evaluateTaskClassCalibrationRound - proposal_only_performance_advantage", () => {
  it("never assigns preferred from a PROPOSAL_ONLY_EXPLORATORY authority alone", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = secondCandidate();
    const outcome = assessedOutcome([c1, c2], {
      preferenceAuthority: { kind: "PROPOSAL_ONLY_EXPLORATORY", ref: "benchmark-report-hash", valueByCandidateId: { "cand-1": 50, "cand-2": 10 } },
    });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
    expect(outcome.regressionBinding).toBeNull();
  });

  it("never creates a RegressionBinding before separate GC-026 promotion even with a clear proposal-only advantage", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1], {
      preferenceAuthority: { kind: "PROPOSAL_ONLY_EXPLORATORY", ref: "benchmark-report-hash", valueByCandidateId: { "cand-1": 999 } },
    });
    expect(outcome.regressionBinding).toBeNull();
  });
});

describe("evaluateTaskClassCalibrationRound - happy path: complete positive DETERMINISTIC evidence", () => {
  it("assigns preferred and emits a RegressionBinding for a sole eligible candidate under an admissible GC-026 authority", () => {
    const outcome = acceptedOutcome();
    expect(outcome.assessment.roundOutcome).toBe("ACCEPTED_PREFERRED");
    expect(outcome.assessment.acceptedCandidateId).toBe("cand-1");
    expect(outcome.assessment.candidateDecisions[0].state).toBe("preferred");
    expect(outcome.assessment.provenanceFingerprint).not.toBeNull();
    expect(outcome.regressionBinding).not.toBeNull();
    expect(outcome.regressionBinding?.invalidationStatus).toBe("CURRENT");
    expect(outcome.regressionBinding?.acceptedCandidateId).toBe("cand-1");
  });
});

describe("evaluateTaskClassCalibrationRound - happy path: complete positive STOCHASTIC evidence", () => {
  it("assigns preferred for a STOCHASTIC candidate with exactly 3 consecutive passing repeats", () => {
    const traces = [makeValidG3Trace({ traceId: "t1" }), makeValidG3Trace({ traceId: "t2" }), makeValidG3Trace({ traceId: "t3" })];
    const c1 = baseCandidate({
      candidateId: "cand-1",
      candidateConfigHash: HASH_A,
      repeatPolicy: "STOCHASTIC",
      repeatsObserved: 3,
      repeatsRequired: 3,
      traceIds: ["t1", "t2", "t3"],
      traceContentHashes: [HASH_C, HASH_C, HASH_C],
      traceCaptureModes: ["OFFLINE_SYNTHETIC", "OFFLINE_SYNTHETIC", "OFFLINE_SYNTHETIC"],
      g3Fixture: makeValidG3Fixture({ repeatPolicy: "STOCHASTIC" }),
      g3Traces: traces,
      producerReceipt: receiptFor("cand-1", HASH_A, ["t1", "t2", "t3"]),
      g3ResultHash: computeG3ResultHash({ result: "PASS_WITH_EVIDENCE", fixtureId: "fixture-1", sourceContentHash: HASH_C, repeatsObserved: 3, repeatsRequired: 3 }),
    });
    const outcome = assessedOutcome([c1], {
      preferenceAuthority: RUBRIC_AUTHORITY({ "cand-1": 7 }),
    });
    expect(outcome.assessment.roundOutcome).toBe("ACCEPTED_PREFERRED");
    expect(outcome.assessment.candidateDecisions[0].state).toBe("preferred");
  });
});

describe("evaluateTaskClassCalibrationRound - exclusive-state precedence ordering", () => {
  it("prioritizes incomparable over insufficient_evidence when both would apply", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    // c2 is both under a mismatched fingerprint AND missing heldout admission.
    expect(secondCandidateState(c1, { comparabilityFingerprint: HASH_2, fixtureSetContentHash: HASH_3, heldoutAdmitted: false, partition: "SEARCH" })).toBe("incomparable");
  });

  it("prioritizes insufficient_evidence over ineligible when both would apply", () => {
    // Missing held-out admission (insufficient_evidence) AND over budget (ineligible).
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, partition: "SEARCH", heldoutAdmitted: false, budgetCeiling: 1, budgetConsumed: 999 });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });

  it("prioritizes ineligible over eligible_nonpreferred/preferred when both would otherwise be reachable", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, budgetCeiling: 1, budgetConsumed: 999 });
    expect(singleCandidateState([c1], { preferenceAuthority: GC026_AUTHORITY({ "cand-1": 100 }) })).toBe("ineligible");
  });

  it("no numeric score can reverse an eligibility failure (no-score-laundering) via a high rubric adapter score", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, rubricEvaluatorAdapter: { materialDefectFound: true, score: 99 } });
    expect(singleCandidateState([c1], { preferenceAuthority: GC026_AUTHORITY({ "cand-1": 9999 }) })).toBe("ineligible");
  });
});

describe("evaluateTaskClassCalibrationRound - immutability of inputs", () => {
  // Merged: same no-preference-authority fixture shape used to prove both non-mutation of the caller's input and determinism of the result.
  it("never mutates the supplied round input, and running it twice produces deep-equal (structurally identical) results", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const input = roundInput([c1]);
    const snapshot = JSON.parse(JSON.stringify(input));
    const outcome1 = evaluateTaskClassCalibrationRound(input);
    expect(input).toEqual(snapshot);
    const outcome2 = evaluateTaskClassCalibrationRound(input);
    expect(outcome1).toEqual(outcome2);
  });

  it("returns frozen assessment, candidateDecisions, and regressionBinding objects", () => {
    const outcome = acceptedOutcome();
    expect(Object.isFrozen(outcome.assessment)).toBe(true);
    expect(Object.isFrozen(outcome.assessment.candidateDecisions)).toBe(true);
    expect(Object.isFrozen(outcome.assessment.candidateDecisions[0])).toBe(true);
    expect(Object.isFrozen(outcome.regressionBinding)).toBe(true);
  });
});

describe("evaluateTaskClassCalibrationRound - no preference evidence case", () => {
  it("records NO_ADMISSIBLE_PREFERENCE_EVIDENCE when no preferenceAuthority is supplied at all", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1]);
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
    expect(outcome.regressionBinding).toBeNull();
  });
});

describe("evaluateRegressionBindingInvalidation - every invalidation trigger", () => {
  const CURRENT_STATUS: "CURRENT" = "CURRENT";
  const currentBinding = { invalidationStatus: CURRENT_STATUS };

  it("fixture_set_content_hash_changes_for_bound_task_class triggers STALE", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, { fixtureSetContentHashChanged: true });
    expect(result.invalidationStatus).toBe("STALE");
    expect(result.triggeredBy).toContain("fixture_set_content_hash_changes_for_bound_task_class");
  });
  it("candidate_config_or_bound_trace_result_or_producer_receipt_changes triggers STALE", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, { candidateConfigOrTraceOrReceiptChanged: true });
    expect(result.invalidationStatus).toBe("STALE");
    expect(result.triggeredBy).toContain("candidate_config_or_bound_trace_result_or_producer_receipt_changes");
  });
  it("partition_rubric_environment_policy_acceptance_or_preference_policy_changes triggers STALE", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, { partitionRubricEnvironmentPolicyOrPreferencePolicyChanged: true });
    expect(result.invalidationStatus).toBe("STALE");
    expect(result.triggeredBy).toContain("partition_rubric_environment_policy_acceptance_or_preference_policy_changes");
  });
  it("accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum triggers STALE", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, { providerLaneReadinessDowngradedBelowMinimum: true });
    expect(result.invalidationStatus).toBe("STALE");
    expect(result.triggeredBy).toContain("accepted_candidate_provider_lane_readiness_downgrades_below_required_minimum");
  });
  it("gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence triggers STALE", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, { gc026PromotionChangedOrWithdrawn: true });
    expect(result.invalidationStatus).toBe("STALE");
    expect(result.triggeredBy).toContain("gc026_promotion_changes_or_is_withdrawn_for_relied_on_performance_evidence");
  });
  it("accepted_candidate_budget_ceiling_lowered_below_recorded_consumption triggers STALE", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, { budgetCeilingLoweredBelowConsumption: true });
    expect(result.invalidationStatus).toBe("STALE");
    expect(result.triggeredBy).toContain("accepted_candidate_budget_ceiling_lowered_below_recorded_consumption");
  });

  it("remains CURRENT when no invalidation-relevant fact is observed", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, {});
    expect(result.invalidationStatus).toBe("CURRENT");
    expect(result.triggeredBy).toEqual([]);
  });

  it("never performs an automatic rollback or configuration mutation; only reports invalidationStatus/triggeredBy", () => {
    const result = evaluateRegressionBindingInvalidation(currentBinding, { fixtureSetContentHashChanged: true });
    expect(Object.keys(result).sort()).toEqual(["invalidationStatus", "triggeredBy"]);
  });

  it("fails closed to STALE on malformed binding/observedFacts input rather than throwing or reporting CURRENT", () => {
    const result = evaluateRegressionBindingInvalidation(null, null);
    expect(result.invalidationStatus).toBe("STALE");
  });

  it("does not mutate the supplied binding object", () => {
    const binding = { invalidationStatus: CURRENT_STATUS, extra: "untouched" };
    const snapshot = JSON.parse(JSON.stringify(binding));
    evaluateRegressionBindingInvalidation(binding, { fixtureSetContentHashChanged: true });
    expect(binding).toEqual(snapshot);
  });
});

describe("composeComparabilityFingerprintPreimage", () => {
  it("joins all eight fields in the exact documented order with a pipe separator", () => {
    const preimage = composeComparabilityFingerprintPreimage({
      canonicalVersion: "v1",
      taskClassId: "tc1",
      fixtureSetContentHash: HASH_C,
      environmentDescriptorHash: HASH_1,
      policyId: "policy-1",
      acceptanceCriteriaVersion: "ac-v1",
      gradingRubricVersionHash: HASH_2,
      heldoutPartitionHash: HASH_3,
    });
    expect(preimage).toBe(`v1|tc1|${HASH_C}|${HASH_1}|policy-1|ac-v1|${HASH_2}|${HASH_3}`);
  });

  it("never throws on malformed (non-string) field input; coerces to empty string deterministically", () => {
    // @ts-expect-error deliberately malformed for fail-closed determinism proof
    const preimage = composeComparabilityFingerprintPreimage({ canonicalVersion: 123 });
    expect(typeof preimage).toBe("string");
  });
});

describe("evaluateTaskClassCalibrationRound - malformed candidate structural fail-closed", () => {
  it("treats a non-array candidates field as an empty candidate set", () => {
    const outcome = evaluateTaskClassCalibrationRound({ taskClassId: "tc1", candidates: "not-an-array" });
    expect(outcome.kind).toBe("BLOCKED_EMPTY_CANDIDATE_SET");
  });

  it("treats a candidate that is not an object as insufficient_evidence, never throwing", () => {
    const outcome = assessedOutcome([null as unknown as Record<string, unknown>]);
    expect(outcome.assessment.candidateDecisions[0].state).toBe("insufficient_evidence");
  });

  it("rejects a malformed (non-canonical) candidateConfigHash as insufficient_evidence", () => {
    // hashOverrides overwrites the derived hash with a non-canonical literal, exercising the canonical-hash-shape check (distinct from the R2-2 recomputation-mismatch check, which needs a well-formed-but-wrong hash).
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A }, { candidateConfigHash: "not-a-hash" });
    expect(singleCandidateState([c1])).toBe("insufficient_evidence");
  });
});

describe("evaluateTaskClassCalibrationRound - provider readiness as eligibility gate only", () => {
  it("marks a candidate outside the allowed provider-lane status set ineligible, never using status for ranking", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, providerLaneStatus: "BLOCKED" });
    expect(singleCandidateState([c1])).toBe("ineligible");
  });

  it("accepts a caller-declared custom allowed-status set", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, providerLaneStatus: "EXPERIMENTAL" });
    expect(singleCandidateState([c1], { allowedProviderLaneStatuses: ["EXPERIMENTAL"] })).toBe("eligible_nonpreferred");
  });
});

describe("evaluateTaskClassCalibrationRound - forbidden-from-silent-comparison dimensions", () => {
  it("marks a candidate incomparable when a forbidden dimension varies, even under a matching fingerprint", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, declaredDimensions: { task_case_set_fixture_set: "set-1" } });
    expect(secondCandidateState(c1, { declaredDimensions: { task_case_set_fixture_set: "set-2" } })).toBe("incomparable");
  });

  it("allows an allowed dimension (e.g. effort_reasoning_level_profile) to vary without becoming incomparable", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, declaredDimensions: { effort_reasoning_level_profile: "low" } });
    expect(secondCandidateState(c1, { declaredDimensions: { effort_reasoning_level_profile: "high" } })).not.toBe("incomparable");
  });
});

describe("evaluateTaskClassCalibrationRound - R1 Finding 2: preference authority bound-evidence requirements", () => {
  it("fails closed to NO_ADMISSIBLE_PREFERENCE_EVIDENCE when a GC026 authority is missing promotionRecordRef/promotedAt (bound-evidence field)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    // promotionRecordRef/promotedAt deliberately omitted
    const outcome = assessedOutcome([c1], {
      preferenceAuthority: { kind: "GC026_PROMOTED_PERFORMANCE_REFERENCE", ref: "gc026-ref-1", valueByCandidateId: { "cand-1": 10 } },
    });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
    expect(outcome.regressionBinding).toBeNull();
  });

  it("fails closed to NO_ADMISSIBLE_PREFERENCE_EVIDENCE when a rubric authority's rubricVersionHash is malformed/non-canonical", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1], {
      preferenceAuthority: { kind: "PREDECLARED_COMPARABLE_VERSION_BOUND_DETERMINISTIC_RUBRIC", ref: "rubric-v1", rubricVersionHash: "not-a-canonical-hash", valueByCandidateId: { "cand-1": 10 } },
    });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
  });

  it("records NO_ADMISSIBLE_PREFERENCE_EVIDENCE (not a subset-only ACCEPTED_PREFERRED) when an eligible candidate is missing a score value", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = secondCandidate();
    // Only cand-1 has a score; cand-2 is eligible but has no value.
    const outcome = assessedOutcome([c1, c2], { preferenceAuthority: GC026_AUTHORITY({ "cand-1": 100 }) });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
    expect(outcome.regressionBinding).toBeNull();
    // Both remain eligible_nonpreferred; incomplete coverage never silently narrows the comparison to the subset that happened to have a score.
    expect(outcome.assessment.candidateDecisions.find((d) => d.candidateId === "cand-1")?.state).toBe("eligible_nonpreferred");
    expect(outcome.assessment.candidateDecisions.find((d) => d.candidateId === "cand-2")?.state).toBe("eligible_nonpreferred");
  });

  it("still never admits PROPOSAL_ONLY_EXPLORATORY alone regardless of bound-evidence fields (unchanged intent)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1], {
      preferenceAuthority: { kind: "PROPOSAL_ONLY_EXPLORATORY", ref: "benchmark-1", valueByCandidateId: { "cand-1": 999 } },
    });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
  });

  it("still never launders a no-score subset into preferred (unchanged intent: no-score-laundering test continues to pass)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1], { preferenceAuthority: GC026_AUTHORITY({}) });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
  });
});

describe("evaluateTaskClassCalibrationRound - R1 Finding 3: real SHA-256 provenanceFingerprint and boundAt/CURRENT consistency", () => {
  const CANONICAL_HASH_PATTERN = /^[0-9a-f]{64}$/;

  it("provenanceFingerprint is a canonical 64-hex-char SHA-256-shaped string, not the raw pipe-joined preimage", () => {
    const fp = acceptedOutcome().assessment.provenanceFingerprint;
    expect(fp).not.toBeNull();
    expect(CANONICAL_HASH_PATTERN.test(fp as string)).toBe(true);
    // Must not just be the pipe-joined preimage string.
    expect(fp).not.toContain("|");
  });

  it("is deterministic: identical inputs produce the identical provenanceFingerprint", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const input = roundInput([c1], {
      preferenceAuthority: GC026_AUTHORITY({ "cand-1": 42 }),
      acceptedAt: "2026-09-17T00:00:00Z",
    });
    const outcome1 = evaluateTaskClassCalibrationRound(input);
    const outcome2 = evaluateTaskClassCalibrationRound(input);
    if (outcome1.kind !== "ASSESSED" || outcome2.kind !== "ASSESSED") throw new Error("unreachable");
    expect(outcome1.assessment.provenanceFingerprint).toBe(outcome2.assessment.provenanceFingerprint);
  });

  it("changes when a preimage-relevant input changes (e.g. a different acceptedCandidateId via a different sole eligible candidate)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = baseCandidate({ candidateId: "cand-2", candidateConfigHash: HASH_B, fixtureId: "fixture-1" });
    const outcome1 = evaluateTaskClassCalibrationRound(roundInput([c1], { preferenceAuthority: GC026_AUTHORITY({ "cand-1": 42 }), acceptedAt: "2026-09-17T00:00:00Z" }));
    const outcome2 = evaluateTaskClassCalibrationRound(roundInput([c2], { preferenceAuthority: GC026_AUTHORITY({ "cand-2": 42 }), acceptedAt: "2026-09-17T00:00:00Z" }));
    if (outcome1.kind !== "ASSESSED" || outcome2.kind !== "ASSESSED") throw new Error("unreachable");
    expect(outcome1.assessment.provenanceFingerprint).not.toBe(outcome2.assessment.provenanceFingerprint);
  });

  // Merged: missing acceptedAt and an explicitly empty-string acceptedAt are two input variants of the same underlying "acceptedAt not usably present" check; both must withhold the binding identically.
  it("never emits a RegressionBinding CURRENT with an empty boundAt, for both missing and empty-string acceptedAt", () => {
    for (const roundOverrides of [{}, { acceptedAt: "" }]) {
      const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
      const outcome = assessedOutcome([c1], { preferenceAuthority: GC026_AUTHORITY({ "cand-1": 42 }), ...roundOverrides });
      expect(outcome.assessment.roundOutcome).toBe("ACCEPTED_PREFERRED");
      expect(outcome.regressionBinding).toBeNull();
      // The withheld-binding reason must be disclosed, not silently dropped.
      expect(outcome.assessment.exclusions.some((e) => e.reason.includes("RegressionBinding is never emitted CURRENT with an empty boundAt"))).toBe(true);
    }
  });

  it("emits a RegressionBinding with a non-empty boundAt and CURRENT status when acceptedAt is properly supplied", () => {
    const outcome = acceptedOutcome();
    expect(outcome.regressionBinding).not.toBeNull();
    expect(outcome.regressionBinding?.boundAt).toBe("2026-09-17T00:00:00Z");
    expect(outcome.regressionBinding?.invalidationStatus).toBe("CURRENT");
    // The invariant this fix establishes: it is structurally impossible for this module to hand back CURRENT with an empty boundAt.
    if (outcome.regressionBinding?.invalidationStatus === "CURRENT") {
      expect(outcome.regressionBinding.boundAt.length).toBeGreaterThan(0);
    }
  });
});

describe("evaluateTaskClassCalibrationRound - R1 Finding 4: schemaVersion and preferenceAuthority in output shape", () => {
  it("OperatingPointAssessment declares a schemaVersion containing the checker's exact schema marker", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1]);
    expect(outcome.assessment.schemaVersion).toContain("cvf.taskClassCalibrationOwner");
  });

  it("RegressionBinding declares a schemaVersion containing the checker's exact schema marker", () => {
    expect(acceptedOutcome().regressionBinding?.schemaVersion).toContain("cvf.taskClassCalibrationOwner");
  });
  it("includes preferenceAuthority in the OperatingPointAssessment output shape when ACCEPTED_PREFERRED", () => {
    const outcome = acceptedOutcome();
    expect(outcome.assessment.preferenceAuthority).not.toBeNull();
    expect(outcome.assessment.preferenceAuthority?.kind).toBe("GC026_PROMOTED_PERFORMANCE_REFERENCE");
  });

  it("preferenceAuthority is null in the output shape when no admissible authority was used", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1]);
    expect(outcome.assessment.preferenceAuthority).toBeNull();
  });
});

describe("evaluateTaskClassCalibrationRound - R2 Finding 1: round-level G3 fixture-set admission genuinely gates eligibility", () => {
  it("fails every candidate to insufficient_evidence when the round's pooled g3Fixture set is POSITIVE-only (no negative companion)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = secondCandidate();
    // skipNegativeCompanion: true -- deliberately exercising the gate itself.
    const outcome = assessedOutcome([c1, c2], { skipNegativeCompanion: true });
    for (const d of outcome.assessment.candidateDecisions) {
      expect(d.state).toBe("insufficient_evidence");
      expect(d.state).not.toBe("eligible_nonpreferred");
      expect(d.state).not.toBe("preferred");
    }
    // Every per-candidate reason names the round-level admission failure.
    for (const d of outcome.assessment.candidateDecisions) {
      expect(d.reasons.some((r) => r.includes("round-level G3 fixture-set admission failed"))).toBe(true);
    }
    expect(outcome.assessment.roundOutcome).toBe("NO_ELIGIBLE_CANDIDATE");
    // The round-level exclusion reason is also visible in `exclusions`.
    expect(outcome.assessment.exclusions.some((e) => e.candidateId === "" && e.reason.includes("MISSING_NEGATIVE_CASE"))).toBe(true);
  });

  it("fails every candidate to insufficient_evidence when the round's pooled g3Fixture set is NEGATIVE-only (no positive case)", () => {
    const c1 = negativeCompanionCandidate({ candidateId: "cand-1" });
    const outcome = assessedOutcome([c1], { skipNegativeCompanion: true });
    expect(outcome.assessment.candidateDecisions[0].state).toBe("insufficient_evidence");
    expect(outcome.assessment.candidateDecisions[0].reasons.some((r) => r.includes("round-level G3 fixture-set admission failed: MISSING_POSITIVE_CASE"))).toBe(true);
    expect(outcome.assessment.roundOutcome).toBe("NO_ELIGIBLE_CANDIDATE");
  });

  it("names the exact admission failure kind and positive/negative counts in the per-candidate reason", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const outcome = assessedOutcome([c1], { skipNegativeCompanion: true });
    expect(outcome.assessment.candidateDecisions[0].reasons.some((r) => r.includes("MISSING_NEGATIVE_CASE") && r.includes("positiveCount=1") && r.includes("negativeCount=0"))).toBe(true);
  });

  it("genuinely gates eligibility (not merely informational): a candidate that would otherwise be eligible_nonpreferred under a POSITIVE-only pool is instead insufficient_evidence", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const withoutGate = evaluateTaskClassCalibrationRound(roundInput([c1])); // admitted (companion present)
    const withGateFailure = evaluateTaskClassCalibrationRound(roundInput([c1], { skipNegativeCompanion: true }));
    if (withoutGate.kind !== "ASSESSED" || withGateFailure.kind !== "ASSESSED") throw new Error("unreachable");
    expect(withoutGate.assessment.candidateDecisions[0].state).toBe("eligible_nonpreferred");
    expect(withGateFailure.assessment.candidateDecisions[0].state).toBe("insufficient_evidence");
  });

  it("a genuinely POSITIVE+NEGATIVE admitted pool (via the negative companion) still allows preferred (positive control)", () => {
    expect(acceptedOutcome().assessment.roundOutcome).toBe("ACCEPTED_PREFERRED");
  });
});

describe("evaluateTaskClassCalibrationRound - R2 Finding 2: taskClassId cross-check and candidateConfigHash/comparabilityFingerprint recomputation", () => {
  it("fails closed to insufficient_evidence when a candidate's declared taskClassId does not match the round's declared taskClassId", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A, taskClassId: "task-class-DIFFERENT" });
    const decision = singleCandidateDecision([c1]);
    expect(decision.state).toBe("insufficient_evidence");
    expect(decision.reasons.some((r) => r.includes("does not match the round's declared taskClassId"))).toBe(true);
  });

  it("fails closed to insufficient_evidence when taskClassId is missing/empty on the candidate envelope", () => {
    const malformed = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    delete (malformed as Record<string, unknown>).taskClassId;
    const outcome = assessedOutcome([malformed]);
    expect(outcome.assessment.candidateDecisions[0].state).toBe("insufficient_evidence");
  });

  it("fails closed to insufficient_evidence when candidateConfigHash does not match the recomputed hash of declaredDimensions (well-formed but fabricated)", () => {
    // well-formed canonical hash, but not the real recomputed one
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A }, { candidateConfigHash: HASH_2 });
    const decision = singleCandidateDecision([c1]);
    expect(decision.state).toBe("insufficient_evidence");
    expect(decision.reasons.some((r) => r.includes("declared candidateConfigHash does not match the recomputed hash of declaredDimensions"))).toBe(true);
  });

  it("fails closed to insufficient_evidence when comparabilityFingerprint does not match the recomputed hash of its declared constituent fields (well-formed but fabricated)", () => {
    // well-formed canonical hash, but not the real recomputed one
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A }, { comparabilityFingerprint: HASH_2 });
    const decision = singleCandidateDecision([c1]);
    // Distinct from the tier-1 cross-candidate incomparable check.
    expect(decision.state).toBe("insufficient_evidence");
    expect(decision.state).not.toBe("incomparable");
    expect(decision.reasons.some((r) => r.includes("declared comparabilityFingerprint does not match the recomputed hash of its declared constituent fields"))).toBe(true);
  });

  it("a candidate with genuinely, correctly recomputed candidateConfigHash/comparabilityFingerprint (via baseCandidate's own derivation) still reaches eligible_nonpreferred (positive control)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    expect(singleCandidateState([c1])).toBe("eligible_nonpreferred");
  });
});

describe("evaluateTaskClassCalibrationRound - R2 Finding 3: GC-026 attestation structure and candidate binding", () => {
  it("fails closed to NO_ADMISSIBLE_PREFERENCE_EVIDENCE when gc026Attestation is entirely missing", () => {
    const authority = GC026_AUTHORITY({ "cand-1": 42 }) as Record<string, unknown>;
    delete authority.gc026Attestation;
    const outcome = acceptedOutcome({}, { preferenceAuthority: authority as never });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.regressionBinding).toBeNull();
  });

  it("fails closed to NO_ADMISSIBLE_PREFERENCE_EVIDENCE when gc026Attestation is malformed (missing recordContent fields)", () => {
    const authority = GC026_AUTHORITY({ "cand-1": 42 }) as Record<string, unknown>;
    // missing candidateConfigHash/promotionRecordRef/promotedAt
    authority.gc026Attestation = { registrySnapshotHash: HASH_1, recordContentHash: HASH_2, recordContent: { taskClassId: "task-class-1" } };
    const outcome = acceptedOutcome({}, { preferenceAuthority: authority as never });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
  });

  it("fails closed to NO_ADMISSIBLE_PREFERENCE_EVIDENCE when gc026Attestation.recordContentHash does not match the recomputed hash of recordContent (fabricated hash)", () => {
    const authority = GC026_AUTHORITY({ "cand-1": 42 }) as Record<string, unknown>;
    // well-formed but not the real recomputed hash
    authority.gc026Attestation = { ...(authority.gc026Attestation as Record<string, unknown>), recordContentHash: HASH_3 };
    const outcome = acceptedOutcome({}, { preferenceAuthority: authority as never });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
  });

  it("fails closed to NO_ADMISSIBLE_PREFERENCE_EVIDENCE when gc026Attestation.recordContent names a DIFFERENT taskClassId than the candidate being preferred", () => {
    const authority = GC026_AUTHORITY({ "cand-1": 42 }, { taskClassId: "task-class-DIFFERENT", candidateConfigHash: DEFAULT_CAND_1_CANDIDATE_CONFIG_HASH });
    const outcome = acceptedOutcome({}, { preferenceAuthority: authority });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
    expect(outcome.regressionBinding).toBeNull();
  });

  it("fails closed to NO_ADMISSIBLE_PREFERENCE_EVIDENCE when gc026Attestation.recordContent names a DIFFERENT candidateConfigHash than the candidate being preferred (direct analogue of R1's candidate-misattribution test, for promotion attestation)", () => {
    // a real-looking but WRONG candidateConfigHash
    const authority = GC026_AUTHORITY({ "cand-1": 42 }, { taskClassId: "task-class-1", candidateConfigHash: HASH_2 });
    const outcome = acceptedOutcome({}, { preferenceAuthority: authority });
    expect(outcome.assessment.roundOutcome).toBe("NO_ADMISSIBLE_PREFERENCE_EVIDENCE");
    expect(outcome.assessment.acceptedCandidateId).toBeNull();
    expect(outcome.regressionBinding).toBeNull();
  });

  it("a genuine, fully consistent, correctly-bound attestation still reaches preferred with a RegressionBinding (positive control)", () => {
    const outcome = acceptedOutcome();
    expect(outcome.assessment.roundOutcome).toBe("ACCEPTED_PREFERRED");
    expect(outcome.assessment.acceptedCandidateId).toBe("cand-1");
    expect(outcome.regressionBinding).not.toBeNull();
    expect(outcome.regressionBinding?.invalidationStatus).toBe("CURRENT");
  });

  it("an attestation genuinely bound to the winning candidate among two candidates still reaches preferred (candidate-selection-time binding check with more than one eligible candidate)", () => {
    const c1 = baseCandidate({ candidateId: "cand-1", candidateConfigHash: HASH_A });
    const c2 = secondCandidate();
    const outcome = assessedOutcome([c1, c2], {
      preferenceAuthority: GC026_AUTHORITY({ "cand-1": 42, "cand-2": 1 }), // bound to cand-1 by default
      acceptedAt: "2026-09-17T00:00:00Z",
    });
    expect(outcome.assessment.roundOutcome).toBe("ACCEPTED_PREFERRED");
    expect(outcome.assessment.acceptedCandidateId).toBe("cand-1");
  });
});
